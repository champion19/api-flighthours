# Release 6: Matrícula (Aircraft Registration) - CRUD Completo

**Tag Git**: `v0.6.0`
**Estado**: ✅ Completado
**Total Horas**: 24h

## Historias de Usuario


| HU   | Descripción                                | Horas | Endpoint                           | Estado | Full Stack |
| ---- | ------------------------------------------- | ----- | ---------------------------------- | ------ | ---------- |
| HU33 | Consultar la Información de la Matrícula  | 8h    | `GET /aircraft-registrations/{id}` | ✅     | 🟡         |
| HU34 | Agregar la Información de la Matrícula    | 8h    | `POST /aircraft-registrations`     | ✅     | 🟡         |
| HU35 | Actualizar la Información de la Matrícula | 8h    | `PUT /aircraft-registrations/{id}` | ✅     | 🟡         |

## Dependencias

- ✅ Release 2: Aerolínea (FK airline_id)
- ✅ Release 7: Modelo Aeronave (FK aircraft_model_id)

## Estructura del Módulo Aircraft Registration

```
core/
├── interactor/
│   ├── interactor_aircraft_registration.go
│   └── services/
│       ├── aircraft_registration_services.go
│       └── domain/
│           └── aircraft_registration.go
handlers/
├── aircraft_registration.go              # DTOs y mappers
└── aircraft_registration_controller.go   # Handlers
platform/
└── databases/
    └── repositories/
        └── aircraft_registration/        # Repository con prepared statements
```

## Notas Técnicas

> 📋 **aircraft_registration** es la tabla que vincula una placa (license_plate) con un modelo de aeronave y una aerolínea.
> 🔗 **Relaciones**: FK a `aircraft_model` y `airline`
> ⚠️ **Clave única**: `license_plate` es única a nivel global.
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.
> 🔑 **Dual-Format ID Resolution**: Acepta tanto UUID como ID ofuscado (HashID).

## Tabla de Base de Datos

```sql
CREATE TABLE aircraft_registration (
    id VARCHAR(36) NOT NULL,
    license_plate VARCHAR(20) NOT NULL UNIQUE,
    aircraft_model_id VARCHAR(36) NOT NULL,
    airline_id VARCHAR(36) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_registration_model FOREIGN KEY (aircraft_model_id) REFERENCES aircraft_model(id),
    CONSTRAINT fk_registration_airline FOREIGN KEY (airline_id) REFERENCES airline(id)
);
```

---

## Escenarios de Prueba

### HU33 - Consultar la Información de la Matrícula


| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                             | Código Mensaje     | Estado      |
| ---------- | --------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ----------- |
| CONMAT-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar la información de una Matrícula, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque una matrícula válida, **entonces** el sistema mostrará correctamente los datos de la matrícula incluyendo número de placa, modelo de aeronave y aerolínea, presentará la información en la vista correspondiente y mostrará al usuario final el mensaje satisfactorio `MAT_CON_EXI_03301`. | `MAT_CON_EXI_03301` | ✅ Aceptado |
| CONMAT-CA2 | ❌ Error  | **Dado** que un Piloto del Sistema quiere consultar la información de una Matrícula, **cuando** intente realizar la consulta con un identificador que no existe en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `MAT_CON_ERR_03302` indicando que la matrícula no fue encontrada y permitirá realizar una nueva búsqueda.                                                                 | `MAT_CON_ERR_03302` | ✅ Aceptado |
| CONMAT-CA3 | ❌ Error  | **Dado** que un Piloto del Sistema quiere consultar la información de una Matrícula, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `MAT_CON_ERR_03303` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                  | `MAT_CON_ERR_03303` | ✅ Aceptado |

### HU34 - Agregar la Información de la Matrícula


| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Código Mensaje     | Estado      |
| ---------- | --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ----------- |
| AGRMAT-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere agregar la información de una Matrícula, **cuando** acceda a la funcionalidad correspondiente e ingrese correctamente todos los datos requeridos (como número de placa, modelo de aeronave y aerolínea), **entonces** el sistema registrará exitosamente la nueva matrícula, la asociará correctamente a la aeronave y aerolínea correspondientes, se mostrará al usuario final el mensaje satisfactorio `MAT_AGR_EXI_03401` y se reflejará la información en la vista de matrículas. | `MAT_AGR_EXI_03401` | ✅ Aceptado |
| AGRMAT-CA2 | ❌ Error  | **Dado** que un Piloto del Sistema quiere agregar la información de una Matrícula, **cuando** intente registrar un número de placa que ya existe en el sistema, **entonces** el sistema no guardará la información, mostrará al usuario final el mensaje de advertencia `MAT_AGR_ERR_03403` indicando que la matrícula ya existe y mantendrá el formulario activo para corregir el número de placa.                                                                                                                                | `MAT_AGR_ERR_03403` | ✅ Aceptado |
| AGRMAT-CA3 | ❌ Error  | **Dado** que un Piloto del Sistema quiere agregar la información de una Matrícula, **cuando** seleccione un modelo de aeronave que no existe o es inválido, **entonces** el sistema no guardará la información, mostrará al usuario final el mensaje de advertencia `MAT_VAL_ERR_03601` indicando que el modelo de aeronave seleccionado no es válido y mantendrá el formulario abierto para seleccionar un modelo correcto.                                                                                                        | `MAT_VAL_ERR_03601` | ✅ Aceptado |
| AGRMAT-CA4 | ❌ Error  | **Dado** que un Piloto del Sistema quiere agregar la información de una Matrícula, **cuando** seleccione una aerolínea que no existe o es inválida, **entonces** el sistema no guardará la información, mostrará al usuario final el mensaje de advertencia `MAT_VAL_ERR_03602` indicando que la aerolínea seleccionada no es válida y mantendrá el formulario abierto para seleccionar una aerolínea correcta.                                                                                                                  | `MAT_VAL_ERR_03602` | ✅ Aceptado |
| AGRMAT-CA5 | ❌ Error  | **Dado** que un Piloto del Sistema quiere agregar la información de una Matrícula, **cuando** ocurra un error técnico durante el proceso (como un fallo en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `MAT_AGR_ERR_03402` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                                                                                           | `MAT_AGR_ERR_03402` | ✅ Aceptado |

### HU35 - Actualizar la Información de la Matrícula


| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                               | Código Mensaje     | Estado      |
| ---------- | --------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ----------- |
| EDIMAT-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere actualizar la información de una Matrícula, **cuando** acceda a la funcionalidad correspondiente, seleccione una matrícula válida e ingrese correctamente los datos a modificar, **entonces** el sistema guardará los cambios exitosamente, mostrará al usuario final el mensaje satisfactorio `MAT_EDI_EXI_03501` y reflejará la información actualizada en la vista de matrículas. | `MAT_EDI_EXI_03501` | ✅ Aceptado |
| EDIMAT-CA2 | ❌ Error  | **Dado** que un Piloto del Sistema quiere actualizar la información de una Matrícula, **cuando** intente modificar una matrícula que no existe en el sistema, **entonces** el sistema no permitirá continuar, mostrará al usuario final el mensaje de advertencia `MAT_CON_ERR_03302` indicando que la matrícula no fue encontrada y permitirá seleccionar otro registro.                                                        | `MAT_CON_ERR_03302` | ✅ Aceptado |
| EDIMAT-CA3 | ❌ Error  | **Dado** que un Piloto del Sistema quiere actualizar la información de una Matrícula, **cuando** seleccione un modelo de aeronave que no existe o es inválido, **entonces** el sistema no guardará los cambios, mostrará al usuario final el mensaje de advertencia `MAT_VAL_ERR_03601` indicando que el modelo de aeronave seleccionado no es válido y mantendrá el formulario abierto para seleccionar un modelo correcto.     | `MAT_VAL_ERR_03601` | ✅ Aceptado |
| EDIMAT-CA4 | ❌ Error  | **Dado** que un Piloto del Sistema quiere actualizar la información de una Matrícula, **cuando** seleccione una aerolínea que no existe o es inválida, **entonces** el sistema no guardará los cambios, mostrará al usuario final el mensaje de advertencia `MAT_VAL_ERR_03602` indicando que la aerolínea seleccionada no es válida y mantendrá el formulario abierto para seleccionar una aerolínea correcta.               | `MAT_VAL_ERR_03602` | ✅ Aceptado |
| EDIMAT-CA5 | ❌ Error  | **Dado** que un Piloto del Sistema quiere actualizar la información de una Matrícula, **cuando** ocurra un error técnico durante el proceso (como un fallo en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `MAT_EDI_ERR_03502` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.    | `MAT_EDI_ERR_03502` | ✅ Aceptado |

### Listar Matrículas (Funcionalidad adicional)


| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                    | Código Mensaje      | Estado      |
| ---------- | --------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- | ----------- |
| LSTMAT-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar el listado de Matrículas, **cuando** acceda a la funcionalidad correspondiente y opcionalmente aplique filtros por aerolínea, **entonces** el sistema mostrará el listado completo de matrículas con sus datos asociados (número de placa, modelo y aerolínea), presentará la información en la vista correspondiente y mostrará el mensaje satisfactorio `MAT_LIST_EXI_03001`. | `MAT_LIST_EXI_03001` | ✅ Aceptado |
| LSTMAT-CA2 | ❌ Error  | **Dado** que un Piloto del Sistema quiere consultar el listado de Matrículas, **cuando** ocurra un error técnico durante el proceso, **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error `MAT_LIST_ERR_03002` y recomendará intentar nuevamente más tarde.                                                                                                                         | `MAT_LIST_ERR_03002` | ✅ Aceptado |

---

## Archivos Principales Modificados


| Categoría     | Archivos                                                                                                                   |
| -------------- | -------------------------------------------------------------------------------------------------------------------------- |
| **Handlers**   | `aircraft_registration_controller.go`, `aircraft_registration.go`, `handler.go`, `hateoas.go`                              |
| **Interactor** | `interactor_aircraft_registration.go`                                                                                      |
| **Services**   | `aircraft_registration_services.go`                                                                                        |
| **Domain**     | `domain/aircraft_registration.go`, `domain/erros.go`                                                                       |
| **Ports**      | `input/service.go`, `output/repository.go`                                                                                 |
| **Repository** | `repositories/aircraft_registration/` (aircraft_registration.go, repository.go, get_by_id.go, list.go, save.go, update.go) |
| **Logger**     | `log_messages.go`                                                                                                          |
| **Cache**      | `platform/cache/messaging/cache.go`                                                                                        |
| **Dependency** | `cmd/dependency/dependency.go`                                                                                             |
| **Server**     | `server/server.go`                                                                                                         |
| **Schema**     | `platform/schema/json_schema/create_aircraft_registration_schema.json`, `update_aircraft_registration_schema.json`         |

---

## Códigos de Mensaje Implementados

### Mensajes de Éxito en errors.go


| Constante                        | Código              | Tipo   |
| -------------------------------- | -------------------- | ------ |
| `MsgAircraftRegistrationGetOK`   | `MAT_CON_EXI_03301`  | Éxito |
| `MsgAircraftRegistrationCreated` | `MAT_AGR_EXI_03401`  | Éxito |
| `MsgAircraftRegistrationUpdated` | `MAT_EDI_EXI_03501`  | Éxito |
| `MsgAircraftRegistrationListOK`  | `MAT_LIST_EXI_03001` | Éxito |

### Mensajes de Error en errors.go


| Constante                               | Código              | Tipo  |
| --------------------------------------- | -------------------- | ----- |
| `MsgAircraftRegistrationNotFound`       | `MAT_CON_ERR_03302`  | Error |
| `MsgAircraftRegistrationGetErr`         | `MAT_CON_ERR_03303`  | Error |
| `MsgAircraftRegistrationSaveError`      | `MAT_AGR_ERR_03402`  | Error |
| `MsgAircraftRegistrationDuplicate`      | `MAT_AGR_ERR_03403`  | Error |
| `MsgAircraftRegistrationUpdateError`    | `MAT_EDI_ERR_03502`  | Error |
| `MsgAircraftRegistrationListError`      | `MAT_LIST_ERR_03002` | Error |
| `MsgAircraftRegistrationInvalidModel`   | `MAT_VAL_ERR_03601`  | Error |
| `MsgAircraftRegistrationInvalidAirline` | `MAT_VAL_ERR_03602`  | Error |

### Errores de Dominio en errors.go


| Variable                                | Código de Error                            |
| --------------------------------------- | ------------------------------------------- |
| `ErrAircraftRegistrationNotFound`       | `ERR_AIRCRAFT_REGISTRATION_NOT_FOUND`       |
| `ErrAircraftRegistrationCannotSave`     | `ERR_AIRCRAFT_REGISTRATION_CANNOT_SAVE`     |
| `ErrAircraftRegistrationCannotUpdate`   | `ERR_AIRCRAFT_REGISTRATION_CANNOT_UPDATE`   |
| `ErrAircraftRegistrationDuplicatePlate` | `ERR_AIRCRAFT_REGISTRATION_DUPLICATE_PLATE` |
| `ErrAircraftRegistrationInvalidModel`   | `ERR_AIRCRAFT_REGISTRATION_INVALID_MODEL`   |
| `ErrAircraftRegistrationInvalidAirline` | `ERR_AIRCRAFT_REGISTRATION_INVALID_AIRLINE` |

### Mapeo HTTP Status en cache.go


| Código              | HTTP Status | Descripción                        |
| -------------------- | ----------- | ----------------------------------- |
| `MAT_CON_EXI_03301`  | 200         | Matrícula consultada exitosamente  |
| `MAT_CON_ERR_03302`  | 404         | Matrícula no encontrada            |
| `MAT_CON_ERR_03303`  | 500         | Error técnico al consultar         |
| `MAT_AGR_EXI_03401`  | 201         | Matrícula creada exitosamente      |
| `MAT_AGR_ERR_03402`  | 400         | Error al crear matrícula           |
| `MAT_AGR_ERR_03403`  | 409         | Matrícula duplicada                |
| `MAT_EDI_EXI_03501`  | 200         | Matrícula actualizada exitosamente |
| `MAT_EDI_ERR_03502`  | 400         | Error al actualizar matrícula      |
| `MAT_LIST_EXI_03001` | 200         | Lista obtenida exitosamente         |
| `MAT_LIST_ERR_03002` | 500         | Error al listar                     |
| `MAT_VAL_ERR_03601`  | 400         | Modelo de aeronave inválido        |
| `MAT_VAL_ERR_03602`  | 400         | Aerolínea inválida                |

---

## Notas de Release

1. Este release implementa el CRUD completo de Matrícula (Aircraft Registration): consultar, agregar, actualizar y listar.
2. Todos los endpoints están protegidos y requieren autenticación JWT.
3. Los endpoints aceptan tanto UUID directo como ID ofuscado (HashID) para mayor flexibilidad.
4. Se validan las referencias a tablas relacionadas (aircraft_model, airline) antes de guardar.
5. La respuesta incluye datos denormalizados (`model_name`, `airline_name`) obtenidos mediante JOINs SQL.
6. La arquitectura sigue el patrón hexagonal establecido: Handler → Interactor → Service → Repository.
7. Se implementa HATEOAS (Richardson Maturity Model Level 3) para navegación entre recursos relacionados.
8. Se incluyen JSON Schemas para validación de requests en POST y PUT.
9. Los errores de FK constraint de MySQL se mapean a errores específicos del módulo (modelo inválido, aerolínea inválida).
