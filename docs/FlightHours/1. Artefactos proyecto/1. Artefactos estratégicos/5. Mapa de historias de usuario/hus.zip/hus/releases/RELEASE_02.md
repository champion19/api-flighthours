# Release 02 - Módulo de Aerolínea

## Información General

| Campo | Valor |
|-------|-------|
| **Versión** | v0.3.0 |
| **Rama** | develop |
| **Sprint** | Sprint 2 |
| **Horas Planificadas** | 10 horas |
| **Pull Requests** | #15 |

---

## Historias de Usuario Incluidas

| Código | Historia de Usuario | Talla | Horas | Full Stack |
|--------|---------------------|-------|-------|------------|
| HU1 | Consultar la Información de la Aerolínea | XS | 2 | ✅ |
| HU2 | Inactivar la Aerolínea | S | 4 | 🟡 |
| HU3 | Activar la Aerolínea | S | 4 | 🟡 |

---

## Componentes Implementados

### 1. Consultar Aerolínea (HU1)
- Endpoint: `GET /flighthours/api/v1/airlines/:id`
- Acepta UUID o ID ofuscado
- Retorna información completa de la aerolínea

### 2. Inactivar Aerolínea (HU2)
- Endpoint: `PATCH /flighthours/api/v1/airlines/:id/deactivate`
- Cambia estado de la aerolínea a inactivo
- Acepta UUID o ID ofuscado

### 3. Activar Aerolínea (HU3)
- Endpoint: `PATCH /flighthours/api/v1/airlines/:id/activate`
- Cambia estado de la aerolínea a activo
- Acepta UUID o ID ofuscado

---

## Escenarios de Prueba

### HU1 - Consultar la Información de la Aerolínea

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| AERO-CA1 | ✅ Éxito | **Dado que** un Piloto del Sistema desea consultar la información de una aerolínea, **cuando** acceda a la funcionalidad de consulta de aerolínea, ingrese un identificador válido y confirme la acción, **entonces** el sistema recuperará la información correspondiente, mostrará los datos de la aerolínea de manera estructurada, desplegará el mensaje satisfactorio con el código `MOD_AIR_GET_EXI_00001` y permitirá al usuario continuar navegando en el sistema. | `MOD_AIR_GET_EXI_00001` | ✅ Aceptado |
| AERO-CA2 | ❌ Error | **Dado que** un Piloto del Sistema desea consultar la información de una aerolínea, **cuando** ingrese un identificador que no corresponde a ninguna aerolínea registrada en el sistema, **entonces** el sistema validará que la aerolínea no existe, mostrará el mensaje de error con el código `MOD_AIR_NOT_FOUND_ERR_00001` y no permitirá continuar con la consulta. | `MOD_AIR_NOT_FOUND_ERR_00001` | ✅ Aceptado |
| AERO-CA3 | ❌ Error | **Dado que** un Piloto del Sistema desea consultar la información de una aerolínea, **cuando** ingrese un identificador con formato incorrecto o inválido, **entonces** el sistema validará el formato del identificador, determinará que es inválido, mostrará el mensaje de error con el código `MOD_V_ID_ERR_00013` y solicitará al usuario que corrija el dato ingresado. | `MOD_V_ID_ERR_00013` | ✅ Aceptado |
| AERO-CA4 | ❌ Error | **Dado que** un Piloto del Sistema desea consultar la información de una aerolínea, **cuando** el sistema no pueda completar la operación debido a una falla interna, **entonces** el sistema detectará la condición de error, mostrará el mensaje con el código `GEN_SRV_ERR_00001` indicando que el servicio no está disponible temporalmente y sugerirá al usuario intentar nuevamente más tarde. | `GEN_SRV_ERR_00001` | ✅ Aceptado |

### HU2 - Inactivar la Aerolínea

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| INAC-CA1 | ✅ Éxito | **Dado que** un Administrador del Sistema desea inactivar una aerolínea, **cuando** acceda a la funcionalidad de gestión de aerolíneas, seleccione la opción de inactivar, ingrese un identificador válido y confirme la acción, **entonces** el sistema cambiará el estado de la aerolínea a inactivo, mostrará el mensaje satisfactorio con el código `MOD_AIR_DEACTIVATE_EXI_00003` y actualizará la vista para reflejar el nuevo estado de la aerolínea. | `MOD_AIR_DEACTIVATE_EXI_00003` | ✅ Aceptado |
| INAC-CA2 | ❌ Error | **Dado que** un Administrador del Sistema desea inactivar una aerolínea, **cuando** ingrese un identificador que no corresponde a ninguna aerolínea registrada en el sistema, **entonces** el sistema validará que la aerolínea no existe, mostrará el mensaje de error con el código `MOD_AIR_NOT_FOUND_ERR_00001` y no permitirá continuar con la operación de inactivación. | `MOD_AIR_NOT_FOUND_ERR_00001` | ✅ Aceptado |
| INAC-CA3 | ❌ Error | **Dado que** un Administrador del Sistema desea inactivar una aerolínea, **cuando** ingrese un identificador con formato incorrecto o inválido, **entonces** el sistema validará el formato del identificador, determinará que es inválido, mostrará el mensaje de error con el código `MOD_V_ID_ERR_00013` y solicitará al usuario que corrija el dato ingresado. | `MOD_V_ID_ERR_00013` | ✅ Aceptado |
| INAC-CA4 | ❌ Error | **Dado que** un Administrador del Sistema desea inactivar una aerolínea, **cuando** el sistema no pueda completar la operación debido a una falla interna, **entonces** el sistema detectará la condición de error, mostrará el mensaje con el código `GEN_SRV_ERR_00001` indicando que el servicio no está disponible temporalmente y sugerirá al usuario intentar nuevamente más tarde. | `GEN_SRV_ERR_00001` | ✅ Aceptado |

### HU3 - Activar la Aerolínea

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| ACTI-CA1 | ✅ Éxito | **Dado que** un Administrador del Sistema desea activar una aerolínea previamente inactiva, **cuando** acceda a la funcionalidad de gestión de aerolíneas, seleccione la opción de activar, ingrese un identificador válido y confirme la acción, **entonces** el sistema cambiará el estado de la aerolínea a activo, mostrará el mensaje satisfactorio con el código `MOD_AIR_ACTIVATE_EXI_00002` y actualizará la vista para reflejar el nuevo estado de la aerolínea. | `MOD_AIR_ACTIVATE_EXI_00002` | ✅ Aceptado |
| ACTI-CA2 | ❌ Error | **Dado que** un Administrador del Sistema desea activar una aerolínea, **cuando** ingrese un identificador que no corresponde a ninguna aerolínea registrada en el sistema, **entonces** el sistema validará que la aerolínea no existe, mostrará el mensaje de error con el código `MOD_AIR_NOT_FOUND_ERR_00001` y no permitirá continuar con la operación de activación. | `MOD_AIR_NOT_FOUND_ERR_00001` | ✅ Aceptado |
| ACTI-CA3 | ❌ Error | **Dado que** un Administrador del Sistema desea activar una aerolínea, **cuando** ingrese un identificador con formato incorrecto o inválido, **entonces** el sistema validará el formato del identificador, determinará que es inválido, mostrará el mensaje de error con el código `MOD_V_ID_ERR_00013` y solicitará al usuario que corrija el dato ingresado. | `MOD_V_ID_ERR_00013` | ✅ Aceptado |
| ACTI-CA4 | ❌ Error | **Dado que** un Administrador del Sistema desea activar una aerolínea, **cuando** el sistema no pueda completar la operación debido a una falla interna, **entonces** el sistema detectará la condición de error, mostrará el mensaje con el código `GEN_SRV_ERR_00001` indicando que el servicio no está disponible temporalmente y sugerirá al usuario intentar nuevamente más tarde. | `GEN_SRV_ERR_00001` | ✅ Aceptado |

---

## Archivos Principales Modificados

| Categoría | Archivos |
|-----------|----------|
| **Handlers** | `airline_controller.go`, `airline.go`, `handler.go` |
| **Interactor** | `interactor_airline.go` |
| **Services** | `airline_services.go` |
| **Domain** | `domain/employee.go` (Airline struct), `domain/erros.go` |
| **Ports** | `input/service.go`, `output/repository.go` |
| **Repository** | `repositories/airline/` (repository.go, get_airline_by_id.go, update_status.go) |
| **Logger** | `log_messages.go` |

---

## Notas de Release

1. Este release implementa la gestión básica de aerolíneas: consulta y cambio de estado.
2. Los endpoints aceptan tanto UUID directo como ID ofuscado para mayor flexibilidad.
3. Se utiliza el patrón PATCH para las operaciones de activar/desactivar (operación parcial sobre recurso).
4. La arquitectura sigue el patrón hexagonal establecido: Handler → Interactor → Service → Repository.
