# Release 01 - Módulo de Empleado Completo

## Información General

| Campo | Valor |
|-------|-------|
| **Versión** | v0.2.0 |
| **Rama** | develop |
| **Sprint** | Sprint 1 |
| **Horas Planificadas** | 32 horas |
| **Pull Requests** | #13, #14 |

---

## Historias de Usuario Incluidas

| Código | Historia de Usuario | Talla | Horas | Full Stack |
|--------|---------------------|-------|-------|------------|
| HU20 | Consultar la Información del Empleado | XS | 2 | 🟡 |
| HU25 | Modificar la Información del Empleado | XL | 32 | 🟡 |
| HU21 | Restablecer la Contraseña del Empleado | XL | 32 | ✅ |
| HU22 | Modificar la Clave del Empleado | XL | 32 | ✅ |
| HU23 | Autenticar la Información del Empleado | XL | 32 | ✅ |

---

## Componentes Implementados

### 1. Consultar Empleado (HU20)
- Endpoint: `GET /flighthours/api/v1/employees/:id`
- Acepta UUID o ID ofuscado
- No expone contraseña del usuario

### 2. Modificar Empleado (HU25)
- Endpoint: `PUT /flighthours/api/v1/employees/:id`
- Validación con JSON Schema
- Sincroniza estado active y role con Keycloak
- No modifica email ni password

### 3. Autenticación (HU23)
- Endpoint: `POST /flighthours/api/v1/login`
- Verifica email verificado antes de login
- Retorna tokens JWT (access, refresh)

### 4. Restablecer Contraseña (HU21)
- Endpoint Solicitud: `POST /flighthours/api/v1/auth/password-reset`
- Endpoint Actualización: `POST /flighthours/api/v1/auth/update-password`
- Envía email con instrucciones de recuperación
- Valida token recibido por email para actualizar
- No revela si el email existe (seguridad)

### 5. Modificar Clave (HU22)
- Endpoint: `POST /flighthours/api/v1/auth/change-password`
- Usuario autenticado cambia su contraseña conociendo la actual
- No requiere salir de la API ni token por email
- Valida contraseña actual antes de permitir el cambio

### 6. Funcionalidades Adicionales
- `POST /auth/resend-verification` - Reenviar verificación
- `POST /auth/verify-email` - Verificar email con token

---

## Escenarios de Prueba

### HU20 - Consultar la Información del Empleado

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| EMP-CA1 | ✅ Éxito | **Dado que** un Usuario del Sistema desea consultar la información de un empleado, **cuando** acceda a la funcionalidad de consulta de empleados, ingrese un identificador válido y confirme la acción, **entonces** el sistema recuperará la información correspondiente, mostrará los datos del empleado de manera estructurada (sin exponer información sensible como la contraseña), desplegará el mensaje satisfactorio con el código `MOD_U_GET_EXI_00005` y permitirá al usuario continuar navegando en el sistema. | `MOD_U_GET_EXI_00005` | ✅ Aceptado |
| EMP-CA2 | ❌ Error | **Dado que** un Usuario del Sistema desea consultar la información de un empleado, **cuando** ingrese un identificador que no corresponde a ningún empleado registrado en el sistema, **entonces** el sistema validará que el empleado no existe, mostrará el mensaje de error con el código `MOD_U_GET_ERR_00003` y no permitirá continuar con la consulta. | `MOD_U_GET_ERR_00003` | ✅ Aceptado |
| EMP-CA3 | ❌ Error | **Dado que** un Usuario del Sistema desea consultar la información de un empleado, **cuando** ingrese un identificador con formato incorrecto o inválido, **entonces** el sistema validará el formato del identificador, determinará que es inválido, mostrará el mensaje de error con el código `MOD_V_ID_ERR_00013` y solicitará al usuario que corrija el dato ingresado. | `MOD_V_ID_ERR_00013` | ✅ Aceptado |
| EMP-CA4 | ❌ Error | **Dado que** un Usuario del Sistema desea consultar la información de un empleado, **cuando** el sistema no pueda completar la operación debido a una falla interna, **entonces** el sistema detectará la condición de error, mostrará el mensaje con el código `GEN_SRV_ERR_00001` indicando que el servicio no está disponible temporalmente y sugerirá al usuario intentar nuevamente más tarde. | `GEN_SRV_ERR_00001` | ✅ Aceptado |

### HU25 - Modificar la Información del Empleado

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| UPD-CA1 | ✅ Éxito | **Dado que** un Administrador del Sistema desea modificar la información de un empleado, **cuando** acceda a la funcionalidad de edición de empleados, complete correctamente todos los campos permitidos (nombre, aerolínea asignada, número de identificación, fechas, rol y estado) y confirme la acción, **entonces** el sistema validará la información ingresada, actualizará el registro del empleado, sincronizará los cambios necesarios en el sistema de autenticación, mostrará el mensaje satisfactorio con el código `MOD_U_UPD_EXI_00002` y actualizará la vista para reflejar los cambios realizados. | `MOD_U_UPD_EXI_00002` | ✅ Aceptado |
| UPD-CA2 | ✅ Éxito | **Dado que** un Administrador del Sistema desea modificar el estado de un empleado, **cuando** cambie el estado del empleado de activo a inactivo, **entonces** el sistema deshabilitará el acceso del empleado al sistema, sincronizará el cambio con el sistema de autenticación, mostrará el mensaje satisfactorio correspondiente y reflejará el nuevo estado en la vista del empleado. | N/A | ✅ Aceptado |
| UPD-CA3 | ✅ Éxito | **Dado que** un Administrador del Sistema desea modificar el rol de un empleado, **cuando** cambie el rol asignado al empleado, **entonces** el sistema actualizará los permisos del empleado, sincronizará el nuevo rol con el sistema de autenticación, mostrará el mensaje satisfactorio correspondiente y reflejará el nuevo rol en la vista del empleado. | N/A | ✅ Aceptado |
| UPD-CA4 | ❌ Error | **Dado que** un Administrador del Sistema desea modificar la información de un empleado, **cuando** seleccione una aerolínea que no se encuentra registrada en el sistema, **entonces** el sistema validará la información de la aerolínea, determinará que no existe, mostrará el mensaje de error con el código `MOD_V_FK_ERR_00014` y solicitará al usuario que seleccione una aerolínea válida. | `MOD_V_FK_ERR_00014` | ✅ Aceptado |
| UPD-CA5 | ❌ Error | **Dado que** un Administrador del Sistema desea modificar la información de un empleado, **cuando** ingrese datos que excedan la longitud máxima permitida en algún campo, **entonces** el sistema validará los datos, detectará que exceden el límite, mostrará el mensaje de error con el código `MOD_V_LEN_ERR_00015` y solicitará al usuario que corrija los datos ingresados. | `MOD_V_LEN_ERR_00015` | ✅ Aceptado |

### HU23 - Autenticar la Información del Empleado

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| LOG-CA1 | ✅ Éxito | **Dado que** un Empleado Registrado desea iniciar sesión en el sistema, **cuando** acceda a la pantalla de inicio de sesión, ingrese su correo electrónico y contraseña correctos, y su correo electrónico se encuentre verificado, **entonces** el sistema autenticará al usuario, generará las credenciales de sesión correspondientes, mostrará el mensaje satisfactorio con el código `MOD_KC_LOGIN_SUCCESS_EXI_00001` y redirigirá al usuario a la pantalla principal del sistema. | `MOD_KC_LOGIN_SUCCESS_EXI_00001` | ✅ Aceptado |
| LOG-CA2 | ❌ Error | **Dado que** un Empleado Registrado desea iniciar sesión en el sistema, **cuando** ingrese su correo electrónico y contraseña correctos pero su correo electrónico aún no haya sido verificado, **entonces** el sistema detectará que el correo no está verificado, reenviará automáticamente el correo de verificación, mostrará el mensaje con el código `MOD_KC_LOGIN_EMAIL_NOT_VERIFIED_ERR_00001` indicando que debe verificar su correo electrónico y no permitirá el acceso al sistema hasta completar la verificación. | `MOD_KC_LOGIN_EMAIL_NOT_VERIFIED_ERR_00001` | ✅ Aceptado |
| LOG-CA3 | ❌ Error | **Dado que** un Usuario desea iniciar sesión en el sistema, **cuando** ingrese credenciales incorrectas (correo electrónico o contraseña erróneos), **entonces** el sistema validará las credenciales, determinará que son incorrectas, mostrará un mensaje genérico de acceso no autorizado con el código `GEN_AUTH_ERR_00002` y no permitirá el acceso al sistema. | `GEN_AUTH_ERR_00002` | ✅ Aceptado |
| LOG-CA4 | ❌ Error | **Dado que** un Usuario desea iniciar sesión en el sistema, **cuando** ingrese un correo electrónico que no se encuentra registrado, **entonces** el sistema mostrará el mismo mensaje genérico de acceso no autorizado con el código `GEN_AUTH_ERR_00002` (por razones de seguridad no revelará si el correo existe o no) y no permitirá el acceso al sistema. | `GEN_AUTH_ERR_00002` | ✅ Aceptado |

### HU21 - Restablecer la Contraseña del Empleado

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| RST-CA1 | ✅ Éxito | **Dado que** un Empleado olvidó su contraseña y desea restablecerla, **cuando** acceda a la funcionalidad de recuperación de contraseña, ingrese su correo electrónico registrado y confirme la solicitud, **entonces** el sistema enviará un correo electrónico con las instrucciones para restablecer la contraseña, mostrará el mensaje satisfactorio con el código `MOD_KC_PWD_RESET_SENT_EXI_00001` y permitirá al usuario consultar su bandeja de entrada para continuar con el proceso. | `MOD_KC_PWD_RESET_SENT_EXI_00001` | ✅ Aceptado |
| RST-CA2 | ⚠️ Alternativo | **Dado que** un Usuario desea restablecer su contraseña, **cuando** ingrese un correo electrónico que no se encuentra registrado en el sistema, **entonces** el sistema mostrará el mismo mensaje de éxito con el código `MOD_KC_PWD_RESET_SENT_EXI_00001` (por razones de seguridad no revelará si el correo existe o no) y sugerirá al usuario verificar su bandeja de entrada. | `MOD_KC_PWD_RESET_SENT_EXI_00001` | ✅ Aceptado |
| RST-CA3 | ❌ Error | **Dado que** un Usuario desea restablecer su contraseña, **cuando** ingrese un correo electrónico con formato incorrecto o inválido, **entonces** el sistema validará el formato del correo, determinará que es inválido, mostrará el mensaje de error con el código `MOD_V_VAL_ERR_00001` y solicitará al usuario que ingrese un correo electrónico válido. | `MOD_V_VAL_ERR_00001` | ✅ Aceptado |
| RST-CA4 | ⚠️ Alternativo | **Dado que** un Usuario desea restablecer su contraseña, **cuando** el servicio de envío de correos no esté disponible temporalmente, **entonces** el sistema mostrará el mismo mensaje de éxito con el código `MOD_KC_PWD_RESET_SENT_EXI_00001` (por razones de seguridad) y registrará internamente la incidencia para su seguimiento. | `MOD_KC_PWD_RESET_SENT_EXI_00001` | ✅ Aceptado |
| RST-CA5 | ✅ Éxito | **Dado que** un Empleado recibió el correo de recuperación de contraseña, **cuando** acceda al enlace de recuperación, ingrese el token de verificación válido, la nueva contraseña y la confirmación de la misma de manera coincidente, **entonces** el sistema validará la información, actualizará la contraseña del empleado, mostrará el mensaje satisfactorio con el código `MOD_KC_PWD_UPDATED_EXI_00001` y redirigirá al usuario a la pantalla de inicio de sesión. | `MOD_KC_PWD_UPDATED_EXI_00001` | ✅ Aceptado |
| RST-CA6 | ❌ Error | **Dado que** un Empleado desea actualizar su contraseña mediante el enlace de recuperación, **cuando** la nueva contraseña ingresada no coincida con la confirmación de la contraseña, **entonces** el sistema validará ambos campos, detectará la discrepancia, mostrará el mensaje de error con el código `MOD_KC_PWD_MISMATCH_ERR_00001` y solicitará al usuario que verifique e ingrese correctamente ambos campos. | `MOD_KC_PWD_MISMATCH_ERR_00001` | ✅ Aceptado |
| RST-CA7 | ❌ Error | **Dado que** un Empleado desea actualizar su contraseña mediante el enlace de recuperación, **cuando** el token de verificación sea inválido o haya expirado, **entonces** el sistema validará el token, determinará que no es válido o ha caducado, mostrará el mensaje de error con el código `MOD_KC_PWD_UPDATE_TOKEN_INVALID_ERR_00001` y sugerirá al usuario solicitar un nuevo correo de recuperación. | `MOD_KC_PWD_UPDATE_TOKEN_INVALID_ERR_00001` | ✅ Aceptado |
| RST-CA8 | ❌ Error | **Dado que** un Empleado desea actualizar su contraseña mediante el enlace de recuperación, **cuando** el sistema no pueda completar la operación debido a una falla interna, **entonces** el sistema detectará la condición de error, mostrará el mensaje con el código `MOD_KC_PWD_UPDATE_ERROR_ERR_00001` indicando que no se pudo actualizar la contraseña y sugerirá al usuario intentar nuevamente más tarde. | `MOD_KC_PWD_UPDATE_ERROR_ERR_00001` | ✅ Aceptado |

### HU22 - Modificar la Clave del Empleado

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| CHG-CA1 | ✅ Éxito | **Dado que** un Empleado Autenticado desea cambiar su contraseña sin salir de la aplicación, **cuando** acceda a la funcionalidad de cambio de contraseña, ingrese su correo electrónico, su contraseña actual correcta, la nueva contraseña y la confirmación de la misma de manera coincidente, **entonces** el sistema validará la contraseña actual, verificará que las nuevas contraseñas coincidan, actualizará la contraseña del empleado, mostrará el mensaje satisfactorio con el código `MOD_KC_PWD_CHANGED_EXI_00001` y permitirá al usuario continuar utilizando la aplicación con su nueva contraseña. | `MOD_KC_PWD_CHANGED_EXI_00001` | ✅ Aceptado |
| CHG-CA2 | ❌ Error | **Dado que** un Empleado Autenticado desea cambiar su contraseña, **cuando** ingrese una contraseña actual incorrecta, **entonces** el sistema validará la contraseña actual, determinará que no corresponde a la registrada en el sistema, mostrará el mensaje de error con el código `MOD_KC_PWD_CURRENT_INVALID_ERR_00001` y solicitará al usuario que ingrese la contraseña actual correcta. | `MOD_KC_PWD_CURRENT_INVALID_ERR_00001` | ✅ Aceptado |
| CHG-CA3 | ❌ Error | **Dado que** un Empleado Autenticado desea cambiar su contraseña, **cuando** la nueva contraseña ingresada no coincida con la confirmación de la contraseña, **entonces** el sistema validará ambos campos, detectará la discrepancia, mostrará el mensaje de error con el código `MOD_KC_PWD_CHANGE_MISMATCH_ERR_00001` y solicitará al usuario que verifique e ingrese correctamente ambos campos. | `MOD_KC_PWD_CHANGE_MISMATCH_ERR_00001` | ✅ Aceptado |
| CHG-CA4 | ❌ Error | **Dado que** un Empleado Autenticado desea cambiar su contraseña, **cuando** ingrese un correo electrónico que no se encuentra registrado en el sistema, **entonces** el sistema validará el correo, determinará que no corresponde a ningún usuario registrado, mostrará el mensaje de error con el código `MOD_KC_USER_NOT_FOUND_ERR_00001` y no permitirá continuar con la operación. | `MOD_KC_USER_NOT_FOUND_ERR_00001` | ✅ Aceptado |
| CHG-CA5 | ❌ Error | **Dado que** un Empleado Autenticado desea cambiar su contraseña, **cuando** el sistema no pueda completar la operación debido a una falla interna, **entonces** el sistema detectará la condición de error, mostrará el mensaje con el código `MOD_KC_PWD_CHANGE_ERROR_ERR_00001` indicando que no se pudo cambiar la contraseña y sugerirá al usuario intentar nuevamente más tarde. | `MOD_KC_PWD_CHANGE_ERROR_ERR_00001` | ✅ Aceptado |

---

## Archivos Principales Modificados

| Categoría | Archivos |
|-----------|----------|
| **Handlers** | `employee_controller.go`, `employee.go` |
| **Interactor** | `interactor.go` |
| **Services** | `employee_services.go`, `authorization_service.go` |
| **Middleware** | Schema validators para employee y password |
| **Platform** | Keycloak client, JWT utilities |

---

## Notas de Release

1. Este release implementa el **CRUD completo de empleado** (excepto DELETE que es HU24).
2. La autenticación verifica email verificado antes de permitir login.
3. El flujo de recuperación de contraseña es seguro (no revela existencia de emails).
4. Los cambios de estado y rol se sincronizan con Keycloak automáticamente.
