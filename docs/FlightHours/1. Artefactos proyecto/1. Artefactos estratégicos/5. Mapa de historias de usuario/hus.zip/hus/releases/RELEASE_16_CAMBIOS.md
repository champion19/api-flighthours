# Release 16: Catálogos Geográficos - Ciudad y País (Virtual Entity Pattern)

**Fecha**: 2026-01-20
**Estado**: ✅ Implementado (sin departamento)

## Resumen

Este release implementa las funcionalidades de consulta de Ciudad (HU13) y País (HU38) usando el **Patrón de Entidad Virtual** - reutilizando los campos `city` y `country` existentes en la tabla `airport` sin necesidad de crear nuevas tablas ni Foreign Keys, evitando así el consumo de JOINs.

## Endpoints Implementados

| Método | Endpoint | Descripción | Retorna |
|--------|----------|-------------|---------|
| `GET` | `/cities/{city_name}` | Obtiene aeropuertos de una ciudad | Lista de aeropuertos en esa ciudad |
| `GET` | `/countries/{country_name}` | Obtiene aeropuertos de un país | Lista de aeropuertos en ese país |

### Ejemplo de Uso

```bash
# Obtener aeropuertos en Bogota
GET /flighthours/api/v1/cities/Bogota

# Obtener aeropuertos en Colombia
GET /flighthours/api/v1/countries/Colombia
```

## Archivos Modificados/Creados

### Repository
| Archivo | Cambio |
|---------|--------|
| `platform/databases/repositories/airport/repository.go` | Nuevas queries y prepared statements |
| `platform/databases/repositories/airport/get_by_location.go` | **NUEVO** - Métodos `GetAirportsByCity` y `GetAirportsByCountry` |

### Ports (Interfaces)
| Archivo | Cambio |
|---------|--------|
| `core/ports/output/repository.go` | Nuevos métodos en `AirportRepository` interface |
| `core/ports/input/service.go` | Nuevos métodos en `AirportService` interface |

### Service & Interactor
| Archivo | Cambio |
|---------|--------|
| `core/interactor/services/airport_services.go` | Nuevos métodos `GetAirportsByCity` y `GetAirportsByCountry` |
| `core/interactor/interactor_airport.go` | Nuevos métodos del interactor |

### Handlers
| Archivo | Cambio |
|---------|--------|
| `handlers/airport_controller.go` | Nuevos handlers `GetAirportsByCity()` y `GetAirportsByCountry()` |

### Domain (Errores/Mensajes)
| Archivo | Cambio |
|---------|--------|
| `core/interactor/services/domain/erros.go` | Nuevos códigos de mensaje para Ciudad y País |

### Server (Rutas)
| Archivo | Cambio |
|---------|--------|
| `server/server.go` | Nuevas rutas públicas `/cities/:city_name` y `/countries/:country_name` |

### Tests
| Archivo | Cambio |
|---------|--------|
| `core/interactor/services/airport_services_test.go` | Mock actualizado |
| `core/interactor/airport_interactor_test.go` | Mock actualizado |
| `handlers/airport_http_test.go` | Mock actualizado |

### SQL
| Archivo | Cambio |
|---------|--------|
| `docs/sql/add_city_country_messages.sql` | **NUEVO** - Mensajes de éxito/error |

## Códigos de Mensaje

### Ciudad (HU13)
| Código | Tipo | HTTP | Descripción |
|--------|------|------|-------------|
| `CIU_CON_EXI_01301` | ✅ Éxito | 200 | Ciudad consultada exitosamente |
| `CIU_CON_ERR_01302` | ❌ Error | 404 | Ciudad no encontrada |
| `CIU_CON_ERR_01303` | ❌ Error | 500 | Error técnico |

### País (HU38)
| Código | Tipo | HTTP | Descripción |
|--------|------|------|-------------|
| `PAI_CON_EXI_03801` | ✅ Éxito | 200 | País consultado exitosamente |
| `PAI_CON_ERR_03802` | ❌ Error | 404 | País no encontrado |
| `PAI_CON_ERR_03803` | ❌ Error | 500 | Error técnico |

## Queries SQL

```sql
-- Ciudad: Obtener aeropuertos por ciudad
SELECT id, name, city, country, iata_code, status, airport_type
FROM airport WHERE city = ? ORDER BY name

-- País: Obtener aeropuertos por país
SELECT id, name, city, country, iata_code, status, airport_type
FROM airport WHERE country = ? ORDER BY name
```

## Notas Técnicas

1. **Sin nuevas tablas** - Se reutiliza la tabla `airport` existente
2. **Sin JOINs** - Consultas directas a la tabla `airport`
3. **Patrón Virtual Entity** - Similar a la implementación de `aircraft_family` (HU32)
4. **El ID es el nombre** - El parámetro de ruta es el nombre de la ciudad/país, no un UUID
5. **HATEOAS** - Las respuestas incluyen links de navegación
6. **Retorna `AirportListResponse`** - Reutiliza el DTO existente de aeropuertos

## HU14 - Departamento

**No se implementó** por decisión de diseño:
- El código IATA del aeropuerto ya contiene información geográfica completa
- No hay necesidad de crear una tabla intermedia `department`
- Evita complejidad adicional y JOINs innecesarios
