# Release 12: Detalle Bitácora Diaria - CRUD Completo (Core del Proyecto)

**Tag Git**: `v0.13.0`
**Estado**: ✅ Completado
**Total Horas**: 52h

## Historias de Usuario

| HU   | Descripción                                                    | Horas | Endpoint                                          | Estado | Full Stack |
| ---- | -------------------------------------------------------------- | ----- | ------------------------------------------------- | ------ | ---------- |
| HU15 | Consultar la Información de Detalle de la Bitácora Diaria      | 16h   | `GET /daily-logbook-details/{id}`                 | ✅     | ✅         |
| HU16 | Agregar la Información a Detalle Bitácora Diaria               | 16h   | `POST /daily-logbooks/{id}/details`               | ✅     | ✅         |
| HU17 | Editar la Información de Detalle Bitácora Diaria               | 16h   | `PUT /daily-logbook-details/{id}`                 | ✅     | ✅         |
| HU18 | Eliminar Información de un Detalle Bitácora Diaria             | 4h    | `DELETE /daily-logbook-details/{id}`              | ✅     | ✅         |

## Dependencias

- ✅ Release 5: Bitácora Diaria (FK daily_logbook_id)
- ✅ Release 6: Matrícula (FK actual_aircraft_registration_id)
- ✅ Release 10: Ruta Aerolínea (FK airline_route_id)
- ✅ Release 1: Empleado (FK employee_logbook_id)

## Estructura del Módulo Daily Logbook Detail

```
core/
├── interactor/
│   ├── interactor_daily_logbook_detail.go
│   └── services/
│       ├── daily_logbook_detail_services.go
│       └── domain/
│           └── daily_logbook_detail.go
handlers/
├── daily_logbook_detail.go              # DTOs y mappers
└── daily_logbook_detail_controller.go   # Handlers
platform/
└── databases/
    └── repositories/
        └── daily_logbook_detail/        # Repository con prepared statements
```

## Notas Técnicas

> 🎯 **CORE DEL PROYECTO**: Esta es la tabla principal que almacena los segmentos de vuelo.
> 📋 **daily_logbook_detail** contiene el detalle de cada segmento de vuelo dentro de una bitácora diaria.
> 🔗 **Relaciones Principales**:
>   - FK a `daily_logbook` (bitácora padre)
>   - FK a `airline_route` (ruta del vuelo)
>   - FK a `aircraft_registration` (aeronave utilizada)
>   - FK a `employee` (piloto que registra)
> 📊 **Campos de tiempo**: out_time, takeoff_time, landing_time, in_time (formato TIME HH:MM)
> 🧮 **Campos calculados**: air_time, block_time, duty_time (formato TIME HH:MM)
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.
> 🔑 **Dual-Format ID Resolution**: Acepta tanto UUID como ID ofuscado (HashID).

## Tabla de Base de Datos

```sql
CREATE TABLE daily_logbook_detail (
    id VARCHAR(36) NOT NULL,
    daily_logbook_id VARCHAR(36) NOT NULL,
    flight_real_date DATE NOT NULL,
    flight_number VARCHAR(36) NOT NULL,
    airline_route_id VARCHAR(36) NOT NULL,
    actual_aircraft_registration_id VARCHAR(36) NOT NULL,
    passengers INT,

    -- Tiempos de vuelo (formato TIME HH:MM)
    out_time TIME NOT NULL,
    takeoff_time TIME NOT NULL,
    landing_time TIME NOT NULL,
    in_time TIME NOT NULL,

    -- Rol del piloto
    pilot_role ENUM('PF', 'PM', 'PFTO', 'PFL') NOT NULL,
    companion_name VARCHAR(100) NULL,

    -- Tiempos calculados (formato TIME HH:MM)
    air_time TIME NOT NULL,
    block_time TIME NOT NULL,
    duty_time TIME NULL,

    -- Tipo de aproximación
    approach_type ENUM('NPA', 'PA', 'APV', 'VISUAL'),
    flight_type VARCHAR(20),
    employee_logbook_id VARCHAR(36),

    PRIMARY KEY(id),
    CONSTRAINT fk_detail_logbook FOREIGN KEY (daily_logbook_id) REFERENCES daily_logbook(id),
    CONSTRAINT fk_detail_airline_route FOREIGN KEY (airline_route_id) REFERENCES airline_route(id),
    CONSTRAINT fk_detail_aircraft_registration FOREIGN KEY (actual_aircraft_registration_id) REFERENCES aircraft_registration(id),
    CONSTRAINT fk_detail_main_employee FOREIGN KEY (employee_logbook_id) REFERENCES employee(id)
);
```

## Validaciones de Negocio

1. **Secuencia de tiempos**: out_time < takeoff_time < landing_time < in_time
2. **Rol de piloto**: Solo uno de los valores ENUM permitidos (PF, PM, PFTO, PFL)
3. **Tipo de aproximación**: Solo valores ENUM permitidos (NPA, PA, APV, VISUAL) o null
4. **Ownership**: Solo el empleado dueño de la bitácora puede agregar/editar/eliminar detalles

---

## Escenarios de Prueba

### HU15 - Consultar la Información de Detalle de la Bitácora Diaria

| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                             | Código Mensaje     | Estado      |
| ---------- | --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ----------- |
| CONVUE-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar la información de un Detalle de Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque un detalle válido, **entonces** el sistema mostrará correctamente los datos del vuelo incluyendo fecha, número de vuelo, tiempos, rol del piloto y aeronave, presentará la información en la vista correspondiente y mostrará al usuario final el mensaje satisfactorio `VUE_CON_EXI_04801`. | `VUE_CON_EXI_04801` | ✅ Aceptado |
| CONVUE-CA2 | ❌ Error  | **Dado** que un Piloto del Sistema quiere consultar la información de un Detalle de Bitácora Diaria, **cuando** intente realizar la consulta con un identificador que no existe en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `VUE_CON_ERR_04803` indicando que el vuelo no fue encontrado y permitirá realizar una nueva búsqueda.                                                                 | `VUE_CON_ERR_04803` | ✅ Aceptado |
| CONVUE-CA3 | ❌ Error  | **Dado** que un Piloto del Sistema quiere consultar la información de un Detalle de Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `VUE_CON_ERR_04804` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                  | `VUE_CON_ERR_04804` | ✅ Aceptado |

### HU16 - Agregar la Información a Detalle Bitácora Diaria

| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Código Mensaje     | Estado      |
| ---------- | --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ----------- |
| AGRVUE-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere agregar un Detalle a su Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente e ingrese correctamente todos los datos requeridos (fecha de vuelo, número de vuelo, ruta, aeronave, tiempos de vuelo, rol del piloto), **entonces** el sistema registrará exitosamente el nuevo detalle de vuelo, lo asociará correctamente a la bitácora correspondiente, mostrará al usuario final el mensaje satisfactorio `VUE_REG_EXI_05001` y se reflejará la información en la vista de detalles. | `VUE_REG_EXI_05001` | ✅ Aceptado |
| AGRVUE-CA2 | ❌ Error  | **Dado** que un Piloto del Sistema quiere agregar un Detalle a su Bitácora Diaria, **cuando** intente registrar un detalle en una bitácora que no le pertenece o no existe, **entonces** el sistema no guardará la información, mostrará al usuario final el mensaje de advertencia `VUE_VAL_ERR_04806` indicando que la bitácora es inválida y mantendrá el formulario activo para seleccionar una bitácora válida.                                                                | `VUE_VAL_ERR_04806` | ✅ Aceptado |
| AGRVUE-CA3 | ❌ Error  | **Dado** que un Piloto del Sistema quiere agregar un Detalle a su Bitácora Diaria, **cuando** seleccione una ruta de aerolínea que no existe o es inválida, **entonces** el sistema no guardará la información, mostrará al usuario final el mensaje de advertencia `VUE_VAL_ERR_04805` indicando que la ruta seleccionada no es válida y mantendrá el formulario abierto para seleccionar una ruta correcta.                                                                                                        | `VUE_VAL_ERR_04805` | ✅ Aceptado |
| AGRVUE-CA4 | ❌ Error  | **Dado** que un Piloto del Sistema quiere agregar un Detalle a su Bitácora Diaria, **cuando** seleccione una matrícula de aeronave que no existe o es inválida, **entonces** el sistema no guardará la información, mostrará al usuario final el mensaje de advertencia `VUE_VAL_ERR_04807` indicando que la matrícula seleccionada no es válida y mantendrá el formulario abierto para seleccionar una matrícula correcta.                                                                                                  | `VUE_VAL_ERR_04807` | ✅ Aceptado |
| AGRVUE-CA5 | ❌ Error  | **Dado** que un Piloto del Sistema quiere agregar un Detalle a su Bitácora Diaria, **cuando** ingrese tiempos de vuelo que no sigan la secuencia correcta (out < takeoff < landing < in), **entonces** el sistema no guardará la información, mostrará al usuario final el mensaje de advertencia `VUE_VAL_ERR_04808` indicando que la secuencia de tiempos es inválida y mantendrá el formulario abierto para corregir los tiempos.                                                                                                  | `VUE_VAL_ERR_04808` | ✅ Aceptado |
| AGRVUE-CA6 | ❌ Error  | **Dado** que un Piloto del Sistema quiere agregar un Detalle a su Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso (como un fallo en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `VUE_REG_ERR_05004` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                                                                                           | `VUE_REG_ERR_05004` | ✅ Aceptado |

### HU17 - Editar la Información de Detalle Bitácora Diaria

| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                              | Código Mensaje     | Estado      |
| ---------- | --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------- | ----------- |
| EDIVUE-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere editar la información de un Detalle de su Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente, seleccione un detalle válido e ingrese correctamente los datos a modificar, **entonces** el sistema guardará los cambios exitosamente, mostrará al usuario final el mensaje satisfactorio `VUE_EDI_EXI_04901` y reflejará la información actualizada en la vista de detalles. | `VUE_EDI_EXI_04901` | ✅ Aceptado |
| EDIVUE-CA2 | ❌ Error  | **Dado** que un Piloto del Sistema quiere editar la información de un Detalle de Bitácora Diaria, **cuando** intente modificar un detalle que no existe en el sistema, **entonces** el sistema no permitirá continuar, mostrará al usuario final el mensaje de advertencia `VUE_CON_ERR_04803` indicando que el vuelo no fue encontrado y permitirá seleccionar otro registro.                                                        | `VUE_CON_ERR_04803` | ✅ Aceptado |
| EDIVUE-CA3 | ❌ Error  | **Dado** que un Piloto del Sistema quiere editar la información de un Detalle de Bitácora Diaria, **cuando** intente modificar un detalle que pertenece a una bitácora de otro piloto, **entonces** el sistema no permitirá la operación, mostrará al usuario final el mensaje de error `VUE_AUTH_ERR_00001` indicando que no está autorizado para esta acción.                                                        | `VUE_AUTH_ERR_00001` | ✅ Aceptado |
| EDIVUE-CA4 | ❌ Error  | **Dado** que un Piloto del Sistema quiere editar la información de un Detalle de Bitácora Diaria, **cuando** seleccione una ruta de aerolínea que no existe o es inválida, **entonces** el sistema no guardará los cambios, mostrará al usuario final el mensaje de advertencia `VUE_VAL_ERR_04805` indicando que la ruta seleccionada no es válida y mantendrá el formulario abierto para seleccionar una ruta correcta.     | `VUE_VAL_ERR_04805` | ✅ Aceptado |
| EDIVUE-CA5 | ❌ Error  | **Dado** que un Piloto del Sistema quiere editar la información de un Detalle de Bitácora Diaria, **cuando** seleccione una matrícula de aeronave que no existe o es inválida, **entonces** el sistema no guardará los cambios, mostrará al usuario final el mensaje de advertencia `VUE_VAL_ERR_04807` indicando que la matrícula seleccionada no es válida y mantendrá el formulario abierto para seleccionar una matrícula correcta.               | `VUE_VAL_ERR_04807` | ✅ Aceptado |
| EDIVUE-CA6 | ❌ Error  | **Dado** que un Piloto del Sistema quiere editar la información de un Detalle de Bitácora Diaria, **cuando** ingrese tiempos de vuelo que no sigan la secuencia correcta, **entonces** el sistema no guardará los cambios, mostrará al usuario final el mensaje de advertencia `VUE_VAL_ERR_04808` indicando que la secuencia de tiempos es inválida.    | `VUE_VAL_ERR_04808` | ✅ Aceptado |
| EDIVUE-CA7 | ❌ Error  | **Dado** que un Piloto del Sistema quiere editar la información de un Detalle de Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso, **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `VUE_EDI_ERR_04904` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.    | `VUE_EDI_ERR_04904` | ✅ Aceptado |

### HU18 - Eliminar Información de un Detalle Bitácora Diaria

| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                              | Código Mensaje     | Estado      |
| ---------- | --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------- | ----------- |
| DELVUE-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere eliminar un Detalle de su Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente, seleccione un detalle válido y confirme la eliminación, **entonces** el sistema eliminará el registro exitosamente y mostrará al usuario final el mensaje satisfactorio `VUE_DEL_EXI_01801`. | `VUE_DEL_EXI_01801` | ✅ Aceptado |
| DELVUE-CA2 | ❌ Error  | **Dado** que un Piloto del Sistema quiere eliminar un Detalle de Bitácora Diaria, **cuando** intente eliminar un detalle que no existe en el sistema, **entonces** el sistema no permitirá continuar, mostrará al usuario final el mensaje de advertencia `VUE_DEL_ERR_01803` indicando que el vuelo no existe o ya fue eliminado.                                                        | `VUE_DEL_ERR_01803` | ✅ Aceptado |
| DELVUE-CA3 | ❌ Error  | **Dado** que un Piloto del Sistema quiere eliminar un Detalle de Bitácora Diaria, **cuando** intente eliminar un detalle que pertenece a una bitácora de otro piloto, **entonces** el sistema no permitirá la operación, mostrará al usuario final el mensaje de error `VUE_AUTH_ERR_00001` indicando que no está autorizado para esta acción.                                                        | `VUE_AUTH_ERR_00001` | ✅ Aceptado |
| DELVUE-CA4 | ❌ Error  | **Dado** que un Piloto del Sistema quiere eliminar un Detalle de Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso, **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `VUE_DEL_ERR_01804` y recomendará intentar nuevamente más tarde.    | `VUE_DEL_ERR_01804` | ✅ Aceptado |

### Listar Detalles por Bitácora (Funcionalidad adicional)

| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                    | Código Mensaje      | Estado      |
| ---------- | --------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- | ----------- |
| LSTVUE-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar el listado de Detalles de una Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente y seleccione una bitácora válida, **entonces** el sistema mostrará el listado completo de vuelos con sus datos asociados (fecha, número de vuelo, tiempos, ruta, aeronave), presentará la información en la vista correspondiente y mostrará el mensaje satisfactorio `VUE_LIST_EXI_04800`. | `VUE_LIST_EXI_04800` | ✅ Aceptado |
| LSTVUE-CA2 | ❌ Error  | **Dado** que un Piloto del Sistema quiere consultar el listado de Detalles de una Bitácora Diaria, **cuando** intente acceder a una bitácora que no le pertenece, **entonces** el sistema no permitirá la operación, mostrará al usuario final el mensaje de error `VUE_AUTH_ERR_00001` indicando que no está autorizado.                                                                                                                         | `VUE_AUTH_ERR_00001` | ✅ Aceptado |
| LSTVUE-CA3 | ❌ Error  | **Dado** que un Piloto del Sistema quiere consultar el listado de Detalles de una Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso, **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error `VUE_LIST_ERR_04802` y recomendará intentar nuevamente más tarde.                                                                                                         | `VUE_LIST_ERR_04802` | ✅ Aceptado |

---

## Archivos Principales Modificados

| Categoría     | Archivos                                                                                                                   |
| -------------- | -------------------------------------------------------------------------------------------------------------------------- |
| **Handlers**   | `daily_logbook_detail_controller.go`, `daily_logbook_detail.go`, `handler.go`, `hateoas.go`                               |
| **Interactor** | `interactor_daily_logbook_detail.go`                                                                                       |
| **Services**   | `daily_logbook_detail_services.go`                                                                                         |
| **Domain**     | `domain/daily_logbook_detail.go`, `domain/erros.go`                                                                        |
| **Ports**      | `input/service.go`, `output/repository.go`                                                                                 |
| **Repository** | `repositories/daily_logbook_detail/` (daily_logbook_detail.go, repository.go, get_by_id.go, list_by_logbook.go, save.go, update.go, delete.go) |
| **Logger**     | `log_messages.go`                                                                                                          |
| **Cache**      | `platform/cache/messaging/cache.go`                                                                                        |
| **Dependency** | `cmd/dependency/dependency.go`                                                                                             |
| **Server**     | `server/server.go`                                                                                                         |

---

## Códigos de Mensaje Implementados

### Mensajes de Éxito en errors.go

| Constante                   | Código              | Tipo   |
| --------------------------- | -------------------- | ------ |
| `MsgFlightGetOK`            | `VUE_CON_EXI_04801`  | Éxito |
| `MsgFlightUpdated`          | `VUE_EDI_EXI_04901`  | Éxito |
| `MsgFlightCreated`          | `VUE_REG_EXI_05001`  | Éxito |
| `MsgFlightListOK`           | `VUE_LIST_EXI_04800` | Éxito |
| `MsgFlightDeleted`          | `VUE_DEL_EXI_01801`  | Éxito |

### Mensajes de Error en errors.go

| Constante                       | Código               | Tipo  |
| ------------------------------- | --------------------- | ----- |
| `MsgFlightNotSelected`          | `VUE_CON_ERR_04802`   | Error |
| `MsgFlightNotFound`             | `VUE_CON_ERR_04803`   | Error |
| `MsgFlightGetError`             | `VUE_CON_ERR_04804`   | Error |
| `MsgFlightUpdateNotSelected`    | `VUE_EDI_ERR_04902`   | Error |
| `MsgFlightInvalidData`          | `VUE_EDI_ERR_04903`   | Error |
| `MsgFlightUpdateError`          | `VUE_EDI_ERR_04904`   | Error |
| `MsgFlightRequiredFields`       | `VUE_REG_ERR_05002`   | Error |
| `MsgFlightInvalidFormat`        | `VUE_REG_ERR_05003`   | Error |
| `MsgFlightSaveError`            | `VUE_REG_ERR_05004`   | Error |
| `MsgFlightListError`            | `VUE_LIST_ERR_04802`  | Error |
| `MsgFlightInvalidRoute`         | `VUE_VAL_ERR_04805`   | Error |
| `MsgFlightInvalidLogbook`       | `VUE_VAL_ERR_04806`   | Error |
| `MsgFlightInvalidAircraft`      | `VUE_VAL_ERR_04807`   | Error |
| `MsgFlightInvalidTimeSequence`  | `VUE_VAL_ERR_04808`   | Error |
| `MsgFlightUnauthorized`         | `VUE_AUTH_ERR_00001`  | Error |
| `MsgFlightDeleteNotSelected`    | `VUE_DEL_ERR_01802`   | Error |
| `MsgFlightDeleteNotFound`       | `VUE_DEL_ERR_01803`   | Error |
| `MsgFlightDeleteError`          | `VUE_DEL_ERR_01804`   | Error |

### Errores de Dominio en errors.go

| Variable                         | Código de Error                        |
| -------------------------------- | --------------------------------------- |
| `ErrFlightNotFound`              | `ERR_FLIGHT_NOT_FOUND`                  |
| `ErrFlightCannotSave`            | `ERR_FLIGHT_CANNOT_SAVE`                |
| `ErrFlightCannotUpdate`          | `ERR_FLIGHT_CANNOT_UPDATE`              |
| `ErrFlightCannotDelete`          | `ERR_FLIGHT_CANNOT_DELETE`              |
| `ErrFlightInvalidLogbook`        | `ERR_FLIGHT_INVALID_LOGBOOK`            |
| `ErrFlightInvalidRoute`          | `ERR_FLIGHT_INVALID_ROUTE`              |
| `ErrFlightInvalidAircraft`       | `ERR_FLIGHT_INVALID_AIRCRAFT`           |
| `ErrFlightInvalidTimeSequence`   | `ERR_FLIGHT_INVALID_TIME_SEQUENCE`      |
| `ErrFlightUnauthorized`          | `ERR_FLIGHT_UNAUTHORIZED`               |

### Mapeo HTTP Status en cache.go

| Código               | HTTP Status | Descripción                            |
| --------------------- | ----------- | --------------------------------------- |
| `VUE_CON_EXI_04801`   | 200         | Vuelo consultado exitosamente           |
| `VUE_CON_ERR_04803`   | 404         | Vuelo no encontrado                     |
| `VUE_CON_ERR_04804`   | 500         | Error técnico al consultar              |
| `VUE_REG_EXI_05001`   | 201         | Vuelo creado exitosamente               |
| `VUE_REG_ERR_05004`   | 400         | Error al crear vuelo                    |
| `VUE_EDI_EXI_04901`   | 200         | Vuelo actualizado exitosamente          |
| `VUE_EDI_ERR_04904`   | 400         | Error al actualizar vuelo               |
| `VUE_DEL_EXI_01801`   | 200         | Vuelo eliminado exitosamente            |
| `VUE_DEL_ERR_01803`   | 404         | Vuelo no existe o ya fue eliminado      |
| `VUE_DEL_ERR_01804`   | 500         | Error técnico al eliminar               |
| `VUE_LIST_EXI_04800`  | 200         | Lista obtenida exitosamente             |
| `VUE_LIST_ERR_04802`  | 500         | Error al listar                         |
| `VUE_VAL_ERR_04805`   | 400         | Ruta de aerolínea inválida              |
| `VUE_VAL_ERR_04806`   | 400         | Bitácora diaria inválida                |
| `VUE_VAL_ERR_04807`   | 400         | Matrícula de aeronave inválida          |
| `VUE_VAL_ERR_04808`   | 400         | Secuencia de tiempos inválida           |
| `VUE_AUTH_ERR_00001`  | 403         | No autorizado para esta operación       |

---

## Notas de Release

1. Este release implementa el CRUD completo de Detalle de Bitácora Diaria (Daily Logbook Detail): consultar, agregar, actualizar, eliminar y listar.
2. **CORE DEL PROYECTO**: Esta es la tabla principal que almacena los segmentos de vuelo individual de cada piloto.
3. Todos los endpoints están protegidos y requieren autenticación JWT.
4. Los endpoints aceptan tanto UUID directo como ID ofuscado (HashID) para mayor flexibilidad.
5. Se validan las referencias a tablas relacionadas (airline_route, aircraft_registration, daily_logbook) antes de guardar.
6. Se implementa **verificación de ownership**: solo el dueño de la bitácora puede agregar/editar/eliminar detalles.
7. Se valida la secuencia de tiempos (out < takeoff < landing < in) antes de guardar.
8. La respuesta incluye datos denormalizados (`route_code`, `license_plate`, `model_name`, `airline_code`) obtenidos mediante JOINs SQL.
9. La arquitectura sigue el patrón hexagonal establecido: Handler → Interactor → Service → Repository.
10. Se implementa HATEOAS (Richardson Maturity Model Level 3) para navegación entre recursos relacionados.
11. Los tiempos se manejan en formato TIME (HH:MM o HH:MM:SS) para compatibilidad con MySQL.
12. Los errores de FK constraint de MySQL se mapean a errores específicos del módulo.
