# Release 00 - Infraestructura Base y Registro de Empleado

## Información General

| Campo | Valor |
|-------|-------|
| **Versión** | v0.1.0 |
| **Tag Git** | `v0.1.0` |
| **Rama** | main |
| **Sprint** | Sprint 0 (Base) |
| **Horas Planificadas** | 32 horas |
| **Pull Requests** | #1, #2, #3, #4, #8, #10, #11, #12 |

---

## Historias de Usuario Incluidas

| Código | Historia de Usuario | Talla | Horas | Full Stack |
|--------|---------------------|-------|-------|------------|
| HU19 | Agregar la información del Empleado (Registro) | XS | 2 | ✅ |

---

## Componentes Implementados

### 1. Registro de Empleado (HU19)
- Endpoint: `POST /flighthours/api/v1/register`
- Validación con JSON Schema
- Integración con Keycloak
- Proceso transaccional con base de datos

### 2. Sistema de Mensajes (CRUD)
- `POST /messages` - Crear mensaje
- `PUT /messages/:id` - Actualizar mensaje
- `DELETE /messages/:id` - Eliminar mensaje
- `GET /messages/:id` - Obtener mensaje
- `GET /messages` - Listar mensajes
- `POST /messages/cache/reload` - Recargar caché

### 3. Infraestructura
- Arquitectura Hexagonal (ports/adapters)
- Interactor pattern
- Cache de mensajes
- Logger centralizado con Trace ID
- Prometheus + Grafana
- Swagger Documentation
- Docker Compose configurations

---

## Escenarios de Prueba

### HU19 - Agregar la Información del Empleado

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| REG-CA1 | ✅ Éxito | **Dado que** un Representante de Sede desea registrarse en el sistema, **cuando** acceda a la funcionalidad de registro, complete correctamente todos los campos obligatorios (nombre, correo electrónico, contraseña), acepte los términos y condiciones y confirme la acción, **entonces** el sistema validará la información ingresada, creará el registro correspondiente, enviará un correo electrónico de verificación a la dirección proporcionada, mostrará el mensaje satisfactorio con el código `MOD_U_REG_EXI_00001` y redirigirá al usuario a la pantalla de inicio de sesión o confirmación de cuenta. | `MOD_U_REG_EXI_00001` | ✅ Aceptado |
| REG-CA2 | ❌ Error | **Dado que** un Representante de Sede desea registrarse en el sistema, **cuando** ingrese un correo electrónico que ya se encuentra registrado en el sistema, **entonces** el sistema validará la unicidad del correo electrónico, determinará que ya existe una cuenta asociada, mostrará el mensaje de error con el código `MOD_U_DUP_ERR_00001` indicando que el correo ya está en uso y solicitará al usuario que utilice un correo diferente o recupere su contraseña si olvidó sus credenciales. | `MOD_U_DUP_ERR_00001` | ✅ Aceptado |
| REG-CA3 | ❌ Error | **Dado que** un Representante de Sede desea registrarse en el sistema, **cuando** ingrese datos con formato incorrecto (correo electrónico mal formado, contraseña que no cumple los requisitos de seguridad, campos vacíos), **entonces** el sistema validará el formato de los datos, detectará las inconsistencias, mostrará el mensaje de error con el código `MOD_V_VAL_ERR_00001` indicando los campos que requieren corrección y solicitará al usuario que verifique la información ingresada. | `MOD_V_VAL_ERR_00001` | ✅ Aceptado |
| REG-CA4 | ❌ Error | **Dado que** un Representante de Sede desea registrarse en el sistema, **cuando** el sistema no pueda completar la operación debido a una falla interna o el servicio de autenticación no esté disponible, **entonces** el sistema detectará la condición de error, revertirá cualquier cambio parcial realizado, mostrará el mensaje con el código `GEN_SRV_ERR_00001` indicando que el servicio no está disponible temporalmente y sugerirá al usuario intentar nuevamente más tarde. | `GEN_SRV_ERR_00001` | ✅ Aceptado |

---

## Archivos Principales Modificados

| Categoría | Archivos |
|-----------|----------|
| **Core** | `core/interactor/`, `core/ports/`, `core/interactor/services/` |
| **Handlers** | `employee_controller.go`, `message_controller.go`, `handler.go` |
| **Middleware** | Error handler, Request ID, Prometheus metrics |
| **Platform** | Logger, Cache, Schema validation |
| **Config** | Docker Compose (Grafana, Swagger), Prometheus |
| **Tests** | `*_test.go` en interactor, services, handlers |

---

## Notas de Release

1. Este release establece la **base arquitectónica** del proyecto usando arquitectura hexagonal.
2. El registro de empleados está completamente funcional con integración Keycloak.
3. El sistema de mensajes permite gestionar todos los mensajes de la aplicación desde la BD.
4. Se implementó monitoreo con Prometheus y visualización con Grafana.
