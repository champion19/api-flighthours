# Release 9: Ruta (Route) - Consulta

**Tag Git**: `v0.10.0`
**Estado**: ✅ Implementado
**Total Horas**: 8h

## Historias de Usuario

| HU   | Descripción                        | Horas | Endpoint              | Estado | Full Stack |
| ---- | ---------------------------------- | ----- | --------------------- | ------ | ---------- |
| HU39 | Consultar Información Ruta         | 8h    | `GET /routes/{id}`    | ✅     | ✅         |

## Dependencias

- ✅ Release 4: Aeropuerto (FK origin_airport_id, destination_airport_id)

## Estructura del Módulo Route

```
core/
├── interactor/
│   ├── interactor_route.go
│   └── services/
│       ├── route_services.go
│       └── domain/
│           └── route.go
handlers/
├── route.go              # DTOs y mappers
└── route_controller.go   # Handlers
platform/
└── databases/
    └── repositories/
        └── route/        # Repository con prepared statements
```

## Notas Técnicas

> 📋 **route** define una ruta entre dos aeropuertos (origen-destino).
> 🔗 **Relaciones**: FK a `airport` (origin_airport_id y destination_airport_id)
> 📊 **Campos desnormalizados**: origin_country, destination_country (obtenidos de airport.country para consultas rápidas)
> ✈️ **airport_type**: Tipo de aeropuerto de la ruta (Nacional/Internacional)
> ⏱️ **estimated_flight_time**: Tiempo estimado de vuelo en minutos (INT)
> � **Clave única**: Combinación origin_airport_id + destination_airport_id es única (evita rutas duplicadas)
> �🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.
> 🔑 **Dual-Format ID Resolution**: Acepta tanto UUID como ID ofuscado (HashID).

## Tabla de Base de Datos

```sql
CREATE TABLE route (
    id VARCHAR(36) NOT NULL,
    origin_airport_id VARCHAR(36) NOT NULL,
    destination_airport_id VARCHAR(36) NOT NULL,
    origin_country VARCHAR(50),
    destination_country VARCHAR(50),
    airport_type VARCHAR(13) NOT NULL,
    estimated_flight_time INT,
    PRIMARY KEY (id),
    CONSTRAINT fk_route_origin_airport FOREIGN KEY (origin_airport_id) REFERENCES airport(id),
    CONSTRAINT fk_route_destination_airport FOREIGN KEY (destination_airport_id) REFERENCES airport(id),
    UNIQUE KEY uq_route_origin_destination (origin_airport_id, destination_airport_id)
);
```

## Endpoints Implementados

### GET /routes/{id}
Obtiene una ruta por ID.
- **Formatos aceptados**: UUID directo o ID ofuscado (HashID)
- **Respuesta**: Ruta con datos denormalizados (códigos IATA, países, tipo aeropuerto) y links HATEOAS
- **Código de éxito**: `RUT_CON_EXI_03901`
- **Código de error**: `RUT_CON_ERR_03902` (no encontrado)

### GET /routes (Funcionalidad adicional)
Lista todas las rutas.
- **Filtros opcionales**: `?airport_type=Nacional`, `?origin_country=Colombia`
- **Respuesta**: Lista de rutas con links HATEOAS
- **Código de éxito**: `RUT_LIST_EXI_03001`
- **Código de error**: `RUT_LIST_ERR_03002`

---

## Escenarios de Prueba

### HU39 - Consultar Información de la Ruta

| Código     | Tipo     | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Código Mensaje        | Estado      |
| ---------- | -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------- | ----------- |
| CONRUT-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar la información de una Ruta, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque una ruta válida por su identificador, **entonces** el sistema mostrará correctamente los datos de la ruta incluyendo aeropuerto origen (código IATA), aeropuerto destino (código IATA), países, tipo de aeropuerto y tiempo estimado de vuelo, presentará la información en la vista correspondiente y mostrará al usuario final el mensaje satisfactorio `RUT_CON_EXI_03901`. | `RUT_CON_EXI_03901` | 🔜 Pendiente |
| CONRUT-CA2 | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar la información de una Ruta, **cuando** intente realizar la consulta con un identificador que no existe en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `RUT_CON_ERR_03902` indicando que la ruta no fue encontrada y permitirá realizar una nueva búsqueda.                                                          | `RUT_CON_ERR_03902` | 🔜 Pendiente |
| CONRUT-CA3 | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar la información de una Ruta, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `RUT_CON_ERR_03903` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                    | `RUT_CON_ERR_03903` | 🔜 Pendiente |

### Listar Rutas (Funcionalidad adicional)

| Código     | Tipo     | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Código Mensaje         | Estado      |
| ---------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------- | ----------- |
| LSTRUT-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar el listado de Rutas, **cuando** acceda a la funcionalidad correspondiente y opcionalmente aplique filtros por tipo de aeropuerto o país de origen, **entonces** el sistema mostrará el listado completo de rutas con sus datos asociados (aeropuertos origen/destino, países, tipo aeropuerto, tiempo estimado), presentará la información en la vista correspondiente y mostrará al usuario final el mensaje satisfactorio `RUT_LIST_EXI_03001`.                      | `RUT_LIST_EXI_03001` | 🔜 Pendiente |
| LSTRUT-CA2 | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar el listado de Rutas, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error `RUT_LIST_ERR_03002` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                                                             | `RUT_LIST_ERR_03002` | 🔜 Pendiente |

---

## Códigos de Mensaje a Implementar

### Mensajes de Éxito en errors.go

| Constante              | Código                 | Tipo  |
| ---------------------- | ---------------------- | ----- |
| `MsgRouteGetOK`        | `RUT_CON_EXI_03901`    | Éxito |
| `MsgRouteListOK`       | `RUT_LIST_EXI_03001`   | Éxito |

### Mensajes de Error en errors.go

| Constante              | Código                 | Tipo  |
| ---------------------- | ---------------------- | ----- |
| `MsgRouteNotFound`     | `RUT_CON_ERR_03902`    | Error |
| `MsgRouteGetErr`       | `RUT_CON_ERR_03903`    | Error |
| `MsgRouteListError`    | `RUT_LIST_ERR_03002`   | Error |

### Errores de Dominio en errors.go

| Variable               | Código de Error         |
| ---------------------- | ----------------------- |
| `ErrRouteNotFound`     | `ERR_ROUTE_NOT_FOUND`   |

### Mapeo HTTP Status en cache.go

| Código                 | HTTP Status | Descripción                          |
| ---------------------- | ----------- | ------------------------------------ |
| `RUT_CON_EXI_03901`    | 200         | Ruta consultada exitosamente         |
| `RUT_CON_ERR_03902`    | 404         | Ruta no encontrada                   |
| `RUT_CON_ERR_03903`    | 500         | Error técnico al consultar           |
| `RUT_LIST_EXI_03001`   | 200         | Lista de rutas obtenida              |
| `RUT_LIST_ERR_03002`   | 500         | Error al listar rutas                |

---

## Query SQL con Datos Denormalizados

```sql
SELECT
    r.id,
    r.origin_airport_id,
    ao.iata_code AS origin_iata_code,
    ao.name AS origin_airport_name,
    r.destination_airport_id,
    ad.iata_code AS destination_iata_code,
    ad.name AS destination_airport_name,
    r.origin_country,
    r.destination_country,
    r.airport_type,
    r.estimated_flight_time,
    CONCAT(ao.iata_code, '-', ad.iata_code) AS route_code
FROM route r
JOIN airport ao ON r.origin_airport_id = ao.id
JOIN airport ad ON r.destination_airport_id = ad.id
WHERE r.id = ?;
```

---

## Archivos Principales a Modificar

| Categoría      | Archivos                                                                |
| -------------- | ----------------------------------------------------------------------- |
| **Handlers**   | `route_controller.go`, `route.go`, `handler.go`, `hateoas.go`           |
| **Interactor** | `interactor_route.go`                                                   |
| **Services**   | `route_services.go`                                                     |
| **Domain**     | `domain/route.go`, `domain/erros.go`                                    |
| **Ports**      | `input/service.go`, `output/repository.go`                              |
| **Repository** | `repositories/route/` (route.go, repository.go, get_by_id.go, list.go)  |
| **Logger**     | `log_messages.go`                                                       |
| **Cache**      | `platform/cache/messaging/cache.go`                                     |
| **Dependency** | `cmd/dependency/dependency.go`                                          |
| **Server**     | `server/server.go`                                                      |

---

## Scripts SQL

- `docs/sql/add_route_messages.sql` - Mensajes del sistema para el módulo Route

---

## Notas de Release

1. Este release implementa las operaciones de consulta para Ruta (Route): consultar por ID y listar todas.
2. Los endpoints pueden ser **públicos** (no requieren autenticación JWT) similar a Aircraft Model.
3. Los endpoints aceptan tanto UUID directo como ID ofuscado (HashID) para mayor flexibilidad.
4. Se puede filtrar la lista de rutas por tipo de aeropuerto (`?airport_type=Nacional`) o por país (`?origin_country=Colombia`).
5. La respuesta incluye datos denormalizados: códigos IATA de aeropuertos, nombres de aeropuertos, países y código de ruta (BOG-CLO).
6. La arquitectura sigue el patrón hexagonal establecido: Handler → Interactor → Service → Repository.
7. Se implementa HATEOAS (Richardson Maturity Model Level 3) para navegación entre recursos relacionados.
8. El constraint UNIQUE evita la creación de rutas duplicadas (mismo origen y destino).
9. Los campos `origin_country` y `destination_country` se mantienen desnormalizados para consultas rápidas de filtrado.

