# HU47: Crew Member Types - Implementation Summary

## Overview
**Release:** 17 - Type Catalogs
**Pattern:** Virtual Entity (Derived Values)
**Endpoint:** `GET /crew-member-types/{role}`
**Date:** 2026-01-20

## Feature Description
The Crew Member Types feature allows retrieving all employees of a specific role without creating a new database table. This is a "Virtual Entity" pattern implementation that queries the existing `employee.role` field.

## Example Usage
```bash
# Get all pilots
GET /flighthours/api/v1/crew-member-types/PILOTO

# Get all co-pilots
GET /flighthours/api/v1/crew-member-types/COPILOTO

# Get all auxiliaries
GET /flighthours/api/v1/crew-member-types/AUXILIAR
```

## Response Format
```json
{
  "success": true,
  "code": "TCM_CON_EXI_04701",
  "message": "Crew members retrieved successfully",
  "data": {
    "employees": [
      {
        "id": "obfuscated-id",
        "name": "John Doe",
        "airline": "ACME",
        "email": "john@example.com",
        "identification_number": "123456",
        "bp": "BP001",
        "start_date": "2025-01-01T00:00:00Z",
        "end_date": "2026-01-01T00:00:00Z",
        "active": true,
        "role": "PILOTO",
        "_links": [
          {"rel": "self", "href": "/flighthours/api/v1/employees/{id}"},
          {"rel": "update", "href": "/flighthours/api/v1/employees/{id}"},
          {"rel": "delete", "href": "/flighthours/api/v1/employees/{id}"}
        ]
      }
    ],
    "count": 1,
    "_links": [
      {"rel": "self", "href": "/flighthours/api/v1/crew-member-types"},
      {"rel": "employees", "href": "/flighthours/api/v1/employees"}
    ]
  }
}
```

## Files Modified

### 1. Repository Layer
- **`platform/databases/repositories/employee/repository.go`**
  - Added `QueryByRole` SQL constant
  - Added `stmtGetByRole` prepared statement
  - Implemented `GetEmployeesByRole(ctx, role)` method

### 2. Service Layer
- **`core/interactor/services/employee_services.go`**
  - Added `GetEmployeesByRole(ctx, role)` method

### 3. Interactor Layer
- **`core/interactor/interactor.go`**
  - Added `GetEmployeesByRole(ctx, role)` method with proper logging

### 4. Handler Layer
- **`handlers/employee_controller.go`**
  - Added `GetEmployeesByRole()` handler function with Swagger documentation
- **`handlers/employee.go`**
  - Added `EmployeeListResponse` struct
  - Added `ToEmployeeListResponse()` helper function

### 5. Routing
- **`server/server.go`**
  - Registered `GET /crew-member-types/:role` route in public group

### 6. Test Files Updated
- **`mocks/mock_repository.go`** - Added `GetEmployeesByRole` method
- **`core/interactor/services/employee_services_test.go`** - Added mock method
- **`core/interactor/interactor_test.go`** - Added mock method
- **`core/interactor/interactor_readonly_test.go`** - Added mock method
- **`handlers/http_test.go`** - Added mock methods to both `fakeService` and `fakeServiceErr`

### 7. SQL Script
- **`docs/sql/add_crew_member_type_messages.sql`**
  - `TCM_CON_EXI_04701` - Success message
  - `TCM_CON_ERR_04702` - Not found message
  - `TCM_CON_ERR_04703` - Error message

## Message Codes
| Code | Type | Description |
|------|------|-------------|
| `TCM_CON_EXI_04701` | SUCCESS | Crew members retrieved successfully |
| `TCM_CON_ERR_04702` | ERROR | No crew members found for the specified role |
| `TCM_CON_ERR_04703` | ERROR | Error retrieving crew members by role |

## Log Messages (if not already in log_messages.go)
The following log constants should be added to `platform/logger/log_messages.go`:
- `LogCrewMemberTypeGet` - Request to get employees by role
- `LogCrewMemberTypeGetOK` - Success log
- `LogCrewMemberTypeGetError` - Error log

## Domain Messages (if not already in domain)
The following constants should be added to `core/interactor/services/domain/messages.go`:
- `MsgCrewMemberTypeGetOK` - Success message code
- `MsgCrewMemberTypeNotFound` - Not found message code

## Database Setup
Execute the SQL script to add messages:
```bash
mysql -u root -p flighthours < docs/sql/add_crew_member_type_messages.sql
```

## Testing
```bash
# Run all tests
go test ./... -count=1

# Run specific tests
go test ./core/interactor/... -v
go test ./handlers/... -v
```

## Notes
- This feature follows the **Virtual Entity Pattern** - no new database tables created
- Queries the existing `employee.role` field directly
- Part of Release 17 alongside HU46 (Airport Types)
- Consistent with HU46 implementation pattern
