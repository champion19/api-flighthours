# Release 7: Modelo de Aeronave (Aircraft Model) - Consultas

**Tag Git**: `v0.8.0`
**Estado**: ✅ Implementado
**Total Horas**: 24h

## Historias de Usuario

| HU   | Descripción                                         | Horas | Endpoint                          | Estado | Full Stack |
| ---- | --------------------------------------------------- | ----- | --------------------------------- | ------ | ---------- |
| HU36 | Consultar información del Modelo de la Aeronave     | 8h    | `GET /aircraft-models/{id}`       | ✅     | 🟡         |
| HU43 | Consultar la Información del Tipo Aeronave          | 16h   | `GET /aircraft-models`             | ✅     | 🟡         |

## Dependencias

- ✅ Release 6: Matrícula (esta tabla es referenciada por matrícula)

## Estructura del Módulo Aircraft Model

```
core/
├── interactor/
│   ├── interactor_aircraft_model.go         ✅ Implementado
│   └── services/
│       ├── aircraft_model_services.go       ✅ Implementado
│       └── domain/
│           ├── aircraft_model.go            ✅ Implementado
│           └── erros.go                     ✅ Actualizado
handlers/
├── aircraft_model.go                        ✅ DTOs y mappers
├── aircraft_model_controller.go             ✅ Handlers
└── hateoas.go                               ✅ HATEOAS links
platform/
├── cache/messaging/
│   └── cache.go                             ✅ HTTP status codes
├── databases/
│   └── repositories/
│       └── aircraft_model/
│           └── repository.go                ✅ Repository con prepared statements
└── logger/
    └── log_messages.go                      ✅ Actualizado
```

## Notas Técnicas

> 📋 **aircraft_model** contiene el modelo y tipo de aeronave con su tipo de motor.
> 🔗 **Campos**: id, model_name, aircraft_type_name, engine_type_name
> 💡 **Tipos de Motor**: Generalmente valores como 'JET', 'TUR' (turboprop), etc.
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.
> 🔐 **Rutas Públicas**: Ambos endpoints son públicos (no requieren autenticación)
> 🔍 **Filtro**: Se puede filtrar por engine_type usando `?engine_type=JET`

## Tabla de Base de Datos

```sql
CREATE TABLE aircraft_model (
    id VARCHAR(36) NOT NULL,
    model_name VARCHAR(8) NOT NULL,
    aircraft_type_name VARCHAR(50) NOT NULL,
    engine_type_name VARCHAR(3),
    PRIMARY KEY(id)
);
```

## Endpoints Implementados

### GET /aircraft-models
Lista todos los modelos de aeronave.
- **Filtros opcionales**: `?engine_type=JET`
- **Respuesta**: Lista de modelos con links HATEOAS
- **Código de éxito**: `MOD_AM_LIST_EXI_04301`

### GET /aircraft-models/{id}
Obtiene un modelo de aeronave por ID.
- **Formatos aceptados**: UUID directo o ID ofuscado (HashID)
- **Respuesta**: Modelo con links HATEOAS
- **Código de éxito**: `MOD_AM_CON_EXI_03601`
- **Código de error**: `MOD_AM_CON_ERR_03602` (no encontrado)

---

## Escenarios de Prueba

### HU36 - Consultar información del Modelo de la Aeronave

| Código     | Tipo     | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Código Mensaje        | Estado      |
| ---------- | -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------- | ----------- |
| CONMOD-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar la información de un Modelo de Aeronave, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque un modelo válido por su identificador, **entonces** el sistema mostrará correctamente los datos del modelo incluyendo nombre del modelo, tipo de aeronave y tipo de motor, presentará la información en la vista correspondiente y mostrará al usuario final el mensaje satisfactorio `MOD_AM_CON_EXI_03601`. | `MOD_AM_CON_EXI_03601` | ✅ Aceptado |
| CONMOD-CA2 | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar la información de un Modelo de Aeronave, **cuando** intente realizar la consulta con un identificador que no existe en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `MOD_AM_CON_ERR_03602` indicando que el modelo de aeronave no fue encontrado y permitirá realizar una nueva búsqueda.                                                          | `MOD_AM_CON_ERR_03602` | ✅ Aceptado |
| CONMOD-CA3 | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar la información de un Modelo de Aeronave, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `MOD_AM_CON_ERR_03603` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                    | `MOD_AM_CON_ERR_03603` | ✅ Aceptado |

### HU43 - Consultar la Información del Tipo Aeronave (Listar Modelos)

| Código     | Tipo     | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Código Mensaje         | Estado      |
| ---------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------- | ----------- |
| LSTMOD-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar el listado de Modelos de Aeronave, **cuando** acceda a la funcionalidad correspondiente y opcionalmente aplique filtros por tipo de motor, **entonces** el sistema mostrará el listado completo de modelos con sus datos asociados (nombre del modelo, tipo de aeronave y tipo de motor), presentará la información en la vista correspondiente y mostrará al usuario final el mensaje satisfactorio `MOD_AM_LIST_EXI_04301`.                      | `MOD_AM_LIST_EXI_04301` | ✅ Aceptado |
| LSTMOD-CA2 | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar el listado de Modelos de Aeronave, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error `MOD_AM_LIST_ERR_04302` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                                                             | `MOD_AM_LIST_ERR_04302` | ✅ Aceptado |

---

## Códigos de Mensaje Implementados

### Mensajes de Éxito en errors.go

| Constante              | Código                 | Tipo  |
| ---------------------- | ---------------------- | ----- |
| `MsgAircraftModelGetOK`   | `MOD_AM_CON_EXI_03601`  | Éxito |
| `MsgAircraftModelListOK`  | `MOD_AM_LIST_EXI_04301` | Éxito |

### Mensajes de Error en errors.go

| Constante                 | Código                 | Tipo  |
| ------------------------- | ---------------------- | ----- |
| `MsgAircraftModelNotFound` | `MOD_AM_CON_ERR_03602`  | Error |
| `MsgAircraftModelGetErr`   | `MOD_AM_CON_ERR_03603`  | Error |
| `MsgAircraftModelListError` | `MOD_AM_LIST_ERR_04302` | Error |

### Errores de Dominio en errors.go

| Variable                   | Código de Error              |
| -------------------------- | ---------------------------- |
| `ErrAircraftModelNotFound` | `ERR_AIRCRAFT_MODEL_NOT_FOUND` |

### Mapeo HTTP Status en cache.go

| Código                 | HTTP Status | Descripción                          |
| ---------------------- | ----------- | ------------------------------------ |
| `MOD_AM_CON_EXI_03601`  | 200         | Modelo de aeronave consultado        |
| `MOD_AM_CON_ERR_03602`  | 404         | Modelo de aeronave no encontrado     |
| `MOD_AM_CON_ERR_03603`  | 500         | Error técnico al consultar           |
| `MOD_AM_LIST_EXI_04301` | 200         | Lista de modelos/tipos obtenida      |
| `MOD_AM_LIST_ERR_04302` | 500         | Error al listar modelos/tipos        |

---

## Scripts SQL

- `docs/sql/add_aircraft_model_messages.sql` - Mensajes del sistema para el módulo

---

## Archivos Principales Modificados

| Categoría      | Archivos                                                                                |
| -------------- | --------------------------------------------------------------------------------------- |
| **Handlers**   | `aircraft_model_controller.go`, `aircraft_model.go`, `handler.go`, `hateoas.go`        |
| **Interactor** | `interactor_aircraft_model.go`                                                          |
| **Services**   | `aircraft_model_services.go`                                                            |
| **Domain**     | `domain/aircraft_model.go`, `domain/erros.go`                                           |
| **Ports**      | `input/service.go`, `output/repository.go`                                              |
| **Repository** | `repositories/aircraft_model/` (aircraft_model.go, repository.go, get_by_id.go, list.go) |
| **Logger**     | `log_messages.go`                                                                       |
| **Cache**      | `platform/cache/messaging/cache.go`                                                     |
| **Dependency** | `cmd/dependency/dependency.go`                                                          |
| **Server**     | `server/server.go`                                                                      |

---

## Notas de Release

1. Este release implementa las operaciones de consulta para Modelo de Aeronave (Aircraft Model): consultar por ID y listar todos.
2. Todos los endpoints son **públicos** (no requieren autenticación JWT).
3. Los endpoints aceptan tanto UUID directo como ID ofuscado (HashID) para mayor flexibilidad.
4. Se puede filtrar la lista de modelos por tipo de motor usando el query parameter `?engine_type=JET`.
5. La respuesta incluye datos completos: nombre del modelo, tipo de aeronave y tipo de motor.
6. La arquitectura sigue el patrón hexagonal establecido: Handler → Interactor → Service → Repository.
7. Se implementa HATEOAS (Richardson Maturity Model Level 3) para navegación entre recursos relacionados.
8. Este módulo es una dependencia del Release 6 (Matrícula/Aircraft Registration) ya que la tabla `aircraft_registration` tiene un FK hacia `aircraft_model`.


