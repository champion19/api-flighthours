# Release 16: Catálogos Geográficos - Consultas

**Tag Git**: `v0.17.0`
**Estado**: 🔜 Pendiente
**Total Horas**: 6h

## Historias de Usuario


| HU   | Descripción                               | Horas | Endpoint                | Estado                                 | Full Stack |
| ---- | ------------------------------------------ | ----- | ----------------------- | -------------------------------------- | ---------- |
| HU13 | Consultar la Información de la Ciudad     | 2h    | `GET /cities/{id}`      | no se tiene en cuenta en documentacion | 🟡         |
| HU14 | Consultar la Información del Departamento | 2h    | `GET /departments/{id}` | no se tiene en cuenta en la documentacion.                             | 🟡         |
| HU38 | Consultar la información del País        | 2h    | `GET /countries/{id}`   | no se tiene en cuenta en la documentacion.| 🟡         |

## Dependencias

- ✅ Release 4: Aeropuerto (usa city, country)

## Estructura del Módulo Geographic Catalogs

```
core/
├── interactor/
│   ├── interactor_city.go
│   ├── interactor_department.go
│   ├── interactor_country.go
│   └── services/
│       ├── city_services.go
│       ├── department_services.go
│       ├── country_services.go
│       └── domain/
│           ├── city.go
│           ├── department.go
│           └── country.go
handlers/
├── city.go
├── city_controller.go
├── department.go
├── department_controller.go
├── country.go
└── country_controller.go
```

## Notas Técnicas

> ⚠️ **Nota**: No existen tablas `city`, `department`, `country` en el schema actual.
> 💡 En `airport` tenemos `city` y `country` como VARCHAR, no FK.
> 📋 Esta release puede implementarse como:
>
> 1. Tablas maestras nuevas
> 2. Servicio externo de geografía
> 3. Extracción de valores únicos de aeropuertos
>    🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.

## Opciones de Implementación

### Opción A: Tablas Maestras

```sql
CREATE TABLE country (
    id VARCHAR(36) NOT NULL,
    country_name VARCHAR(50) NOT NULL,
    country_code VARCHAR(3),
    PRIMARY KEY(id)
);

CREATE TABLE department (
    id VARCHAR(36) NOT NULL,
    department_name VARCHAR(50) NOT NULL,
    country_id VARCHAR(36) NOT NULL,
    PRIMARY KEY(id),
    FOREIGN KEY (country_id) REFERENCES country(id)
);

CREATE TABLE city (
    id VARCHAR(36) NOT NULL,
    city_name VARCHAR(50) NOT NULL,
    department_id VARCHAR(36) NOT NULL,
    PRIMARY KEY(id),
    FOREIGN KEY (department_id) REFERENCES department(id)
);
```

### Opción B: Valores Derivados

Extraer valores únicos de `airport.city` y `airport.country`.
