# Release 04 - Módulo de Aeropuerto

## Información General

| Campo | Valor |
|-------|-------|
| **Versión** | v0.5.0 |
| **Rama** | develop |
| **Sprint** | Sprint 4 |
| **Horas Planificadas** | 12 horas |
| **Pull Requests** | #17 |

---

## Historias de Usuario Incluidas

| Código | Historia de Usuario | Talla | Horas | Full Stack |
|--------|---------------------|-------|-------|------------|
| HU4 | Consultar la Información del Aeropuerto | S | 4 | ✅ |
| HU5 | Activar el aeropuerto | S | 4 | 🟡 |
| HU6 | Inactivar el aeropuerto | S | 4 | 🟡 |

---

## Componentes Implementados

### 1. Consultar Aeropuerto (HU4)
- Endpoint: `GET /flighthours/api/v1/airports/:id`
- Acepta UUID o ID ofuscado
- Retorna información completa del aeropuerto

### 2. Activar Aeropuerto (HU5)
- Endpoint: `PATCH /flighthours/api/v1/airports/:id/activate`
- Cambia estado del aeropuerto a activo (status = true)
- Acepta UUID o ID ofuscado

### 3. Inactivar Aeropuerto (HU6)
- Endpoint: `PATCH /flighthours/api/v1/airports/:id/deactivate`
- Cambia estado del aeropuerto a inactivo (status = false)
- Acepta UUID o ID ofuscado

---

## Escenarios de Prueba

### HU4 - Consultar la Información del Aeropuerto

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| APTO-CA1 | ✅ Éxito | **Dado que** un Piloto del Sistema desea consultar la información de un aeropuerto, **cuando** acceda a la funcionalidad de consulta de aeropuerto, ingrese un identificador válido y confirme la acción, **entonces** el sistema recuperará la información correspondiente, mostrará los datos del aeropuerto de manera estructurada, desplegará el mensaje satisfactorio con el código `MOD_APT_GET_EXI_00001` y permitirá al usuario continuar navegando en el sistema. | `MOD_APT_GET_EXI_00001` | ✅ Aceptado |
| APTO-CA2 | ❌ Error | **Dado que** un Piloto del Sistema desea consultar la información de un aeropuerto, **cuando** ingrese un identificador que no corresponde a ningún aeropuerto registrado en el sistema, **entonces** el sistema validará que el aeropuerto no existe, mostrará el mensaje de error con el código `MOD_APT_NOT_FOUND_ERR_00001` y no permitirá continuar con la consulta. | `MOD_APT_NOT_FOUND_ERR_00001` | ✅ Aceptado |
| APTO-CA3 | ❌ Error | **Dado que** un Piloto del Sistema desea consultar la información de un aeropuerto, **cuando** ingrese un identificador con formato incorrecto o inválido, **entonces** el sistema validará el formato del identificador, determinará que es inválido, mostrará el mensaje de error con el código `MOD_V_ID_ERR_00013` y solicitará al usuario que corrija el dato ingresado. | `MOD_V_ID_ERR_00013` | ✅ Aceptado |
| APTO-CA4 | ❌ Error | **Dado que** un Piloto del Sistema desea consultar la información de un aeropuerto, **cuando** el sistema no pueda completar la operación debido a una falla interna, **entonces** el sistema detectará la condición de error, mostrará el mensaje con el código `GEN_SRV_ERR_00001` indicando que el servicio no está disponible temporalmente y sugerirá al usuario intentar nuevamente más tarde. | `GEN_SRV_ERR_00001` | ✅ Aceptado |

### HU5 - Activar el Aeropuerto

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| ACTA-CA1 | ✅ Éxito | **Dado que** un Administrador del Sistema desea activar un aeropuerto previamente inactivo, **cuando** acceda a la funcionalidad de gestión de aeropuertos, seleccione la opción de activar, ingrese un identificador válido y confirme la acción, **entonces** el sistema cambiará el estado del aeropuerto a activo, mostrará el mensaje satisfactorio con el código `MOD_APT_ACTIVATE_EXI_00002` y actualizará la vista para reflejar el nuevo estado del aeropuerto. | `MOD_APT_ACTIVATE_EXI_00002` | ✅ Aceptado |
| ACTA-CA2 | ❌ Error | **Dado que** un Administrador del Sistema desea activar un aeropuerto, **cuando** ingrese un identificador que no corresponde a ningún aeropuerto registrado en el sistema, **entonces** el sistema validará que el aeropuerto no existe, mostrará el mensaje de error con el código `MOD_APT_NOT_FOUND_ERR_00001` y no permitirá continuar con la operación de activación. | `MOD_APT_NOT_FOUND_ERR_00001` | ✅ Aceptado |
| ACTA-CA3 | ❌ Error | **Dado que** un Administrador del Sistema desea activar un aeropuerto, **cuando** ingrese un identificador con formato incorrecto o inválido, **entonces** el sistema validará el formato del identificador, determinará que es inválido, mostrará el mensaje de error con el código `MOD_V_ID_ERR_00013` y solicitará al usuario que corrija el dato ingresado. | `MOD_V_ID_ERR_00013` | ✅ Aceptado |
| ACTA-CA4 | ❌ Error | **Dado que** un Administrador del Sistema desea activar un aeropuerto, **cuando** el sistema no pueda completar la operación debido a una falla interna, **entonces** el sistema detectará la condición de error, mostrará el mensaje con el código `GEN_SRV_ERR_00001` indicando que el servicio no está disponible temporalmente y sugerirá al usuario intentar nuevamente más tarde. | `GEN_SRV_ERR_00001` | ✅ Aceptado |

### HU6 - Inactivar el Aeropuerto

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| INCA-CA1 | ✅ Éxito | **Dado que** un Administrador del Sistema desea inactivar un aeropuerto, **cuando** acceda a la funcionalidad de gestión de aeropuertos, seleccione la opción de inactivar, ingrese un identificador válido y confirme la acción, **entonces** el sistema cambiará el estado del aeropuerto a inactivo, mostrará el mensaje satisfactorio con el código `MOD_APT_DEACTIVATE_EXI_00003` y actualizará la vista para reflejar el nuevo estado del aeropuerto. | `MOD_APT_DEACTIVATE_EXI_00003` | ✅ Aceptado |
| INCA-CA2 | ❌ Error | **Dado que** un Administrador del Sistema desea inactivar un aeropuerto, **cuando** ingrese un identificador que no corresponde a ningún aeropuerto registrado en el sistema, **entonces** el sistema validará que el aeropuerto no existe, mostrará el mensaje de error con el código `MOD_APT_NOT_FOUND_ERR_00001` y no permitirá continuar con la operación de inactivación. | `MOD_APT_NOT_FOUND_ERR_00001` | ✅ Aceptado |
| INCA-CA3 | ❌ Error | **Dado que** un Administrador del Sistema desea inactivar un aeropuerto, **cuando** ingrese un identificador con formato incorrecto o inválido, **entonces** el sistema validará el formato del identificador, determinará que es inválido, mostrará el mensaje de error con el código `MOD_V_ID_ERR_00013` y solicitará al usuario que corrija el dato ingresado. | `MOD_V_ID_ERR_00013` | ✅ Aceptado |
| INCA-CA4 | ❌ Error | **Dado que** un Administrador del Sistema desea inactivar un aeropuerto, **cuando** el sistema no pueda completar la operación debido a una falla interna, **entonces** el sistema detectará la condición de error, mostrará el mensaje con el código `GEN_SRV_ERR_00001` indicando que el servicio no está disponible temporalmente y sugerirá al usuario intentar nuevamente más tarde. | `GEN_SRV_ERR_00001` | ✅ Aceptado |

---

## Archivos Principales Modificados

| Categoría | Archivos |
|-----------|----------|
| **Handlers** | `airport_controller.go`, `airport.go`, `handler.go` |
| **Interactor** | `interactor_airport.go` |
| **Services** | `airport_services.go` |
| **Domain** | `domain/airport.go`, `domain/erros.go` |
| **Ports** | `input/service.go`, `output/repository.go` |
| **Repository** | `repositories/airport/` (airport.go, repository.go, get_airport_by_id.go, update_status.go) |
| **Logger** | `log_messages.go` |
| **Dependency** | `cmd/dependency/dependency.go` |
| **Server** | `server/server.go` |

---

## Códigos de Mensaje Implementados

### Mensajes en errors.go

| Constante | Código | Tipo |
|-----------|--------|------|
| `MsgAirportNotFound` | `MOD_APT_NOT_FOUND_ERR_00001` | Error |
| `MsgAirportActivateErr` | `MOD_APT_ACTIVATE_ERR_00002` | Error |
| `MsgAirportDeactivateErr` | `MOD_APT_DEACTIVATE_ERR_00003` | Error |
| `MsgAirportGetOK` | `MOD_APT_GET_EXI_00001` | Éxito |
| `MsgAirportActivateOK` | `MOD_APT_ACTIVATE_EXI_00002` | Éxito |
| `MsgAirportDeactivateOK` | `MOD_APT_DEACTIVATE_EXI_00003` | Éxito |

### Errores en errors.go

| Variable | Código de Error |
|----------|-----------------|
| `ErrAirportNotFound` | `ERR_AIRPORT_NOT_FOUND` |

### SQL para insertar mensajes en la BD

```sql
INSERT INTO message (id, code, type, category, module, title, content, active) VALUES
(UUID(), 'MOD_APT_NOT_FOUND_ERR_00001', 'ERROR', 'backend', 'airport', 'Aeropuerto no encontrado', 'El aeropuerto solicitado no existe en el sistema', true),
(UUID(), 'MOD_APT_ACTIVATE_ERR_00002', 'ERROR', 'backend', 'airport', 'Error al activar aeropuerto', 'No se pudo activar el aeropuerto', true),
(UUID(), 'MOD_APT_DEACTIVATE_ERR_00003', 'ERROR', 'backend', 'airport', 'Error al desactivar aeropuerto', 'No se pudo desactivar el aeropuerto', true),
(UUID(), 'MOD_APT_GET_EXI_00001', 'SUCCESS', 'backend', 'airport', 'Aeropuerto obtenido', 'Aeropuerto obtenido exitosamente', true),
(UUID(), 'MOD_APT_ACTIVATE_EXI_00002', 'SUCCESS', 'backend', 'airport', 'Aeropuerto activado', 'El aeropuerto ha sido activado exitosamente', true),
(UUID(), 'MOD_APT_DEACTIVATE_EXI_00003', 'SUCCESS', 'backend', 'airport', 'Aeropuerto desactivado', 'El aeropuerto ha sido desactivado exitosamente', true);
```

---

## Notas de Release

1. Este release implementa la gestión básica de aeropuertos: consulta y cambio de estado.
2. Los endpoints aceptan tanto UUID directo como ID ofuscado para mayor flexibilidad.
3. Se utiliza el patrón PATCH para las operaciones de activar/desactivar (operación parcial sobre recurso).
4. La arquitectura sigue el patrón hexagonal establecido: Handler → Interactor → Service → Repository.
5. El campo `status` en la tabla `airport` es de tipo `BOOL` (diferente a `airline` que usa `VARCHAR`).
6. Los campos opcionales del aeropuerto (city, country, iata_code, airport_type) se manejan con punteros para soportar valores NULL.
