# Release 13: Motor y Fabricante - Consultas

**Tag Git**: `v0.14.0`
**Estado**: ✅ Completado
**Total Horas**: 10h

## Historias de Usuario

| HU   | Descripción                                    | Horas | Endpoint                    | Estado | Full Stack |
| ---- | ---------------------------------------------- | ----- | --------------------------- | ------ | ---------- |
| HU37 | Consultar la Información del Motor             | 8h    | `GET /engines/{id}`         | ✅     | 🟡         |
| HU31 | Consultar la Información del Fabricante        | 2h    | `GET /manufacturers/{id}`   | ✅     | 🟡         |

## Dependencias

- ✅ Release 7: Modelo Aeronave (Contexto de aeronaves)

## Estructura del Módulo Engine/Manufacturer

```
core/
├── interactor/
│   ├── interactor_engine.go
│   ├── interactor_manufacturer.go
│   └── services/
│       ├── engine_services.go
│       ├── manufacturer_services.go
│       └── domain/
│           ├── engine.go
│           └── manufacturer.go
handlers/
├── engine.go
├── engine_controller.go
├── manufacturer.go
└── manufacturer_controller.go
platform/
└── databases/
    └── repositories/
        ├── engine/
        │   └── repository.go
        └── manufacturer/
            └── repository.go
```

## Notas Técnicas

> 🎯 **CATÁLOGOS NORMALIZADOS**: Se crearon tablas `engine` y `manufacturer` como catálogos maestros.
> 📋 La tabla `aircraft_model` fue normalizada con FKs a estas nuevas tablas.
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.
> 🔑 **Dual-Format ID Resolution**: Acepta tanto UUID como ID ofuscado (HashID).

## Tablas de Base de Datos

```sql
-- Tabla Engine (Motor)
CREATE TABLE engine (
    id VARCHAR(36) NOT NULL PRIMARY KEY,
    name VARCHAR(3) NOT NULL
);

-- Tabla Manufacturer (Fabricante)
CREATE TABLE manufacturer (
    id VARCHAR(36) NOT NULL PRIMARY KEY,
    name VARCHAR(50) NOT NULL
);

-- Modificación a aircraft_model (FKs)
ALTER TABLE aircraft_model
    ADD COLUMN engine_type_id VARCHAR(36),
    ADD COLUMN manufacturer_id VARCHAR(36),
    ADD CONSTRAINT fk_aircraft_model_engine FOREIGN KEY (engine_type_id) REFERENCES engine(id),
    ADD CONSTRAINT fk_aircraft_model_manufacturer FOREIGN KEY (manufacturer_id) REFERENCES manufacturer(id);
```

---

## Escenarios de Prueba

### HU37 - Consultar la Información del Motor

| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                             | Código Mensaje     | Estado      |
| ---------- | --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ----------- |
| CONMOT-CA1 | ✅ Éxito | **Dado** que un Usuario del Sistema quiere consultar la información de un tipo de Motor, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque un motor válido por su identificador, **entonces** el sistema mostrará correctamente los datos del motor incluyendo el nombre del tipo de motor, presentará la información en la vista correspondiente con enlaces HATEOAS y mostrará al usuario final el mensaje satisfactorio `MOT_CON_EXI_03701`. | `MOT_CON_EXI_03701` | ✅ Aceptado |
| CONMOT-CA2 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar la información de un tipo de Motor, **cuando** intente realizar la consulta con un identificador que no existe en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `MOT_CON_ERR_03702` indicando que el motor no fue encontrado y permitirá realizar una nueva búsqueda.                                                                 | `MOT_CON_ERR_03702` | ✅ Aceptado |
| CONMOT-CA3 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar la información de un tipo de Motor, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `MOT_CON_ERR_03703` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                  | `MOT_CON_ERR_03703` | ✅ Aceptado |

### Listar Motores (Funcionalidad adicional)

| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                    | Código Mensaje      | Estado      |
| ---------- | --------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- | ----------- |
| LSTMOT-CA1 | ✅ Éxito | **Dado** que un Usuario del Sistema quiere consultar el listado de tipos de Motores disponibles, **cuando** acceda a la funcionalidad correspondiente, **entonces** el sistema mostrará el listado completo de motores con sus datos asociados (ID y nombre), presentará la información en la vista correspondiente con enlaces HATEOAS y mostrará el mensaje satisfactorio `MOT_LIST_EXI_03704`. | `MOT_LIST_EXI_03704` | ✅ Aceptado |
| LSTMOT-CA2 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar el listado de tipos de Motores, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error `MOT_LIST_ERR_03705` y recomendará intentar nuevamente más tarde.                                                                                                         | `MOT_LIST_ERR_03705` | ✅ Aceptado |

### HU31 - Consultar la Información del Fabricante

| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                             | Código Mensaje     | Estado      |
| ---------- | --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ----------- |
| CONFAB-CA1 | ✅ Éxito | **Dado** que un Usuario del Sistema quiere consultar la información de un Fabricante, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque un fabricante válido por su identificador, **entonces** el sistema mostrará correctamente los datos del fabricante incluyendo el nombre, presentará la información en la vista correspondiente con enlaces HATEOAS y mostrará al usuario final el mensaje satisfactorio `FAB_CON_EXI_03101`. | `FAB_CON_EXI_03101` | ✅ Aceptado |
| CONFAB-CA2 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar la información de un Fabricante, **cuando** intente realizar la consulta con un identificador que no existe en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `FAB_CON_ERR_03102` indicando que el fabricante no fue encontrado y permitirá realizar una nueva búsqueda.                                                                 | `FAB_CON_ERR_03102` | ✅ Aceptado |
| CONFAB-CA3 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar la información de un Fabricante, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `FAB_CON_ERR_03103` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                  | `FAB_CON_ERR_03103` | ✅ Aceptado |

### Listar Fabricantes (Funcionalidad adicional)

| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                    | Código Mensaje      | Estado      |
| ---------- | --------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- | ----------- |
| LSTFAB-CA1 | ✅ Éxito | **Dado** que un Usuario del Sistema quiere consultar el listado de Fabricantes disponibles, **cuando** acceda a la funcionalidad correspondiente, **entonces** el sistema mostrará el listado completo de fabricantes con sus datos asociados (ID y nombre), presentará la información en la vista correspondiente con enlaces HATEOAS y mostrará el mensaje satisfactorio `FAB_LIST_EXI_03104`. | `FAB_LIST_EXI_03104` | ✅ Aceptado |
| LSTFAB-CA2 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar el listado de Fabricantes, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error `FAB_LIST_ERR_03105` y recomendará intentar nuevamente más tarde.                                                                                                         | `FAB_LIST_ERR_03105` | ✅ Aceptado |

---

## Archivos Principales Modificados

| Categoría     | Archivos                                                                                                                   |
| -------------- | -------------------------------------------------------------------------------------------------------------------------- |
| **Handlers**   | `engine_controller.go`, `engine.go`, `manufacturer_controller.go`, `manufacturer.go`, `handler.go`, `hateoas.go`          |
| **Interactor** | `interactor_engine.go`, `interactor_manufacturer.go`                                                                       |
| **Services**   | `engine_services.go`, `manufacturer_services.go`                                                                           |
| **Domain**     | `domain/engine.go`, `domain/manufacturer.go`, `domain/erros.go`                                                            |
| **Ports**      | `input/service.go`, `output/repository.go`                                                                                 |
| **Repository** | `repositories/engine/repository.go`, `repositories/manufacturer/repository.go`                                            |
| **Logger**     | `log_messages.go`                                                                                                          |
| **Cache**      | `platform/cache/messaging/cache.go`                                                                                        |
| **Middleware** | `middleware/errors_handler.go`                                                                                             |
| **Dependency** | `cmd/dependency/dependency.go`                                                                                             |
| **Server**     | `server/server.go`                                                                                                         |
| **SQL**        | `docs/sql/add_engine_manufacturer_messages.sql`, `docs/sql/tables.sql`                                                     |

---

## Códigos de Mensaje Implementados

### Mensajes de Éxito en errors.go

| Constante                   | Código              | Tipo   |
| --------------------------- | -------------------- | ------ |
| `MsgEngineGetOK`            | `MOT_CON_EXI_03701`  | Éxito |
| `MsgEngineListOK`           | `MOT_LIST_EXI_03704` | Éxito |
| `MsgManufacturerGetOK`      | `FAB_CON_EXI_03101`  | Éxito |
| `MsgManufacturerListOK`     | `FAB_LIST_EXI_03104` | Éxito |

### Mensajes de Error en errors.go

| Constante                   | Código               | Tipo  |
| --------------------------- | --------------------- | ----- |
| `MsgEngineNotFound`         | `MOT_CON_ERR_03702`   | Error |
| `MsgEngineGetError`         | `MOT_CON_ERR_03703`   | Error |
| `MsgEngineListError`        | `MOT_LIST_ERR_03705`  | Error |
| `MsgManufacturerNotFound`   | `FAB_CON_ERR_03102`   | Error |
| `MsgManufacturerGetError`   | `FAB_CON_ERR_03103`   | Error |
| `MsgManufacturerListError`  | `FAB_LIST_ERR_03105`  | Error |

### Errores de Dominio en errors.go

| Variable                         | Código de Error                        |
| -------------------------------- | --------------------------------------- |
| `ErrEngineNotFound`              | `ERR_ENGINE_NOT_FOUND`                  |
| `ErrManufacturerNotFound`        | `ERR_MANUFACTURER_NOT_FOUND`            |

### Mapeo HTTP Status en cache.go

| Código               | HTTP Status | Descripción                            |
| --------------------- | ----------- | --------------------------------------- |
| `MOT_CON_EXI_03701`   | 200         | Motor consultado exitosamente           |
| `MOT_CON_ERR_03702`   | 404         | Motor no encontrado                     |
| `MOT_CON_ERR_03703`   | 500         | Error técnico al consultar motor        |
| `MOT_LIST_EXI_03704`  | 200         | Lista de motores obtenida               |
| `MOT_LIST_ERR_03705`  | 500         | Error al listar motores                 |
| `FAB_CON_EXI_03101`   | 200         | Fabricante consultado exitosamente      |
| `FAB_CON_ERR_03102`   | 404         | Fabricante no encontrado                |
| `FAB_CON_ERR_03103`   | 500         | Error técnico al consultar fabricante   |
| `FAB_LIST_EXI_03104`  | 200         | Lista de fabricantes obtenida           |
| `FAB_LIST_ERR_03105`  | 500         | Error al listar fabricantes             |

### Mapeo Error → Código en errors_handler.go

| Error de Dominio               | Código de Mensaje         |
| ------------------------------ | -------------------------- |
| `ErrEngineNotFound`            | `MsgEngineNotFound`        |
| `ErrManufacturerNotFound`      | `MsgManufacturerNotFound`  |

---

## Endpoints API

### Engines (Motor)

| Método | Endpoint                              | Descripción                    | Auth  |
| ------ | ------------------------------------- | ------------------------------ | ----- |
| GET    | `/flighthours/api/v1/engines`         | Lista todos los tipos de motor | No    |
| GET    | `/flighthours/api/v1/engines/{id}`    | Obtiene motor por ID           | No    |

### Manufacturers (Fabricante)

| Método | Endpoint                                  | Descripción                    | Auth  |
| ------ | ----------------------------------------- | ------------------------------ | ----- |
| GET    | `/flighthours/api/v1/manufacturers`       | Lista todos los fabricantes    | No    |
| GET    | `/flighthours/api/v1/manufacturers/{id}`  | Obtiene fabricante por ID      | No    |

---

## Ejemplos de Respuesta

### GET /engines/{id} - Éxito

```json
{
  "success": true,
  "code": "MOT_CON_EXI_03701",
  "message": "The engine has been retrieved successfully.",
  "data": {
    "id": "xK7mN2pQ9rLw",
    "name": "JET",
    "_links": {
      "self": { "href": "/flighthours/api/v1/engines/xK7mN2pQ9rLw" },
      "engines": { "href": "/flighthours/api/v1/engines" }
    }
  }
}
```

### GET /manufacturers/{id} - Éxito

```json
{
  "success": true,
  "code": "FAB_CON_EXI_03101",
  "message": "The manufacturer has been retrieved successfully.",
  "data": {
    "id": "yL8nO3qR0sMx",
    "name": "Boeing",
    "_links": {
      "self": { "href": "/flighthours/api/v1/manufacturers/yL8nO3qR0sMx" },
      "manufacturers": { "href": "/flighthours/api/v1/manufacturers" }
    }
  }
}
```

### GET /engines/{id} - Error Not Found

```json
{
  "success": false,
  "code": "MOT_CON_ERR_03702",
  "message": "The requested engine does not exist in the system."
}
```

---

## Notas de Release

1. Este release implementa las consultas de Motor (Engine) y Fabricante (Manufacturer).
2. Se crearon nuevas tablas `engine` y `manufacturer` como catálogos maestros.
3. La tabla `aircraft_model` fue normalizada con FKs a estas nuevas tablas.
4. Todos los endpoints son públicos (no requieren autenticación).
5. Los endpoints aceptan tanto UUID directo como ID ofuscado (HashID).
6. Se implementa HATEOAS (Richardson Maturity Model Level 3) para navegación.
7. La arquitectura sigue el patrón hexagonal: Handler → Interactor → Service → Repository.
8. Los mensajes se cargan desde la tabla `system_messages` a través el sistema de cache.
9. Se agregó el mapeo de errores en `errors_handler.go` para Engine y Manufacturer.
10. Se agregaron los HTTP status codes en `cache.go` para los códigos de mensaje.
