# Release 17: Catálogos de Tipos - Consultas

**Tag Git**: `v0.18.0`
**Estado**: ✅ Completado
**Total Horas**: 18h

## Historias de Usuario

| HU   | Descripción                                          | Horas | Endpoint                         | Estado | Full Stack |
| ---- | ---------------------------------------------------- | ----- | -------------------------------- | ------ | ---------- |
| HU46 | Consultar la Información del Tipo Aeropuerto         | 16h   | `GET /airport-types/{type}`      | ✅     | 🟡         |
| HU47 | Consultar la Información del Tipo Integrante         | 2h    | `GET /crew-member-types/{role}`  | ✅     | 🟡         |

## Dependencias

- ✅ Release 4: Aeropuerto (usa airport_type)
- ✅ Release 1: Empleado (usa role)

## Estructura del Módulo Type Catalogs

> ⚠️ **Nota Técnica**: Este módulo **NO** crea nuevas tablas `airport_type` ni `crew_member_type`.
> 💡 La implementación usa campos existentes: `airport.airport_type` y `employee.role`.
> 🎯 **Patrón Virtual Entity implementado**: Consulta directa sobre campos VARCHAR existentes.

```
core/
├── interactor/
│   ├── interactor_airport.go           ← Método: GetAirportsByType
│   ├── interactor.go                   ← Método: GetEmployeesByRole
│   └── services/
│       ├── airport_services.go         ← Método: GetAirportsByType
│       ├── employee_services.go        ← Método: GetEmployeesByRole
│       └── domain/
│           ├── airport.go              ← Ya tiene campo AirportType
│           └── employee.go             ← Ya tiene campo Role
handlers/
├── airport_controller.go               ← Handler: GetAirportsByType
├── employee_controller.go              ← Handler: GetEmployeesByRole
└── employee.go                         ← DTO: EmployeeListResponse
platform/
└── databases/
    └── repositories/
        ├── airport/
        │   └── repository.go           ← Query: QueryGetByType
        └── employee/
            └── repository.go           ← Query: QueryByRole
```

## Notas Técnicas

> 🎯 **REUTILIZACIÓN**: Se aprovecha la infraestructura existente de `airport` y `employee`.
> 📋 Ejemplo tipos aeropuerto: INTERNATIONAL, NATIONAL, REGIONAL, PRIVATE.
> 📋 Ejemplo roles empleado: PILOTO, COPILOTO, AUXILIAR, INSTRUCTOR.
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.
> 🔑 **ID de Tipo/Rol**: Es un string directo (ej: "INTERNATIONAL", "PILOTO"), no un UUID ofuscado.

---

## Escenarios de Prueba

### HU46 - Consultar la Información del Tipo Aeropuerto

| Código     | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                          | Código Mensaje     | Estado       |
| ---------- | --------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ------------ |
| CONTAE-CA1 | ✅ Éxito  | **Dado** que un Usuario del Sistema quiere consultar los aeropuertos de un tipo específico, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque un tipo válido por su identificador (ej: INTERNATIONAL, NATIONAL), **entonces** el sistema mostrará correctamente todos los aeropuertos de ese tipo incluyendo nombre, ciudad, país, código IATA, estado y tipo, presentará la información en la vista correspondiente con enlaces HATEOAS y mostrará al usuario final el mensaje satisfactorio `TAE_CON_EXI_04601`. | `TAE_CON_EXI_04601` | ✅ Aceptado  |
| CONTAE-CA2 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar los aeropuertos de un tipo específico, **cuando** intente realizar la consulta con un identificador de tipo que no existe o no tiene aeropuertos asociados en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `TAE_CON_ERR_04602` indicando que no se encontraron aeropuertos de ese tipo y permitirá realizar una nueva búsqueda.                                                     | `TAE_CON_ERR_04602` | ✅ Aceptado  |
| CONTAE-CA3 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar los aeropuertos de un tipo específico, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `TAE_CON_ERR_04603` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                                                              | `TAE_CON_ERR_04603` | ✅ Aceptado  |

### HU47 - Consultar la Información del Tipo Integrante

| Código     | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                              | Código Mensaje     | Estado       |
| ---------- | --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------- | ------------ |
| CONTIN-CA1 | ✅ Éxito  | **Dado** que un Usuario del Sistema quiere consultar los empleados de un rol específico (Crew Member Type), **cuando** acceda a la funcionalidad correspondiente y seleccione o busque un rol válido por su identificador (ej: PILOTO, COPILOTO), **entonces** el sistema mostrará correctamente todos los empleados de ese rol incluyendo nombre, aerolínea, email, identificación, bp, fechas, estado y rol, presentará la información en la vista correspondiente con enlaces HATEOAS y mostrará al usuario final el mensaje satisfactorio `TIN_CON_EXI_04701`. | `TIN_CON_EXI_04701` | ✅ Aceptado  |
| CONTIN-CA2 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar los empleados de un rol específico, **cuando** intente realizar la consulta con un identificador de rol que no existe o no tiene empleados asociados en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `TIN_CON_ERR_04702` indicando que no se encontraron empleados de ese rol y permitirá realizar una nueva búsqueda.                                                               | `TIN_CON_ERR_04702` | ✅ Aceptado  |
| CONTIN-CA3 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar los empleados de un rol específico, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `TIN_CON_ERR_04703` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                                                                  | `TIN_CON_ERR_04703` | ✅ Aceptado  |

---

## Archivos Principales Modificados

| Categoría      | Archivos                                                                                 |
| -------------- | ---------------------------------------------------------------------------------------- |
| **Handlers**   | `airport_controller.go` (handler: `GetAirportsByType`)                                   |
|                | `employee_controller.go` (handler: `GetEmployeesByRole`)                                 |
|                | `employee.go` (DTO: `EmployeeListResponse`, func: `ToEmployeeListResponse`)              |
| **Interactor** | `interactor_airport.go` (método: `GetAirportsByType`)                                    |
|                | `interactor.go` (método: `GetEmployeesByRole`)                                           |
| **Services**   | `airport_services.go` (método: `GetAirportsByType`)                                      |
|                | `employee_services.go` (método: `GetEmployeesByRole`)                                    |
| **Ports**      | `input/service.go`, `output/repository.go` (nuevos métodos en interfaces)                |
| **Repository** | `repositories/airport/repository.go` (query: `QueryGetByType`)                           |
|                | `repositories/airport/get_by_location.go` (método: `GetAirportsByType`)                  |
|                | `repositories/employee/repository.go` (query: `QueryByRole`, método: `GetEmployeesByRole`) |
| **Server**     | `server/server.go` (rutas: `GET /airport-types/:airport_type`, `GET /crew-member-types/:role`) |
| **SQL**        | `docs/sql/add_airport_type_messages.sql`                                                 |
|                | `docs/sql/add_crew_member_type_messages.sql`                                             |
| **Tests**      | `mocks/mock_repository.go`, `airport_services_test.go`, `employee_services_test.go`      |
|                | `interactor_test.go`, `interactor_readonly_test.go`, `http_test.go`                      |

---

## Códigos de Mensaje Implementados

### Mensajes de Éxito en errors.go

| Constante                | Código              | Tipo   |
| ------------------------ | -------------------- | ------ |
| `MsgAirportTypeGetOK`    | `TAE_CON_EXI_04601`  | Éxito  |
| `MsgCrewMemberTypeGetOK` | `TIN_CON_EXI_04701`  | Éxito  |

### Mensajes de Error en errors.go

| Constante                   | Código              | Tipo  |
| --------------------------- | -------------------- | ----- |
| `MsgAirportTypeNotFound`    | `TAE_CON_ERR_04602`  | Error |
| `MsgAirportTypeGetErr`      | `TAE_CON_ERR_04603`  | Error |
| `MsgCrewMemberTypeNotFound` | `TIN_CON_ERR_04702`  | Error |
| `MsgCrewMemberTypeGetErr`   | `TIN_CON_ERR_04703`  | Error |

### Errores de Dominio en errors.go

| Variable                    | Código de Error                    |
| --------------------------- | ---------------------------------- |
| `ErrAirportTypeNotFound`    | `ERR_AIRPORT_TYPE_NOT_FOUND`       |
| `ErrCrewMemberTypeNotFound` | `ERR_CREW_MEMBER_TYPE_NOT_FOUND`   |

### Mapeo HTTP Status en cache.go

| Código              | HTTP Status | Descripción                                   |
| -------------------- | ----------- | --------------------------------------------- |
| `TAE_CON_EXI_04601`  | 200         | Aeropuertos del tipo consultados exitosamente |
| `TAE_CON_ERR_04602`  | 404         | Tipo de aeropuerto no encontrado              |
| `TAE_CON_ERR_04603`  | 500         | Error técnico al consultar tipo aeropuerto    |
| `TIN_CON_EXI_04701`  | 200         | Empleados del rol consultados exitosamente    |
| `TIN_CON_ERR_04702`  | 404         | Tipo de integrante no encontrado              |
| `TIN_CON_ERR_04703`  | 500         | Error técnico al consultar tipo integrante    |

---

## Endpoints API

| Método | Endpoint                                               | Descripción                              | Auth  |
| ------ | ------------------------------------------------------ | ---------------------------------------- | ----- |
| GET    | `/flighthours/api/v1/airport-types/{airport_type}`     | Obtiene aeropuertos de un tipo           | No    |
| GET    | `/flighthours/api/v1/crew-member-types/{role}`         | Obtiene empleados de un rol              | No    |

---

## Ejemplos de Respuesta

### GET /airport-types/INTERNATIONAL - Éxito

```json
{
  "airports": [
    {
      "id": "xK7mN2pQ9rLw",
      "name": "El Dorado International Airport",
      "city": "Bogota",
      "country": "Colombia",
      "iata_code": "BOG",
      "status": true,
      "airport_type": "INTERNATIONAL",
      "_links": [
        { "rel": "self", "href": "/flighthours/api/v1/airports/xK7mN2pQ9rLw" }
      ]
    },
    {
      "id": "yL8nO3qR0sMx",
      "name": "Alfonso Bonilla Aragón",
      "city": "Cali",
      "country": "Colombia",
      "iata_code": "CLO",
      "status": true,
      "airport_type": "INTERNATIONAL",
      "_links": [
        { "rel": "self", "href": "/flighthours/api/v1/airports/yL8nO3qR0sMx" }
      ]
    }
  ],
  "total": 2,
  "_links": [
    { "rel": "airports", "href": "/flighthours/api/v1/airports" }
  ]
}
```

### GET /airport-types/INVALID - Error Not Found

```json
{
  "success": false,
  "code": "TAE_CON_ERR_04602",
  "message": "No se encontraron aeropuertos del tipo especificado."
}
```

### GET /crew-member-types/PILOTO - Éxito

```json
{
  "employees": [
    {
      "id": "zM9pP4sT1uNy",
      "name": "Juan Pérez",
      "airline": "ACME Airlines",
      "email": "juan@acme.com",
      "identification_number": "123456789",
      "bp": "BP001",
      "start_date": "2025-01-01T00:00:00Z",
      "end_date": "2026-12-31T00:00:00Z",
      "active": true,
      "role": "PILOTO",
      "_links": [
        { "rel": "self", "href": "/flighthours/api/v1/employees/zM9pP4sT1uNy" }
      ]
    }
  ],
  "count": 1,
  "_links": [
    { "rel": "self", "href": "/flighthours/api/v1/crew-member-types" },
    { "rel": "employees", "href": "/flighthours/api/v1/employees" }
  ]
}
```

### GET /crew-member-types/INVALID - Error Not Found

```json
{
  "success": false,
  "code": "TIN_CON_ERR_04702",
  "message": "No se encontraron empleados del rol especificado."
}
```

---

## Query SQL Implementadas

```sql
-- QueryGetByType: Obtener todos los aeropuertos de un tipo específico
SELECT
    a.id,
    a.name,
    a.city,
    a.country,
    a.iata_code,
    a.status,
    a.airport_type
FROM airport a
WHERE a.airport_type = ?
ORDER BY a.name

-- QueryByRole: Obtener todos los empleados de un rol específico
SELECT
    e.id,
    e.name,
    e.airline,
    e.email,
    e.password,
    e.identification_number,
    e.bp,
    e.start_date,
    e.end_date,
    e.active,
    e.role,
    e.keycloak_user_id
FROM employee e
WHERE e.role = ?
ORDER BY e.name
```

---

## Notas de Release

1. Este release implementa la consulta de Tipo de Aeropuerto (HU46) y Tipo de Integrante (HU47).
2. **NO se crean tablas adicionales** - Se reutilizan los campos `airport.airport_type` y `employee.role`.
3. **Patrón Virtual Entity**: Consultas directas sobre campos VARCHAR existentes.
4. Se aprovecha la infraestructura existente de los módulos `airport` y `employee`.
5. Ambos endpoints son públicos (no requieren autenticación).
6. El "ID" de tipo/rol es un string directo (ej: "INTERNATIONAL", "PILOTO"), no un UUID.
7. Se implementa HATEOAS (Richardson Maturity Model Level 3) para navegación.
8. La arquitectura sigue el patrón hexagonal: Handler → Interactor → Service → Repository.
9. Los mensajes se cargan desde la tabla `system_messages` a través del sistema de cache.
10. Retorna código 404 cuando no hay registros para el tipo/rol especificado.
11. Los IDs de empleados en las respuestas están ofuscados usando el encoder HashID.
