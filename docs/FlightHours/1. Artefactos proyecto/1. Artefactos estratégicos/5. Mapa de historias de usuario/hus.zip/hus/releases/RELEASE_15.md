# Release 15: Empleado Aerolínea - CRUD

**Tag Git**: `v0.16.0`
**Estado**: ✅ Completado
**Total Horas**: 20h
**Fecha de implementación:** 2026-01-21

## Historias de Usuario

| HU   | Descripción                                               | Horas | Endpoint                                        | Estado | Full Stack |
| ---- | --------------------------------------------------------- | ----- | ----------------------------------------------- | ------ | ---------- |
| HU26 | Consultar la Información del Empleado Aerolínea           | 4h    | `GET /airline-employees/{id}`                   | ✅     | 🟡         |
| HU27 | Editar el Empleado de la Aerolínea                        | 4h    | `PUT /airline-employees/{id}`                   | ✅     | 🟡         |
| HU28 | Agregar la Información del Empleado de la Aerolínea       | 4h    | `POST /airline-employees`                       | ✅     | 🟡         |
| HU29 | Activar el Empleado de la Aerolínea                       | 4h    | `PATCH /airline-employees/{id}/activate`        | ✅     | 🟡         |
| HU30 | Inactivar el Empleado de la Aerolínea                     | 4h    | `PATCH /airline-employees/{id}/deactivate`      | ✅     | 🟡         |

## Dependencias

- ✅ Release 1: Empleado (tabla base)
- ✅ Release 2: Aerolínea (FK airline)

## Estructura del Módulo Airline Employee

```
core/
├── interactor/
│   ├── interactor_airline_employee.go
│   └── services/
│       ├── airline_employee_services.go
│       └── domain/
│           └── airline_employee.go
handlers/
├── airline_employee.go
└── airline_employee_controller.go
platform/databases/repositories/airline_employee/
├── airline_employee.go
├── repository.go
├── get_by_id.go
├── list.go
├── save.go
├── update.go
└── update_status.go
```

## Notas Técnicas

> 📋 **Empleado Aerolínea** es una vista especializada del empleado donde `airline IS NOT NULL`.
> 🔗 **Relación**: employee.airline → airline.id
> 💡 Esta release extiende la funcionalidad del empleado para gestión específica por aerolínea.
> 📊 **Campos relevantes**: airline, bp (código de piloto), active
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.

---

## Escenarios de Prueba

### HU26 - Consultar la Información del Empleado Aerolínea

| Código       | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                         | Código Mensaje          | Estado       |
| ------------ | --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------- | ------------ |
| CONEAE-CA1   | ✅ Éxito  | **Dado** que un Usuario del Sistema quiere consultar la información de un empleado de aerolínea, **cuando** acceda a la funcionalidad correspondiente y proporcione un ID válido (ofuscado), **entonces** el sistema mostrará correctamente los datos del empleado incluyendo nombre, aerolínea, email, identificación, bp, fechas, estado y rol, presentará la información con enlaces HATEOAS y mostrará al usuario final el mensaje satisfactorio `EMP_AIR_CON_EXI_02601`. | `EMP_AIR_CON_EXI_02601` | ✅ Aceptado  |
| CONEAE-CA2   | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar la información de un empleado de aerolínea, **cuando** intente realizar la consulta con un ID que no existe o que corresponde a un empleado sin aerolínea asociada, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `EMP_AIR_CON_ERR_02602` indicando que el empleado no fue encontrado y permitirá realizar una nueva búsqueda.                                   | `EMP_AIR_CON_ERR_02602` | ✅ Aceptado  |
| CONEAE-CA3   | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar la información de un empleado de aerolínea, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `EMP_AIR_CON_ERR_02603` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                         | `EMP_AIR_CON_ERR_02603` | ✅ Aceptado  |

### HU27 - Editar el Empleado de la Aerolínea

| Código       | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Código Mensaje          | Estado       |
| ------------ | --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------- | ------------ |
| EDIEAE-CA1   | ✅ Éxito  | **Dado** que un Usuario del Sistema quiere editar la información de un empleado de aerolínea, **cuando** proporcione un ID válido y los datos actualizados (nombre, aerolínea, email, identificación, bp, fechas, rol), **entonces** el sistema actualizará los datos correctamente, presentará la información actualizada con enlaces HATEOAS y mostrará al usuario final el mensaje satisfactorio `EMP_AIR_UPD_EXI_02701`.                                                     | `EMP_AIR_UPD_EXI_02701` | ✅ Aceptado  |
| EDIEAE-CA2   | ❌ Error  | **Dado** que un Usuario del Sistema quiere editar la información de un empleado de aerolínea, **cuando** intente actualizar con un ID que no existe, **entonces** el sistema no ejecutará la actualización, mostrará al usuario final el mensaje de advertencia `EMP_AIR_UPD_ERR_02702` indicando que el empleado no fue encontrado.                                                                                                                                            | `EMP_AIR_UPD_ERR_02702` | ✅ Aceptado  |
| EDIEAE-CA3   | ❌ Error  | **Dado** que un Usuario del Sistema quiere editar la información de un empleado de aerolínea, **cuando** proporcione datos inválidos (fechas incorrectas, email duplicado, FK de aerolínea inexistente), **entonces** el sistema no ejecutará la actualización, mostrará al usuario final el mensaje de error `EMP_AIR_UPD_ERR_02703` indicando el problema de validación.                                                                                                        | `EMP_AIR_UPD_ERR_02703` | ✅ Aceptado  |

### HU28 - Agregar la Información del Empleado de la Aerolínea

| Código       | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Código Mensaje          | Estado       |
| ------------ | --------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------- | ------------ |
| AGREAE-CA1   | ✅ Éxito  | **Dado** que un Usuario del Sistema quiere agregar un nuevo empleado de aerolínea, **cuando** proporcione los datos requeridos (nombre, aerolínea, email, identificación, bp, fechas, rol), **entonces** el sistema creará el nuevo empleado correctamente, presentará la información creada con enlaces HATEOAS y mostrará al usuario final el mensaje satisfactorio `EMP_AIR_CRE_EXI_02801`.                                                                                  | `EMP_AIR_CRE_EXI_02801` | ✅ Aceptado  |
| AGREAE-CA2   | ❌ Error  | **Dado** que un Usuario del Sistema quiere agregar un nuevo empleado de aerolínea, **cuando** proporcione un ID de aerolínea que no existe en el sistema, **entonces** el sistema no creará el empleado, mostrará al usuario final el mensaje de error `EMP_AIR_CRE_ERR_02802` indicando que la aerolínea especificada no existe.                                                                                                                                             | `EMP_AIR_CRE_ERR_02802` | ✅ Aceptado  |
| AGREAE-CA3   | ❌ Error  | **Dado** que un Usuario del Sistema quiere agregar un nuevo empleado de aerolínea, **cuando** proporcione datos inválidos (email duplicado, fechas incorrectas, campos requeridos faltantes), **entonces** el sistema no creará el empleado, mostrará al usuario final el mensaje de error `EMP_AIR_CRE_ERR_02803` indicando el problema de validación.                                                                                                                          | `EMP_AIR_CRE_ERR_02803` | ✅ Aceptado  |

### HU29 - Activar el Empleado de la Aerolínea

| Código       | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                | Código Mensaje          | Estado       |
| ------------ | --------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------- | ------------ |
| ACTEAE-CA1   | ✅ Éxito  | **Dado** que un Usuario del Sistema quiere activar un empleado de aerolínea, **cuando** proporcione un ID válido de un empleado que actualmente está inactivo, **entonces** el sistema cambiará el estado a activo, presentará la información actualizada con enlaces HATEOAS y mostrará al usuario final el mensaje satisfactorio `EMP_AIR_ACT_EXI_02901`.                                                           | `EMP_AIR_ACT_EXI_02901` | ✅ Aceptado  |
| ACTEAE-CA2   | ❌ Error  | **Dado** que un Usuario del Sistema quiere activar un empleado de aerolínea, **cuando** intente activar con un ID que no existe, **entonces** el sistema no ejecutará la operación, mostrará al usuario final el mensaje de error `EMP_AIR_ACT_ERR_02902` indicando que el empleado no fue encontrado.                                                                                                               | `EMP_AIR_ACT_ERR_02902` | ✅ Aceptado  |
| ACTEAE-CA3   | ❌ Error  | **Dado** que un Usuario del Sistema quiere activar un empleado de aerolínea, **cuando** ocurra un error técnico durante el proceso, **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error `EMP_AIR_ACT_ERR_02903` y recomendará intentar nuevamente.                                                                                                                 | `EMP_AIR_ACT_ERR_02903` | ✅ Aceptado  |

### HU30 - Inactivar el Empleado de la Aerolínea

| Código       | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                   | Código Mensaje          | Estado       |
| ------------ | --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------- | ------------ |
| INAEAE-CA1   | ✅ Éxito  | **Dado** que un Usuario del Sistema quiere inactivar un empleado de aerolínea, **cuando** proporcione un ID válido de un empleado que actualmente está activo, **entonces** el sistema cambiará el estado a inactivo, presentará la información actualizada con enlaces HATEOAS y mostrará al usuario final el mensaje satisfactorio `EMP_AIR_DEA_EXI_03001`.                                                         | `EMP_AIR_DEA_EXI_03001` | ✅ Aceptado  |
| INAEAE-CA2   | ❌ Error  | **Dado** que un Usuario del Sistema quiere inactivar un empleado de aerolínea, **cuando** intente inactivar con un ID que no existe, **entonces** el sistema no ejecutará la operación, mostrará al usuario final el mensaje de error `EMP_AIR_DEA_ERR_03002` indicando que el empleado no fue encontrado.                                                                                                            | `EMP_AIR_DEA_ERR_03002` | ✅ Aceptado  |
| INAEAE-CA3   | ❌ Error  | **Dado** que un Usuario del Sistema quiere inactivar un empleado de aerolínea, **cuando** ocurra un error técnico durante el proceso, **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error `EMP_AIR_DEA_ERR_03003` y recomendará intentar nuevamente.                                                                                                                | `EMP_AIR_DEA_ERR_03003` | ✅ Aceptado  |

---

## Códigos de Mensaje Implementados

### Mensajes de Éxito en errors.go

| Constante                            | Código                  | Tipo   |
| ------------------------------------ | ----------------------- | ------ |
| `MsgAirlineEmployeeGetOK`            | `EMP_AIR_CON_EXI_02601` | Éxito  |
| `MsgAirlineEmployeeUpdateOK`         | `EMP_AIR_UPD_EXI_02701` | Éxito  |
| `MsgAirlineEmployeeCreateOK`         | `EMP_AIR_CRE_EXI_02801` | Éxito  |
| `MsgAirlineEmployeeActivateOK`       | `EMP_AIR_ACT_EXI_02901` | Éxito  |
| `MsgAirlineEmployeeDeactivateOK`     | `EMP_AIR_DEA_EXI_03001` | Éxito  |
| `MsgAirlineEmployeeListOK`           | `EMP_AIR_LST_EXI_02604` | Éxito  |

### Mensajes de Error en errors.go

| Constante                            | Código                  | Tipo  |
| ------------------------------------ | ----------------------- | ----- |
| `MsgAirlineEmployeeNotFound`         | `EMP_AIR_CON_ERR_02602` | Error |
| `MsgAirlineEmployeeGetError`         | `EMP_AIR_CON_ERR_02603` | Error |
| `MsgAirlineEmployeeUpdateNotFound`   | `EMP_AIR_UPD_ERR_02702` | Error |
| `MsgAirlineEmployeeUpdateError`      | `EMP_AIR_UPD_ERR_02703` | Error |
| `MsgAirlineEmployeeCreateAirlineErr` | `EMP_AIR_CRE_ERR_02802` | Error |
| `MsgAirlineEmployeeCreateError`      | `EMP_AIR_CRE_ERR_02803` | Error |
| `MsgAirlineEmployeeActivateNotFound` | `EMP_AIR_ACT_ERR_02902` | Error |
| `MsgAirlineEmployeeActivateError`    | `EMP_AIR_ACT_ERR_02903` | Error |
| `MsgAirlineEmployeeDeactNotFound`    | `EMP_AIR_DEA_ERR_03002` | Error |
| `MsgAirlineEmployeeDeactError`       | `EMP_AIR_DEA_ERR_03003` | Error |

### Errores de Dominio en errors.go

| Variable                           | Código de Error                      |
| ---------------------------------- | ------------------------------------ |
| `ErrAirlineEmployeeNotFound`       | `ERR_AIRLINE_EMPLOYEE_NOT_FOUND`     |
| `ErrAirlineEmployeeCannotSave`     | `ERR_AIRLINE_EMPLOYEE_CANNOT_SAVE`   |
| `ErrAirlineEmployeeCannotUpdate`   | `ERR_AIRLINE_EMPLOYEE_CANNOT_UPDATE` |
| `ErrAirlineEmployeeInvalidAirline` | `ERR_AIRLINE_EMPLOYEE_INVALID_AIRLINE` |

### Mapeo HTTP Status en cache.go

| Código                  | HTTP Status | Descripción                              |
| ----------------------- | ----------- | ---------------------------------------- |
| `EMP_AIR_CON_EXI_02601` | 200         | Empleado aerolínea consultado exitosamente |
| `EMP_AIR_CON_ERR_02602` | 404         | Empleado aerolínea no encontrado         |
| `EMP_AIR_CON_ERR_02603` | 500         | Error técnico al consultar               |
| `EMP_AIR_LST_EXI_02604` | 200         | Listado exitoso                          |
| `EMP_AIR_UPD_EXI_02701` | 200         | Actualizado exitosamente                 |
| `EMP_AIR_UPD_ERR_02702` | 404         | No encontrado al actualizar              |
| `EMP_AIR_UPD_ERR_02703` | 400         | Error de validación al actualizar        |
| `EMP_AIR_CRE_EXI_02801` | 201         | Creado exitosamente                      |
| `EMP_AIR_CRE_ERR_02802` | 400         | Aerolínea inválida                       |
| `EMP_AIR_CRE_ERR_02803` | 400         | Error de validación al crear             |
| `EMP_AIR_ACT_EXI_02901` | 200         | Activado exitosamente                    |
| `EMP_AIR_ACT_ERR_02902` | 404         | No encontrado al activar                 |
| `EMP_AIR_ACT_ERR_02903` | 500         | Error técnico al activar                 |
| `EMP_AIR_DEA_EXI_03001` | 200         | Desactivado exitosamente                 |
| `EMP_AIR_DEA_ERR_03002` | 404         | No encontrado al desactivar              |
| `EMP_AIR_DEA_ERR_03003` | 500         | Error técnico al desactivar              |

---

## Diferencia con Release 1

- **Release 1**: CRUD genérico de empleado (self-service)
- **Release 15**: Gestión de empleados por aerolínea (admin de aerolínea)

---

# Implementación Completada

## Resumen

Implementación completa del módulo **Airline Employee** (Empleado Aerolínea) que permite gestionar empleados asociados a una aerolínea específica. Este módulo es una **vista especializada** de la tabla `employee` donde `airline IS NOT NULL`.

---

## Endpoints Implementados

| Método | Endpoint | Descripción | HU |
|--------|----------|-------------|-----|
| `GET` | `/airline-employees` | Listar empleados de aerolínea | - |
| `GET` | `/airline-employees/:id` | Consultar empleado por ID | HU26 |
| `PUT` | `/airline-employees/:id` | Editar empleado | HU27 |
| `POST` | `/airline-employees` | Agregar empleado | HU28 |
| `PATCH` | `/airline-employees/:id/activate` | Activar empleado | HU29 |
| `PATCH` | `/airline-employees/:id/deactivate` | Inactivar empleado | HU30 |

### Query Parameters (Filtros)
- `?airline_id=xxx` - Filtrar por ID de aerolínea (ofuscado)
- `?active=true/false` - Filtrar por estado activo/inactivo

---

## Archivos Creados

### 1. Domain (Capa de Dominio)
```
core/interactor/services/domain/airline_employee.go
```
- Modelo de dominio `AirlineEmployee` con campos desnormalizados de airline

### 2. Repository (Capa de Persistencia)
```
platform/databases/repositories/airline_employee/
├── airline_employee.go    # Entidad DB con ToDomain/FromDomain
├── repository.go          # Queries SQL y constructor
├── get_by_id.go          # HU26 - Consultar por ID
├── list.go               # Listar con filtros
├── save.go               # HU28 - Crear nuevo
├── update.go             # HU27 - Actualizar
└── update_status.go      # HU29/HU30 - Activar/Desactivar
```

### 3. Service (Capa de Servicio)
```
core/interactor/services/airline_employee_services.go
```
- Implementa `AirlineEmployeeService` interface
- Lógica de negocio para todas las operaciones CRUD

### 4. Interactor (Capa de Orquestación)
```
core/interactor/interactor_airline_employee.go
```
- `AirlineEmployeeInteractor` que orquesta operaciones con logging

### 5. Handler (Capa HTTP)
```
handlers/airline_employee.go            # DTOs Request/Response
handlers/airline_employee_controller.go # Controladores HTTP
```

---

## Archivos Modificados

### 1. Puertos/Interfaces
- `core/ports/output/repository.go` - Agregada `AirlineEmployeeRepository` interface
- `core/ports/input/service.go` - Agregada `AirlineEmployeeService` interface

### 2. Errores y Mensajes
- `core/interactor/services/domain/erros.go` - Agregados errores y códigos de mensaje:
  - `ErrAirlineEmployeeNotFound`
  - `ErrAirlineEmployeeCannotSave`
  - `ErrAirlineEmployeeCannotUpdate`
  - `ErrAirlineEmployeeInvalidAirline`
  - Códigos de mensaje: `EMP_AIR_*`

### 3. Handler
- `handlers/handler.go` - Agregado `AirlineEmployeeInteractor` al struct y constructor
- `handlers/hateoas.go` - Agregadas funciones HATEOAS para airline-employees

### 4. Dependencias
- `cmd/dependency/dependency.go` - Inicialización de repo/service/interactor

### 5. Rutas
- `server/server.go` - Agregados 6 nuevos endpoints bajo rutas protegidas

### 6. Tests
- `handlers/airline_http_test.go` - Actualizado con nuevo parámetro
- `handlers/airport_http_test.go` - Actualizado con nuevo parámetro
- `handlers/http_test.go` - Actualizado con nuevo parámetro
- `handlers/message_http_test.go` - Actualizado con nuevo parámetro

---

## Queries SQL Implementadas

### GET by ID (HU26)
```sql
SELECT e.id, e.name, e.airline, a.airline_name, a.airline_code, e.email,
       e.identification_number, e.bp, e.start_date, e.end_date, e.active,
       e.role, e.keycloak_user_id
FROM employee e
JOIN airline a ON e.airline = a.id
WHERE e.id = ? AND e.airline IS NOT NULL
```

### Filtros
- Por `airline_id`
- Por `active` (status)

---

## Validaciones Implementadas

1. **Fechas**: `start_date` debe ser anterior a `end_date`
2. **Foreign Key**: Validación de aerolínea existente
3. **Duplicados**: Validación de email único
4. **Formato de fecha**: Esperado `YYYY-MM-DD`

---

## Estructura de Request/Response

### Request (POST/PUT)
```json
{
  "name": "string",
  "airline_id": "string (obfuscated)",
  "email": "string",
  "identification_number": "string",
  "bp": "string (optional)",
  "start_date": "YYYY-MM-DD",
  "end_date": "YYYY-MM-DD (optional)",
  "active": true,
  "role": "string"
}
```

### Response
```json
{
  "id": "string (obfuscated)",
  "name": "string",
  "airline_id": "string (obfuscated)",
  "airline_name": "string",
  "airline_code": "string",
  "email": "string",
  "identification_number": "string",
  "bp": "string",
  "start_date": "2006-01-02T00:00:00Z",
  "end_date": "2006-01-02T00:00:00Z",
  "active": true,
  "role": "string",
  "_links": [...]
}
```

---

## Verificación

- ✅ `go build ./...` - Compilación exitosa
- ✅ `go test ./...` - Todos los tests pasan
- ✅ Sin breaking changes en funcionalidades existentes

---

## Notas Técnicas de Implementación

1. **Vista Especializada**: Este módulo opera sobre la tabla `employee` existente, filtrando por `airline IS NOT NULL`. No se creó una nueva tabla.

2. **Datos Desnormalizados**: El response incluye `airline_name` y `airline_code` obtenidos via JOIN para evitar llamadas adicionales.

3. **ID Ofuscación**: Todos los IDs (employee y airline) se ofuscan/desofuscan automáticamente.

4. **HATEOAS**: Cada respuesta incluye links a operaciones relacionadas.

---

## Refactorización Adicional (Estandarización de Repositorios)

Como parte de este release, también se estandarizaron los siguientes repositorios:

| Repositorio | Archivos creados |
|------------|------------------|
| `engine` | `engine.go`, `get_by_id.go`, `list.go` |
| `manufacturer` | `manufacturer.go`, `get_by_id.go`, `list.go` |
| `aircraft_model` | `aircraft_model.go`, `get_by_id.go`, `list.go`, `get_by_family.go` |
| `route` | `route.go`, `get_by_id.go`, `list.go` |
| `airline_route` | `airline_route.go`, `get_by_id.go`, `list.go`, `update_status.go` |

Patrón aplicado:
- `repository.go` → Solo estructura, queries y constructor
- `{entity}.go` → Entidad DB con `ToDomain()` / `FromDomain()`
- `{operacion}.go` → Un archivo por operación

