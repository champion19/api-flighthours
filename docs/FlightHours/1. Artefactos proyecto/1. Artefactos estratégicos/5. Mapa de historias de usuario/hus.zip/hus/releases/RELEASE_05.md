# Release 05 - Módulo de Bitácora Diaria

## Información General

| Campo | Valor |
|-------|-------|
| **Versión** | v0.6.0 |
| **Rama** | develop |
| **Sprint** | Sprint 5 |
| **Horas Planificadas** | 32 horas |
| **Pull Requests** | #18 |

---

## Historias de Usuario Incluidas

| Código | Historia de Usuario | Talla | Horas | Full Stack |
|--------|---------------------|-------|-------|------------|
| HU7 | Consultar la Información de la Bitácora Diaria | M | 8 | ✅ |
| HU8 | Agregar la Información de la Bitácora Diaria | M | 8 | ✅ |
| HU9 | Editar la Información de la Bitácora Diaria | S | 4 | ✅ |
| HU10 | Eliminar la Información de la Bitácora Diaria | S | 4 | ✅ |
| HU11 | Activar la Bitácora Diaria | S | 4 | ✅ |
| HU12 | Inactivar la Bitácora Diaria | S | 4 | ✅ |

---

## Componentes Implementados

### 1. Consultar Bitácora Diaria (HU7)
- Endpoint: `GET /flighthours/api/v1/daily-logbooks/:id`
- Acepta UUID o ID ofuscado
- Retorna información completa de la bitácora diaria
- Valida que la bitácora pertenezca al empleado autenticado

### 2. Agregar Bitácora Diaria (HU8)
- Endpoint: `POST /flighthours/api/v1/daily-logbooks`
- Crea una nueva bitácora diaria asociada al empleado autenticado
- Campos: log_date (fecha), book_page (número de página, opcional)

### 3. Editar Bitácora Diaria (HU9)
- Endpoint: `PUT /flighthours/api/v1/daily-logbooks/:id`
- Actualiza la información de una bitácora existente
- Valida propiedad del empleado autenticado

### 4. Eliminar Bitácora Diaria (HU10)
- Endpoint: `DELETE /flighthours/api/v1/daily-logbooks/:id`
- Elimina permanentemente la bitácora
- Valida propiedad del empleado autenticado

### 5. Activar Bitácora Diaria (HU11)
- Endpoint: `PATCH /flighthours/api/v1/daily-logbooks/:id/activate`
- Cambia estado de la bitácora a activo (status = true)
- Valida propiedad del empleado autenticado

### 6. Inactivar Bitácora Diaria (HU12)
- Endpoint: `PATCH /flighthours/api/v1/daily-logbooks/:id/deactivate`
- Cambia estado de la bitácora a inactivo (status = false)
- Valida propiedad del empleado autenticado

---

## Escenarios de Prueba

### HU7 - Consultar la Información de la Bitácora Diaria

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| CONBIT-CA1 | ✅ Éxito | **Dado que** un Piloto del Sistema quiere consultar la información de la Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque una bitácora válida, **entonces** el sistema mostrará correctamente los datos disponibles de la bitácora, presentará la información en la vista correspondiente y mostrará el mensaje satisfactorio `BIT_CON_EXI_01901`. | `BIT_CON_EXI_01901` | ✅ Aceptado |
| CONBIT-CA2 | ❌ Error | **Dado que** un Piloto del Sistema quiere consultar la información de la Bitácora Diaria, **cuando** intente realizar la consulta sin seleccionar previamente una bitácora o sin ingresar criterios de búsqueda válidos, **entonces** el sistema no ejecutará la consulta, mostrará un mensaje de advertencia `BIT_CON_ERR_01902` indicando que debe ingresar o seleccionar una bitácora para continuar, y mantendrá la pantalla activa para corregir. | `BIT_CON_ERR_01902` | ✅ Aceptado |
| CONBIT-CA3 | ❌ Error | **Dado que** un Piloto del Sistema quiere consultar la información de la Bitácora Diaria, **cuando** no existan coincidencias con los criterios de búsqueda ingresados, **entonces** el sistema mostrará el mensaje `BIT_CON_ERR_01903` indicando que no se encontraron resultados y permitirá redefinir los filtros de búsqueda o realizar una nueva consulta. | `BIT_CON_ERR_01903` | ✅ Aceptado |
| CONBIT-CA4 | ❌ Error | **Dado que** un Piloto del Sistema quiere consultar la información de la Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará un mensaje de error general `BIT_CON_ERR_01904` y recomendará intentar nuevamente más tarde o contactar al soporte técnico. | `BIT_CON_ERR_01904` | ✅ Aceptado |

### HU8 - Agregar la Información de la Bitácora Diaria

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| AGRBIT-CA1 | ✅ Éxito | **Dado que** un Piloto del Sistema quiere agregar la información de una Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente, ingrese correctamente todos los datos requeridos y confirme la acción, **entonces** el sistema guardará la información, mostrará al usuario final el mensaje satisfactorio `BIT_AGR_EXI_01801` y reflejará la nueva bitácora en la vista correspondiente. | `BIT_AGR_EXI_01801` | ✅ Aceptado |
| AGRBIT-CA2 | ❌ Error | **Dado que** un Piloto del Sistema quiere agregar la información de una Bitácora Diaria, **cuando** intente realizar la acción sin completar todos los campos obligatorios, **entonces** el sistema no guardará la información, mostrará un mensaje de advertencia `BIT_AGR_ERR_01802` indicando que debe completar todos los campos requeridos y mantendrá el formulario activo para corregir. | `BIT_AGR_ERR_01802` | ✅ Aceptado |
| AGRBIT-CA3 | ❌ Error | **Dado que** un Piloto del Sistema quiere agregar la información de una Bitácora Diaria, **cuando** ingrese datos con formato incorrecto o inválidos, **entonces** el sistema no guardará los datos, mostrará un mensaje de advertencia `BIT_AGR_ERR_01803` indicando los errores a corregir y mantendrá el formulario abierto para ajustes. | `BIT_AGR_ERR_01803` | ✅ Aceptado |
| AGRBIT-CA4 | ❌ Error | **Dado que** un Piloto del Sistema quiere agregar la información de una Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso (como un fallo en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará un mensaje de error general `BIT_AGR_ERR_01804` y recomendará intentar nuevamente más tarde o contactar al soporte técnico. | `BIT_AGR_ERR_01804` | ✅ Aceptado |

### HU9 - Editar la Información de la Bitácora Diaria

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| EDIBIT-CA1 | ✅ Éxito | **Dado que** un Piloto del Sistema quiere editar la información de una Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente, seleccione una bitácora válida e ingrese correctamente los datos requeridos, **entonces** el sistema guardará los cambios, mostrará al usuario final el mensaje satisfactorio `BIT_EDI_EXI_01701` y reflejará la información actualizada en la vista correspondiente. | `BIT_EDI_EXI_01701` | ✅ Aceptado |
| EDIBIT-CA2 | ❌ Error | **Dado que** un Piloto del Sistema quiere editar la información de una Bitácora Diaria, **cuando** intente realizar la modificación sin haber seleccionado previamente una bitácora válida, **entonces** el sistema no permitirá continuar, mostrará un mensaje de advertencia `BIT_EDI_ERR_01702` indicando que debe seleccionar una bitácora para modificar, y la pantalla permanecerá activa para corregir. | `BIT_EDI_ERR_01702` | ✅ Aceptado |
| EDIBIT-CA3 | ❌ Error | **Dado que** un Piloto del Sistema quiere editar la información de una Bitácora Diaria, **cuando** ingrese datos incompletos, inválidos o con formato incorrecto, **entonces** el sistema no guardará los cambios, mostrará un mensaje de advertencia `BIT_EDI_ERR_01703` indicando los errores a corregir y mantendrá el formulario abierto para ajustes. | `BIT_EDI_ERR_01703` | ✅ Aceptado |
| EDIBIT-CA4 | ❌ Error | **Dado que** un Piloto del Sistema quiere editar la información de una Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso (como un fallo en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará un mensaje de error general `BIT_EDI_ERR_01704` y recomendará intentar nuevamente más tarde o contactar al soporte técnico. | `BIT_EDI_ERR_01704` | ✅ Aceptado |

### HU10 - Eliminar la Información de la Bitácora Diaria

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| DELBIT-CA1 | ✅ Éxito | **Dado que** un Piloto del Sistema quiere eliminar la información de una Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente, seleccione una bitácora válida y confirme la acción de eliminación, **entonces** el sistema eliminará correctamente la información de la bitácora, mostrará al usuario final el mensaje satisfactorio `BIT_DEL_EXI_01601` y reflejará la eliminación en la vista correspondiente. | `BIT_DEL_EXI_01601` | ✅ Aceptado |
| DELBIT-CA2 | ❌ Error | **Dado que** un Piloto del Sistema quiere eliminar la información de una Bitácora Diaria, **cuando** intente realizar la eliminación sin haber seleccionado previamente una bitácora válida, **entonces** el sistema no permitirá continuar, mostrará un mensaje de advertencia `BIT_DEL_ERR_01602` indicando que debe seleccionar una bitácora para eliminar, y la pantalla permanecerá activa para corregir. | `BIT_DEL_ERR_01602` | ✅ Aceptado |
| DELBIT-CA3 | ❌ Error | **Dado que** un Piloto del Sistema quiere eliminar la información de una Bitácora Diaria, **cuando** intente eliminar una bitácora que ya ha sido eliminada previamente o que no existe en el sistema, **entonces** el sistema no podrá completar la operación, mostrará un mensaje de advertencia `BIT_DEL_ERR_01603` indicando que la bitácora no existe o ya fue eliminada, y permitirá al usuario seleccionar otro registro. | `BIT_DEL_ERR_01603` | ✅ Aceptado |
| DELBIT-CA4 | ❌ Error | **Dado que** un Piloto del Sistema quiere eliminar la información de una Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso (como fallo en la base de datos o problemas de conexión), **entonces** el sistema no podrá completar la operación, mostrará un mensaje de error general `BIT_DEL_ERR_01604` y recomendará intentar nuevamente más tarde o contactar al soporte técnico. | `BIT_DEL_ERR_01604` | ✅ Aceptado |

### HU11 - Activar la Bitácora Diaria

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| ACTBIT-CA1 | ✅ Éxito | **Dado que** un Piloto del Sistema quiere activar una Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente, seleccione una bitácora inactiva válida y confirme la acción de activación, **entonces** el sistema cambiará el estado de la bitácora a activa, mostrará al usuario final el mensaje satisfactorio `BIT_ACT_EXI_01501` y reflejará el cambio en la vista correspondiente. | `BIT_ACT_EXI_01501` | ✅ Aceptado |
| ACTBIT-CA2 | ❌ Error | **Dado que** un Piloto del Sistema quiere activar una Bitácora Diaria, **cuando** intente realizar la acción sin seleccionar previamente una bitácora válida, **entonces** el sistema no permitirá continuar, mostrará un mensaje de advertencia `BIT_ACT_ERR_01502` indicando que debe seleccionar una bitácora para activar, y la pantalla permanecerá activa para corregir. | `BIT_ACT_ERR_01502` | ✅ Aceptado |
| ACTBIT-CA3 | ❌ Error | **Dado que** un Piloto del Sistema quiere activar una Bitácora Diaria, **cuando** intente activar una bitácora que ya se encuentre activa, **entonces** el sistema no realizará la operación, mostrará un mensaje de advertencia `BIT_ACT_ERR_01503` indicando que la bitácora ya está activa, y mantendrá la vista activa para selección correcta. | `BIT_ACT_ERR_01503` | ✅ Aceptado |
| ACTBIT-CA4 | ❌ Error | **Dado que** un Piloto del Sistema quiere activar una Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso (como fallo en la base de datos o problemas de conexión), **entonces** el sistema no podrá completar la operación, mostrará un mensaje de error general `BIT_ACT_ERR_01504` y recomendará intentar nuevamente más tarde o contactar al soporte técnico. | `BIT_ACT_ERR_01504` | ✅ Aceptado |

### HU12 - Inactivar la Bitácora Diaria

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| INABIT-CA1 | ✅ Éxito | **Dado que** un Piloto del Sistema quiere inactivar una Bitácora Diaria, **cuando** acceda a la funcionalidad correspondiente, seleccione una bitácora válida y confirme la acción de inactivación, **entonces** el sistema cambiará el estado de la bitácora a inactiva, mostrará al usuario final el mensaje satisfactorio `BIT_INA_EXI_01401` y reflejará el cambio en la vista correspondiente. | `BIT_INA_EXI_01401` | ✅ Aceptado |
| INABIT-CA2 | ❌ Error | **Dado que** un Piloto del Sistema quiere inactivar una Bitácora Diaria, **cuando** intente realizar la acción sin seleccionar previamente una bitácora válida, **entonces** el sistema no permitirá continuar, mostrará un mensaje de advertencia `BIT_INA_ERR_01402` indicando que debe seleccionar una bitácora para inactivar, y la pantalla permanecerá activa para corregir. | `BIT_INA_ERR_01402` | ✅ Aceptado |
| INABIT-CA3 | ❌ Error | **Dado que** un Piloto del Sistema quiere inactivar una Bitácora Diaria, **cuando** intente inactivar una bitácora que ya se encuentre inactiva, **entonces** el sistema no realizará la operación, mostrará un mensaje de advertencia `BIT_INA_ERR_01403` indicando que la bitácora ya está inactiva, y mantendrá la vista activa para selección correcta. | `BIT_INA_ERR_01403` | ✅ Aceptado |
| INABIT-CA4 | ❌ Error | **Dado que** un Piloto del Sistema quiere inactivar una Bitácora Diaria, **cuando** ocurra un error técnico durante el proceso (como fallo en la base de datos o problemas de conexión), **entonces** el sistema no podrá completar la operación, mostrará un mensaje de error general `BIT_INA_ERR_01404` y recomendará intentar nuevamente más tarde o contactar al soporte técnico. | `BIT_INA_ERR_01404` | ✅ Aceptado |

---

## Archivos Principales Modificados

| Categoría | Archivos |
|-----------|----------|
| **Handlers** | `daily_logbook_controller.go`, `daily_logbook.go`, `handler.go`, `hateoas.go` |
| **Interactor** | `interactor_daily_logbook.go` |
| **Services** | `daily_logbook_services.go` |
| **Domain** | `domain/daily_logbook.go`, `domain/erros.go` |
| **Ports** | `input/service.go`, `output/repository.go` |
| **Repository** | `repositories/daily_logbook/` (daily_logbook.go, repository.go, get_by_id.go, list_by_employee.go, save.go, update.go, delete.go) |
| **Logger** | `log_messages.go` |
| **Dependency** | `cmd/dependency/dependency.go` |
| **Server** | `server/server.go` |

---

## Códigos de Mensaje Implementados

### Mensajes de Éxito en errors.go

| Constante | Código | Tipo |
|-----------|--------|------|
| `MsgDailyLogbookGetOK` | `BIT_CON_EXI_01901` | Éxito |
| `MsgDailyLogbookCreated` | `BIT_AGR_EXI_01801` | Éxito |
| `MsgDailyLogbookUpdated` | `BIT_EDI_EXI_01701` | Éxito |
| `MsgDailyLogbookDeleted` | `BIT_DEL_EXI_01601` | Éxito |
| `MsgDailyLogbookActivateOK` | `BIT_ACT_EXI_01501` | Éxito |
| `MsgDailyLogbookDeactivateOK` | `BIT_INA_EXI_01401` | Éxito |
| `MsgDailyLogbookListOK` | `BIT_LIST_EXI_01001` | Éxito |

### Mensajes de Error en errors.go

| Constante | Código | Tipo |
|-----------|--------|------|
| `MsgDailyLogbookNotFound` | `BIT_CON_ERR_01903` | Error |
| `MsgDailyLogbookGetErr` | `BIT_CON_ERR_01904` | Error |
| `MsgDailyLogbookSaveError` | `BIT_AGR_ERR_01804` | Error |
| `MsgDailyLogbookUpdateError` | `BIT_EDI_ERR_01704` | Error |
| `MsgDailyLogbookDeleteError` | `BIT_DEL_ERR_01604` | Error |
| `MsgDailyLogbookActivateErr` | `BIT_ACT_ERR_01504` | Error |
| `MsgDailyLogbookDeactivateErr` | `BIT_INA_ERR_01404` | Error |
| `MsgDailyLogbookListError` | `BIT_LIST_ERR_01002` | Error |
| `MsgDailyLogbookUnauthorized` | `BIT_AUTH_ERR_00001` | Error |

### Mensajes Adicionales (solo en BD/Cache)

| Código | Tipo | Descripción |
|--------|------|-------------|
| `BIT_CON_ERR_01902` | Error | Bitácora no seleccionada (consulta) |
| `BIT_AGR_ERR_01802` | Error | Campos requeridos incompletos |
| `BIT_AGR_ERR_01803` | Error | Formato inválido |
| `BIT_EDI_ERR_01702` | Error | Bitácora no seleccionada (editar) |
| `BIT_EDI_ERR_01703` | Error | Datos inválidos |
| `BIT_DEL_ERR_01602` | Error | Bitácora no seleccionada (eliminar) |
| `BIT_DEL_ERR_01603` | Error | Bitácora ya eliminada o no existe |
| `BIT_ACT_ERR_01502` | Error | Bitácora no seleccionada (activar) |
| `BIT_ACT_ERR_01503` | Error | Bitácora ya activa |
| `BIT_INA_ERR_01402` | Error | Bitácora no seleccionada (inactivar) |
| `BIT_INA_ERR_01403` | Error | Bitácora ya inactiva |


### Errores de Dominio en errors.go

| Variable | Código de Error |
|----------|-----------------|
| `ErrDailyLogbookNotFound` | `ERR_DAILY_LOGBOOK_NOT_FOUND` |
| `ErrDailyLogbookCannotSave` | `ERR_DAILY_LOGBOOK_CANNOT_SAVE` |
| `ErrDailyLogbookCannotUpdate` | `ERR_DAILY_LOGBOOK_CANNOT_UPDATE` |
| `ErrDailyLogbookCannotDelete` | `ERR_DAILY_LOGBOOK_CANNOT_DELETE` |
| `ErrDailyLogbookUnauthorized` | `ERR_DAILY_LOGBOOK_UNAUTHORIZED` |

### SQL para insertar mensajes en la BD

```sql
-- Mensajes de Éxito
INSERT INTO message (id, code, type, category, module, title, content, active) VALUES
(UUID(), 'BIT_CON_EXI_01901', 'SUCCESS', 'backend', 'daily_logbook', 'Bitácora consultada', 'La información de la bitácora diaria se obtuvo exitosamente', true),
(UUID(), 'BIT_AGR_EXI_01801', 'SUCCESS', 'backend', 'daily_logbook', 'Bitácora creada', 'La bitácora diaria se ha creado exitosamente', true),
(UUID(), 'BIT_EDI_EXI_01701', 'SUCCESS', 'backend', 'daily_logbook', 'Bitácora actualizada', 'La bitácora diaria se ha actualizado exitosamente', true),
(UUID(), 'BIT_DEL_EXI_01601', 'SUCCESS', 'backend', 'daily_logbook', 'Bitácora eliminada', 'La bitácora diaria se ha eliminado exitosamente', true),
(UUID(), 'BIT_ACT_EXI_01501', 'SUCCESS', 'backend', 'daily_logbook', 'Bitácora activada', 'La bitácora diaria se ha activado exitosamente', true),
(UUID(), 'BIT_INA_EXI_01401', 'SUCCESS', 'backend', 'daily_logbook', 'Bitácora inactivada', 'La bitácora diaria se ha inactivado exitosamente', true);

-- Mensajes de Error - Consultar
INSERT INTO message (id, code, type, category, module, title, content, active) VALUES
(UUID(), 'BIT_CON_ERR_01902', 'ERROR', 'backend', 'daily_logbook', 'Bitácora no seleccionada', 'Debe ingresar o seleccionar una bitácora para continuar', true),
(UUID(), 'BIT_CON_ERR_01903', 'ERROR', 'backend', 'daily_logbook', 'Bitácora no encontrada', 'No se encontraron resultados con los criterios de búsqueda', true),
(UUID(), 'BIT_CON_ERR_01904', 'ERROR', 'backend', 'daily_logbook', 'Error al consultar', 'Ocurrió un error técnico al consultar la bitácora. Intente nuevamente más tarde', true);

-- Mensajes de Error - Agregar
INSERT INTO message (id, code, type, category, module, title, content, active) VALUES
(UUID(), 'BIT_AGR_ERR_01802', 'ERROR', 'backend', 'daily_logbook', 'Campos requeridos', 'Debe completar todos los campos requeridos', true),
(UUID(), 'BIT_AGR_ERR_01803', 'ERROR', 'backend', 'daily_logbook', 'Formato inválido', 'Los datos ingresados tienen formato incorrecto o son inválidos', true),
(UUID(), 'BIT_AGR_ERR_01804', 'ERROR', 'backend', 'daily_logbook', 'Error al crear', 'Ocurrió un error técnico al crear la bitácora. Intente nuevamente más tarde', true);

-- Mensajes de Error - Editar
INSERT INTO message (id, code, type, category, module, title, content, active) VALUES
(UUID(), 'BIT_EDI_ERR_01702', 'ERROR', 'backend', 'daily_logbook', 'Bitácora no seleccionada', 'Debe seleccionar una bitácora para modificar', true),
(UUID(), 'BIT_EDI_ERR_01703', 'ERROR', 'backend', 'daily_logbook', 'Datos inválidos', 'Los datos ingresados son incompletos, inválidos o tienen formato incorrecto', true),
(UUID(), 'BIT_EDI_ERR_01704', 'ERROR', 'backend', 'daily_logbook', 'Error al editar', 'Ocurrió un error técnico al editar la bitácora. Intente nuevamente más tarde', true);

-- Mensajes de Error - Eliminar
INSERT INTO message (id, code, type, category, module, title, content, active) VALUES
(UUID(), 'BIT_DEL_ERR_01602', 'ERROR', 'backend', 'daily_logbook', 'Bitácora no seleccionada', 'Debe seleccionar una bitácora para eliminar', true),
(UUID(), 'BIT_DEL_ERR_01603', 'ERROR', 'backend', 'daily_logbook', 'Bitácora no existe', 'La bitácora no existe o ya fue eliminada previamente', true),
(UUID(), 'BIT_DEL_ERR_01604', 'ERROR', 'backend', 'daily_logbook', 'Error al eliminar', 'Ocurrió un error técnico al eliminar la bitácora. Intente nuevamente más tarde', true);

-- Mensajes de Error - Activar
INSERT INTO message (id, code, type, category, module, title, content, active) VALUES
(UUID(), 'BIT_ACT_ERR_01502', 'ERROR', 'backend', 'daily_logbook', 'Bitácora no seleccionada', 'Debe seleccionar una bitácora para activar', true),
(UUID(), 'BIT_ACT_ERR_01503', 'ERROR', 'backend', 'daily_logbook', 'Bitácora ya activa', 'La bitácora seleccionada ya se encuentra activa', true),
(UUID(), 'BIT_ACT_ERR_01504', 'ERROR', 'backend', 'daily_logbook', 'Error al activar', 'Ocurrió un error técnico al activar la bitácora. Intente nuevamente más tarde', true);

-- Mensajes de Error - Inactivar
INSERT INTO message (id, code, type, category, module, title, content, active) VALUES
(UUID(), 'BIT_INA_ERR_01402', 'ERROR', 'backend', 'daily_logbook', 'Bitácora no seleccionada', 'Debe seleccionar una bitácora para inactivar', true),
(UUID(), 'BIT_INA_ERR_01403', 'ERROR', 'backend', 'daily_logbook', 'Bitácora ya inactiva', 'La bitácora seleccionada ya se encuentra inactiva', true),
(UUID(), 'BIT_INA_ERR_01404', 'ERROR', 'backend', 'daily_logbook', 'Error al inactivar', 'Ocurrió un error técnico al inactivar la bitácora. Intente nuevamente más tarde', true);
```

---

## Notas de Release

1. Este release implementa el CRUD completo de Bitácora Diaria: consultar, agregar, editar, eliminar, activar e inactivar.
2. Todos los endpoints están protegidos y requieren autenticación JWT.
3. Se valida que cada operación solo pueda realizarse sobre bitácoras del empleado autenticado (ownership validation).
4. Los endpoints aceptan tanto UUID directo como ID ofuscado para mayor flexibilidad.
5. Se utiliza el patrón PATCH para las operaciones de activar/desactivar (operación parcial sobre recurso).
6. La arquitectura sigue el patrón hexagonal establecido: Handler → Interactor → Service → Repository.
7. Se implementa HATEOAS para navegación entre recursos relacionados.
8. El campo `book_page` es opcional y permite registrar el número de página del folio físico.
