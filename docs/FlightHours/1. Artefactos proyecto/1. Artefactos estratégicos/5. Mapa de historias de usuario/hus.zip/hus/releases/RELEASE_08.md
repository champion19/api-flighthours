# Release 8: Tipo Aeronave - Gestión de Estado

**Tag Git**: `v0.9.0`
**Estado**: 🔜 Pendiente
**Total Horas**: 8h

## Historias de Usuario

| HU   | Descripción                                     | Horas | Endpoint                                    | Estado | Full Stack |
| ---- | ----------------------------------------------- | ----- | ------------------------------------------- | ------ | ---------- |
| HU44 | Inactivar la información del Tipo Aeronave     | 4h    | `PATCH /aircraft-types/{id}/deactivate`     | 🔜     | 🟡         |
| HU45 | Activar la información del Tipo Aeronave       | 4h    | `PATCH /aircraft-types/{id}/activate`       | 🔜     | 🟡         |

## Dependencias

- ✅ Release 7: Modelo de Aeronave (Consultas implementadas)

## Estructura del Módulo (Extensión)

```
handlers/
├── aircraft_type_controller.go   # Handlers adicionales para activate/deactivate
platform/
└── databases/
    └── repositories/
        └── aircraft_type/
            ├── update_status.go  # Nueva funcionalidad
```

## Notas Técnicas

> ⚠️ **Nota**: Si la tabla `aircraft_model` no tiene campo `status`, se deberá agregar una migración.
> 📋 Esta release extiende la funcionalidad de Release 7 con gestión de estado.
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.
