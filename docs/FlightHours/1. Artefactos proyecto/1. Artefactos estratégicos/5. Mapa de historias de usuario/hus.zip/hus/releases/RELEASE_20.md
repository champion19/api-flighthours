# Release 20: Sistema de Alertas - Limitaciones

**Tag Git**: `v0.21.0`
**Estado**: 🔜 Pendiente
**Total Horas**: 32h

## Historias de Usuario

| HU   | Descripción                                                    | Horas | Endpoint                                  | Estado | Full Stack |
| ---- | -------------------------------------------------------------- | ----- | ----------------------------------------- | ------ | ---------- |
| N/A  | Consultar Alertas de Limitaciones del Empleado                 | 16h   | `GET /employees/{id}/limitation-alerts`   | 🔜     | 🟡         |
| N/A  | Verificar Estado de Limitaciones (sistema)                     | 16h   | `POST /limitation-alerts/check`           | 🔜     | 🟡         |

## Dependencias

- ✅ Release 18: Limitaciones de Vuelo
- ✅ Release 19: Resumen de Horas

## Estructura del Módulo Limitation Alerts

```
core/
├── interactor/
│   ├── interactor_limitation_alerts.go
│   └── services/
│       ├── limitation_alerts_services.go
│       └── domain/
│           └── limitation_alert.go
handlers/
├── limitation_alerts.go
└── limitation_alerts_controller.go
```

## Notas Técnicas

> 🚨 **Sistema de Alertas**: Compara horas acumuladas vs límites definidos.
> 📊 **Tipos de Alerta**:
>   - WARNING (80% del límite)
>   - CRITICAL (90% del límite)
>   - EXCEEDED (100%+ del límite)
>   - CAT_EXPIRING (aproximación CAT próxima a vencer)
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.

## Lógica de Alertas

```
1. Obtener flight_limitations del empleado (vigentes)
2. Obtener employee_flight_summary para períodos actuales
3. Comparar:
   - total_air_time vs max_flight_hours
   - total_duty_time vs max_duty_hours
   - total_landings vs max_landings
   - last_cat_approach_date vs cat_approach_validity_days
4. Generar alertas según umbrales
```

## Tipos de Respuesta

```json
{
  "alerts": [
    {
      "type": "FLIGHT_HOURS",
      "level": "WARNING",
      "period": "MONTHLY",
      "current": 72.5,
      "limit": 90.0,
      "percentage": 80.5,
      "message": "Has alcanzado el 80% de tu límite mensual de horas de vuelo"
    },
    {
      "type": "CAT_APPROACH",
      "level": "CRITICAL",
      "daysRemaining": 15,
      "lastApproachDate": "2026-01-01",
      "expirationDate": "2026-01-16",
      "message": "Tu habilitación de aproximación CAT expira en 15 días"
    }
  ]
}
```
