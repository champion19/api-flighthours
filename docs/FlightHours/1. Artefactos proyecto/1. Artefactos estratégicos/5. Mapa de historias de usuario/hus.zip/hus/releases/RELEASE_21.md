# Release 21: Reportes de Vuelo - Generación

**Tag Git**: `v0.22.0`
**Estado**: 🔜 Pendiente
**Total Horas**: 32h

## Historias de Usuario

| HU   | Descripción                                      | Horas | Endpoint                  | Estado | Full Stack |
| ---- | ------------------------------------------------ | ----- | ------------------------- | ------ | ---------- |
| N/A  | Generar Reporte de Horas por Período             | 16h   | `GET /reports/flight-hours` | 🔜   | 🟡         |
| N/A  | Generar Reporte de Bitácora (formato oficial)    | 16h   | `GET /reports/logbook`      | 🔜   | 🟡         |

## Dependencias

- ✅ Release 5: Bitácora Diaria
- ✅ Release 12: Detalle Bitácora
- ✅ Release 19: Resumen de Horas

## Notas Técnicas

> 📋 **Reportes**: Generación de documentos estructurados.
> 📊 **Formatos**: JSON (API), PDF (futuro), Excel (futuro)
> 🔗 **Filtros**: Por período, aerolínea, aeronave, ruta
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.

## Parámetros de Consulta

### Flight Hours Report
- `employee_id`: UUID del empleado
- `period_type`: MONTHLY, QUARTERLY, ANNUAL
- `period_year`: 2026
- `period_number`: 1-12 (mes), 1-4 (trimestre)
