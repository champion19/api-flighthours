# Release 18: Limitaciones de Vuelo - Gestión

**Tag Git**: `v0.19.0`
**Estado**: 🔜 Pendiente
**Total Horas**: 32h

## Historias de Usuario

| HU   | Descripción                                                | Horas | Endpoint                                    | Estado | Full Stack |
| ---- | ---------------------------------------------------------- | ----- | ------------------------------------------- | ------ | ---------- |
| N/A  | Consultar Limitaciones de Vuelo del Empleado               | 8h    | `GET /employees/{id}/flight-limitations`    | 🔜     | 🟡         |
| N/A  | Agregar Limitación de Vuelo                                | 8h    | `POST /flight-limitations`                  | 🔜     | 🟡         |
| N/A  | Actualizar Limitación de Vuelo                             | 8h    | `PUT /flight-limitations/{id}`              | 🔜     | 🟡         |
| N/A  | Eliminar Limitación de Vuelo                               | 8h    | `DELETE /flight-limitations/{id}`           | 🔜     | 🟡         |

## Dependencias

- ✅ Release 1: Empleado (FK employee_id)
- ✅ Release 12: Detalle Bitácora (para cálculo de horas)

## Estructura del Módulo Flight Limitation

```
core/
├── interactor/
│   ├── interactor_flight_limitation.go
│   └── services/
│       ├── flight_limitation_services.go
│       └── domain/
│           └── flight_limitation.go
handlers/
├── flight_limitation.go
└── flight_limitation_controller.go
platform/
└── databases/
    └── repositories/
        └── flight_limitation/
```

## Notas Técnicas

> 🎯 **Importante para Alertas**: Esta tabla permite definir límites de horas de vuelo por periodo.
> 📊 **Tipos de Limitación**: MONTHLY, QUARTERLY, SEMIANNUAL, ANNUAL, PERIOD_1_15, PERIOD_16_30
> 🚨 **Campos de Alerta**: max_flight_hours, max_duty_hours, max_landings, cat_approach_validity_days
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.

## Tabla de Base de Datos

```sql
CREATE TABLE flight_limitation (
    id VARCHAR(36) NOT NULL,
    employee_id VARCHAR(36) NOT NULL,
    limitation_type VARCHAR(20) NOT NULL,
    max_flight_hours DECIMAL(6,2) NOT NULL,
    max_duty_hours DECIMAL(6,2),
    max_landings INTEGER,
    cat_approach_validity_days INTEGER DEFAULT 90,
    effective_date DATE NOT NULL,
    expiration_date DATE,
    PRIMARY KEY (id),
    CONSTRAINT fk_limitation_employee FOREIGN KEY (employee_id) REFERENCES employee(id)
);
```

## Casos de Uso

1. **Límite mensual**: max_flight_hours = 90.00 (limitación FAA)
2. **Límite trimestral**: max_flight_hours = 270.00
3. **Vigencia CAT**: cat_approach_validity_days = 90 (pierde habilitación si no hace en 90 días)
