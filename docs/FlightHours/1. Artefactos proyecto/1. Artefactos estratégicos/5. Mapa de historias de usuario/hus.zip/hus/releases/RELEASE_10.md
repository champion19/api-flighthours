# Release 10: Ruta Aerolínea (Airline Route) - CRUD Completo

**Tag Git**: `v0.11.0`
**Estado**: ✅ Implementado
**Total Horas**: 24h

## Historias de Usuario

| HU   | Descripción                                       | Horas | Endpoint                                   | Estado | Full Stack |
| ---- | ------------------------------------------------- | ----- | ------------------------------------------ | ------ | ---------- |
| HU40 | Consultar la Información de la Ruta Aerolinea     | 16h   | `GET /airline-routes/{id}`                 | ✅     | ✅         |
| HU41 | Desactivar la información de la Ruta Aerolinea    | 4h    | `PATCH /airline-routes/{id}/deactivate`    | ✅     | 🟡         |
| HU42 | Activar la información de la Ruta Aerolinea       | 4h    | `PATCH /airline-routes/{id}/activate`      | ✅     | 🟡         |

## Dependencias

- ✅ Release 2: Aerolínea (FK airline_id)
- ✅ Release 9: Ruta (FK route_id)

## Estructura del Módulo Airline Route

```
core/
├── interactor/
│   ├── interactor_airline_route.go
│   └── services/
│       ├── airline_route_services.go
│       └── domain/
│           └── airline_route.go
handlers/
├── airline_route.go              # DTOs y mappers
└── airline_route_controller.go   # Handlers
platform/
└── databases/
    └── repositories/
        └── airline_route/        # Repository con prepared statements
```

## Notas Técnicas

> 📋 **airline_route** vincula una ruta con una aerolínea específica.
> 🔗 **Relaciones**: FK a `route` y `airline`
> 📊 **Campo de estado**: `status` (BOOLEAN) para activar/desactivar rutas por aerolínea
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.
> 🔑 **Dual-Format ID Resolution**: Acepta tanto UUID como ID ofuscado (HashID).
> 📊 **Campos desnormalizados**: airline_code, airline_name, route_code, origin/destination IATA codes (obtenidos via JOINs)

## Tabla de Base de Datos

```sql
CREATE TABLE airline_route (
    id VARCHAR(36) NOT NULL,
    route_id VARCHAR(36) NOT NULL,
    airline_id VARCHAR(36) NOT NULL,
    status BOOLEAN NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_airline_route_route FOREIGN KEY (route_id) REFERENCES route(id),
    CONSTRAINT fk_airline_route_airline FOREIGN KEY (airline_id) REFERENCES airline(id)
);
```

## Endpoints Implementados

### GET /airline-routes/{id}
Obtiene una ruta aerolínea por ID.
- **Formatos aceptados**: UUID directo o ID ofuscado (HashID)
- **Respuesta**: Ruta aerolínea con datos denormalizados (código aerolínea, código ruta, aeropuertos) y links HATEOAS
- **Código de éxito**: `RUT_AIR_CON_EXI_04001`
- **Código de error**: `RUT_AIR_CON_ERR_04002` (no encontrado)

### GET /airline-routes (Funcionalidad adicional)
Lista todas las rutas aerolínea.
- **Filtros opcionales**: `?airline_code=AV`, `?status=true`
- **Respuesta**: Lista de rutas aerolínea con links HATEOAS
- **Código de éxito**: `RUT_AIR_LIST_EXI_04001`
- **Código de error**: `RUT_AIR_LIST_ERR_04002`

### PATCH /airline-routes/{id}/activate
Activa una ruta aerolínea.
- **Formatos aceptados**: UUID directo o ID ofuscado (HashID)
- **Código de éxito**: `RUT_AIR_ACT_EXI_04201`
- **Código de error**: `RUT_AIR_ACT_ERR_04202`

### PATCH /airline-routes/{id}/deactivate
Desactiva una ruta aerolínea.
- **Formatos aceptados**: UUID directo o ID ofuscado (HashID)
- **Código de éxito**: `RUT_AIR_INA_EXI_04101`
- **Código de error**: `RUT_AIR_INA_ERR_04102`

---

## Escenarios de Prueba

### HU40 - Consultar Información de la Ruta Aerolínea

| Código       | Tipo     | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Código Mensaje           | Estado      |
| ------------ | -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------ | ----------- |
| CONRTA-CA1   | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar la información de una Ruta Aerolínea, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque una ruta aerolínea válida por su identificador, **entonces** el sistema mostrará correctamente los datos de la ruta aerolínea incluyendo código de aerolínea, nombre de aerolínea, código de ruta (origen-destino), aeropuertos origen y destino, tipo de aeropuerto, estado y tiempo estimado de vuelo, presentará la información en la vista correspondiente con links HATEOAS y mostrará al usuario final el mensaje satisfactorio `RUT_AIR_CON_EXI_04001`. | `RUT_AIR_CON_EXI_04001` | ✅ Implementado |
| CONRTA-CA2   | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar la información de una Ruta Aerolínea, **cuando** intente realizar la consulta con un identificador que no existe en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `RUT_AIR_CON_ERR_04002` indicando que la ruta aerolínea no fue encontrada y permitirá realizar una nueva búsqueda.                                                          | `RUT_AIR_CON_ERR_04002` | ✅ Implementado |
| CONRTA-CA3   | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar la información de una Ruta Aerolínea, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `RUT_AIR_CON_ERR_04003` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                    | `RUT_AIR_CON_ERR_04003` | ✅ Implementado |

### HU41 - Desactivar Información de la Ruta Aerolínea

| Código       | Tipo     | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Código Mensaje           | Estado      |
| ------------ | -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------ | ----------- |
| INARUT-CA1   | ✅ Éxito | **Dado** que un Administrador del Sistema quiere desactivar una Ruta Aerolínea, **cuando** acceda a la funcionalidad de desactivación y seleccione una ruta aerolínea válida por su identificador, **entonces** el sistema actualizará el estado de la ruta aerolínea a inactivo (status = false), presentará la información actualizada con links HATEOAS contextuales (solo mostrará opción de activar) y mostrará al usuario final el mensaje satisfactorio `RUT_AIR_INA_EXI_04101`. | `RUT_AIR_INA_EXI_04101` | ✅ Implementado |
| INARUT-CA2   | ❌ Error | **Dado** que un Administrador del Sistema quiere desactivar una Ruta Aerolínea, **cuando** intente realizar la desactivación con un identificador que no existe en el sistema, **entonces** el sistema no ejecutará la desactivación, mostrará al usuario final el mensaje de advertencia `RUT_AIR_CON_ERR_04002` indicando que la ruta aerolínea no fue encontrada y permitirá realizar una nueva búsqueda.                                                          | `RUT_AIR_CON_ERR_04002` | ✅ Implementado |
| INARUT-CA3   | ❌ Error | **Dado** que un Administrador del Sistema quiere desactivar una Ruta Aerolínea, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `RUT_AIR_INA_ERR_04102` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                    | `RUT_AIR_INA_ERR_04102` | ✅ Implementado |

### HU42 - Activar Información de la Ruta Aerolínea

| Código       | Tipo     | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Código Mensaje           | Estado      |
| ------------ | -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------ | ----------- |
| ACTRUT-CA1   | ✅ Éxito | **Dado** que un Administrador del Sistema quiere activar una Ruta Aerolínea, **cuando** acceda a la funcionalidad de activación y seleccione una ruta aerolínea válida por su identificador, **entonces** el sistema actualizará el estado de la ruta aerolínea a activo (status = true), presentará la información actualizada con links HATEOAS contextuales (solo mostrará opción de desactivar) y mostrará al usuario final el mensaje satisfactorio `RUT_AIR_ACT_EXI_04201`. | `RUT_AIR_ACT_EXI_04201` | ✅ Implementado |
| ACTRUT-CA2   | ❌ Error | **Dado** que un Administrador del Sistema quiere activar una Ruta Aerolínea, **cuando** intente realizar la activación con un identificador que no existe en el sistema, **entonces** el sistema no ejecutará la activación, mostrará al usuario final el mensaje de advertencia `RUT_AIR_CON_ERR_04002` indicando que la ruta aerolínea no fue encontrada y permitirá realizar una nueva búsqueda.                                                          | `RUT_AIR_CON_ERR_04002` | ✅ Implementado |
| ACTRUT-CA3   | ❌ Error | **Dado** que un Administrador del Sistema quiere activar una Ruta Aerolínea, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `RUT_AIR_ACT_ERR_04202` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                    | `RUT_AIR_ACT_ERR_04202` | ✅ Implementado |

### Listar Rutas Aerolínea (Funcionalidad adicional)

| Código       | Tipo     | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Código Mensaje            | Estado      |
| ------------ | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------- | ----------- |
| LSTRTA-CA1   | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar el listado de Rutas Aerolínea, **cuando** acceda a la funcionalidad correspondiente y opcionalmente aplique filtros por código de aerolínea o estado, **entonces** el sistema mostrará el listado completo de rutas aerolínea con sus datos asociados (código aerolínea, nombre aerolínea, código ruta, aeropuertos origen/destino, estado), presentará la información en la vista correspondiente con links HATEOAS y mostrará al usuario final el mensaje satisfactorio `RUT_AIR_LIST_EXI_04001`.                      | `RUT_AIR_LIST_EXI_04001` | ✅ Implementado |
| LSTRTA-CA2   | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar el listado de Rutas Aerolínea, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error `RUT_AIR_LIST_ERR_04002` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                                                             | `RUT_AIR_LIST_ERR_04002` | ✅ Implementado |

---

## Códigos de Mensaje Implementados

### Mensajes de Éxito en errors.go

| Constante                    | Código                   | Tipo  |
| ---------------------------- | ------------------------ | ----- |
| `MsgAirlineRouteGetOK`       | `RUT_AIR_CON_EXI_04001`  | Éxito |
| `MsgAirlineRouteDeactivateOK`| `RUT_AIR_INA_EXI_04101`  | Éxito |
| `MsgAirlineRouteActivateOK`  | `RUT_AIR_ACT_EXI_04201`  | Éxito |
| `MsgAirlineRouteListOK`      | `RUT_AIR_LIST_EXI_04001` | Éxito |

### Mensajes de Error en errors.go

| Constante                       | Código                   | Tipo  |
| ------------------------------- | ------------------------ | ----- |
| `MsgAirlineRouteNotFound`       | `RUT_AIR_CON_ERR_04002`  | Error |
| `MsgAirlineRouteGetErr`         | `RUT_AIR_CON_ERR_04003`  | Error |
| `MsgAirlineRouteDeactivateErr`  | `RUT_AIR_INA_ERR_04102`  | Error |
| `MsgAirlineRouteActivateErr`    | `RUT_AIR_ACT_ERR_04202`  | Error |
| `MsgAirlineRouteListError`      | `RUT_AIR_LIST_ERR_04002` | Error |
| `MsgAirlineRouteInvalidRoute`   | `RUT_AIR_VAL_ERR_04301`  | Error |
| `MsgAirlineRouteInvalidAirline` | `RUT_AIR_VAL_ERR_04302`  | Error |

### Errores de Dominio en errors.go

| Variable                        | Código de Error                   |
| ------------------------------- | --------------------------------- |
| `ErrAirlineRouteNotFound`       | `ERR_AIRLINE_ROUTE_NOT_FOUND`     |
| `ErrAirlineRouteCannotSave`     | `ERR_AIRLINE_ROUTE_CANNOT_SAVE`   |
| `ErrAirlineRouteCannotUpdate`   | `ERR_AIRLINE_ROUTE_CANNOT_UPDATE` |
| `ErrAirlineRouteInvalidRoute`   | `ERR_AIRLINE_ROUTE_INVALID_ROUTE` |
| `ErrAirlineRouteInvalidAirline` | `ERR_AIRLINE_ROUTE_INVALID_AIRLINE` |

### Mapeo HTTP Status en cache.go

| Código                   | HTTP Status | Descripción                              |
| ------------------------ | ----------- | ---------------------------------------- |
| `RUT_AIR_CON_EXI_04001`  | 200         | Ruta aerolínea consultada exitosamente   |
| `RUT_AIR_CON_ERR_04002`  | 404         | Ruta aerolínea no encontrada             |
| `RUT_AIR_CON_ERR_04003`  | 500         | Error técnico al consultar               |
| `RUT_AIR_INA_EXI_04101`  | 200         | Ruta aerolínea desactivada exitosamente  |
| `RUT_AIR_INA_ERR_04102`  | 500         | Error técnico al desactivar              |
| `RUT_AIR_ACT_EXI_04201`  | 200         | Ruta aerolínea activada exitosamente     |
| `RUT_AIR_ACT_ERR_04202`  | 500         | Error técnico al activar                 |
| `RUT_AIR_LIST_EXI_04001` | 200         | Lista de rutas aerolínea obtenida        |
| `RUT_AIR_LIST_ERR_04002` | 500         | Error al listar rutas aerolínea          |
| `RUT_AIR_VAL_ERR_04301`  | 400         | Ruta inválida                            |
| `RUT_AIR_VAL_ERR_04302`  | 400         | Aerolínea inválida                       |

### Mensajes de Log en log_messages.go

| Constante                          | Mensaje                                            |
| ---------------------------------- | -------------------------------------------------- |
| `LogAirlineRouteGet`               | Obteniendo información de ruta aerolínea           |
| `LogAirlineRouteGetOK`             | Ruta aerolínea obtenida exitosamente               |
| `LogAirlineRouteGetError`          | Error obteniendo ruta aerolínea                    |
| `LogAirlineRouteNotFound`          | Ruta aerolínea no encontrada                       |
| `LogAirlineRouteList`              | Listando rutas aerolínea                           |
| `LogAirlineRouteListOK`            | Rutas aerolínea listadas exitosamente              |
| `LogAirlineRouteListError`         | Error listando rutas aerolínea                     |
| `LogAirlineRouteActivate`          | Activando ruta aerolínea                           |
| `LogAirlineRouteActivateOK`        | Ruta aerolínea activada exitosamente               |
| `LogAirlineRouteActivateError`     | Error activando ruta aerolínea                     |
| `LogAirlineRouteDeactivate`        | Desactivando ruta aerolínea                        |
| `LogAirlineRouteDeactivateOK`      | Ruta aerolínea desactivada exitosamente            |
| `LogAirlineRouteDeactivateError`   | Error desactivando ruta aerolínea                  |
| `LogAirlineRouteRepoInit`          | Inicializando repositorio de rutas aerolínea       |
| `LogAirlineRouteRepoInitOK`        | Repositorio de rutas aerolínea inicializado        |
| `LogAirlineRouteRepoInitError`     | Error inicializando repositorio de rutas aerolínea |

---

## Query SQL con Datos Denormalizados

```sql
SELECT
    ar.id,
    ar.route_id,
    ar.airline_id,
    ar.status,
    a.airline_code,
    a.airline_name,
    ao.iata_code AS origin_iata_code,
    ad.iata_code AS destination_iata_code,
    CONCAT(ao.iata_code, '-', ad.iata_code) AS route_code,
    ao.name AS origin_airport_name,
    ad.name AS destination_airport_name,
    r.airport_type,
    r.estimated_flight_time
FROM airline_route ar
JOIN airline a ON ar.airline_id = a.id
JOIN route r ON ar.route_id = r.id
JOIN airport ao ON r.origin_airport_id = ao.id
JOIN airport ad ON r.destination_airport_id = ad.id
WHERE ar.id = ?;
```

---

## Archivos Principales Modificados

| Categoría      | Archivos                                                                       |
| -------------- | ------------------------------------------------------------------------------ |
| **Handlers**   | `airline_route_controller.go`, `airline_route.go`, `handler.go`, `hateoas.go`  |
| **Interactor** | `interactor_airline_route.go`                                                  |
| **Services**   | `airline_route_services.go`                                                    |
| **Domain**     | `domain/airline_route.go`, `domain/erros.go`                                   |
| **Ports**      | `input/service.go`, `output/repository.go`                                     |
| **Repository** | `repositories/airline_route/repository.go`                                     |
| **Logger**     | `log_messages.go`                                                              |
| **Cache**      | `platform/cache/messaging/cache.go`                                            |
| **Middleware** | `middleware/errors_handler.go`                                                 |
| **Dependency** | `cmd/dependency/dependency.go`                                                 |
| **Server**     | `server/server.go`                                                             |
| **Tests**      | `http_test.go`, `airline_http_test.go`, `airport_http_test.go`, `message_http_test.go` |

---

## Scripts SQL

- `docs/sql/add_airline_route_messages.sql` - Mensajes del sistema para el módulo Airline Route

---

## Notas de Release

1. Este release implementa las operaciones CRUD para Ruta Aerolínea (Airline Route): consultar por ID, listar todas, activar y desactivar.
2. Los endpoints GET son **públicos** (no requieren autenticación JWT). Los endpoints PATCH (activate/deactivate) son **protegidos**.
3. Los endpoints aceptan tanto UUID directo como ID ofuscado (HashID) para mayor flexibilidad.
4. Se puede filtrar la lista de rutas aerolínea por código de aerolínea (`?airline_code=AV`) o por estado (`?status=true`).
5. La respuesta incluye datos denormalizados: código de aerolínea, nombre de aerolínea, código de ruta (BOG-CLO), nombres de aeropuertos.
6. La arquitectura sigue el patrón hexagonal establecido: Handler → Interactor → Service → Repository.
7. Se implementa HATEOAS (Richardson Maturity Model Level 3) con links contextuales según el estado (activo muestra deactivate, inactivo muestra activate).
8. Los cambios de estado se realizan transaccionalmente con validación previa de existencia.
9. La tabla `airline_route` vincula una ruta física con una aerolínea específica, permitiendo que múltiples aerolíneas operen la misma ruta.
