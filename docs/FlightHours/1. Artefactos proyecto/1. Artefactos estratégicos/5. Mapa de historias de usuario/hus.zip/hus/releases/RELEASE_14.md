# Release 14: Familia de Aeronave - Consulta

**Tag Git**: `v0.15.0`
**Estado**: 🔜 Pendiente
**Total Horas**: 8h

## Historias de Usuario

| HU   | Descripción                                            | Horas | Endpoint                      | Estado | Full Stack |
| ---- | ------------------------------------------------------- | ----- | ----------------------------- | ------ | ---------- |
| HU32 | Consultar la Información de la Familia de una Aeronave | 8h    | `GET /aircraft-families/{family}` | ✅     | 🟡         |

## Dependencias

- ✅ Release 7: Modelo Aeronave

## Estructura del Módulo Aircraft Family

> ⚠️ **Nota Técnica**: Este módulo **NO** crea una nueva tabla `aircraft_family`.
> 💡 La implementación usa el campo `family` existente en `aircraft_model` para agrupar modelos.
> 🎯 **Opción C implementada**: Agrupación lógica por el campo `family` sin FKs adicionales.

```
core/
├── interactor/
│   ├── interactor_aircraft_model.go     ← Método: GetAircraftModelsByFamily
│   └── services/
│       ├── aircraft_model_services.go   ← Método: GetAircraftModelsByFamily
│       └── domain/
│           └── aircraft_model.go        ← Ya tiene campo Family
handlers/
├── aircraft_model.go                    ← DTOs existentes reutilizados
└── aircraft_model_controller.go         ← Handler: GetAircraftModelsByFamily
platform/
└── databases/
    └── repositories/
        └── aircraft_model/
            └── repository.go            ← Query: QueryGetByFamily
```

## Notas Técnicas

> 🎯 **REUTILIZACIÓN**: Se aprovecha la infraestructura existente de `aircraft_model`.
> 📋 Ejemplo de familias: A320 (incluye A319, A320, A321), B737 (incluye B737, B738, B739).
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.
> 🔑 **ID de Familia**: Es un string directo (ej: "A320", "B737"), no un UUID ofuscado.

---

## Escenarios de Prueba

### HU32 - Consultar la Información de la Familia de una Aeronave

| Código    | Tipo      | Escenario                                                                                                                                                                                                                                                                                                                                                                                                                                             | Código Mensaje     | Estado      |
| ---------- | --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ----------- |
| CONFAM-CA1 | ✅ Éxito | **Dado** que un Usuario del Sistema quiere consultar la información de una Familia de Aeronaves, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque una familia válida por su identificador (ej: A320, B737), **entonces** el sistema mostrará correctamente todos los modelos pertenecientes a esa familia incluyendo nombre del modelo, tipo de aeronave, tipo de motor, familia y fabricante, presentará la información en la vista correspondiente con enlaces HATEOAS y mostrará al usuario final el mensaje satisfactorio `FAM_CON_EXI_03201`. | `FAM_CON_EXI_03201` | 🔜 Pendiente |
| CONFAM-CA2 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar la información de una Familia de Aeronaves, **cuando** intente realizar la consulta con un identificador de familia que no existe en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `FAM_CON_ERR_03202` indicando que la familia no fue encontrada y permitirá realizar una nueva búsqueda.                                                                 | `FAM_CON_ERR_03202` | 🔜 Pendiente |
| CONFAM-CA3 | ❌ Error  | **Dado** que un Usuario del Sistema quiere consultar la información de una Familia de Aeronaves, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `FAM_CON_ERR_03203` y recomendará intentar nuevamente más tarde o contactar al soporte técnico.                                  | `FAM_CON_ERR_03203` | 🔜 Pendiente |

---

## Archivos Principales Modificados

| Categoría     | Archivos                                                                                   |
| -------------- | ------------------------------------------------------------------------------------------ |
| **Handlers**   | `aircraft_model_controller.go` (nuevo handler: `GetAircraftModelsByFamily`)               |
| **Interactor** | `interactor_aircraft_model.go` (nuevo método: `GetAircraftModelsByFamily`)                |
| **Services**   | `aircraft_model_services.go` (nuevo método: `GetAircraftModelsByFamily`)                  |
| **Ports**      | `input/service.go`, `output/repository.go` (nuevos métodos en interfaces)                 |
| **Repository** | `repositories/aircraft_model/repository.go` (nueva query: `QueryGetByFamily`)             |
| **Server**     | `server/server.go` (nueva ruta: `GET /aircraft-families/:family`)                         |
| **SQL**        | `docs/sql/add_aircraft_family_messages.sql`                                               |

---

## Códigos de Mensaje Implementados

### Mensajes de Éxito en errors.go

| Constante                     | Código              | Tipo   |
| ----------------------------- | -------------------- | ------ |
| `MsgAircraftFamilyGetOK`      | `FAM_CON_EXI_03201`  | Éxito |

### Mensajes de Error en errors.go

| Constante                     | Código               | Tipo  |
| ----------------------------- | --------------------- | ----- |
| `MsgAircraftFamilyNotFound`   | `FAM_CON_ERR_03202`   | Error |
| `MsgAircraftFamilyGetError`   | `FAM_CON_ERR_03203`   | Error |

### Errores de Dominio en errors.go

| Variable                         | Código de Error                        |
| -------------------------------- | --------------------------------------- |
| `ErrAircraftFamilyNotFound`      | `ERR_AIRCRAFT_FAMILY_NOT_FOUND`        |

### Mapeo HTTP Status en cache.go

| Código               | HTTP Status | Descripción                                  |
| --------------------- | ----------- | -------------------------------------------- |
| `FAM_CON_EXI_03201`   | 200         | Familia de aeronaves consultada exitosamente |
| `FAM_CON_ERR_03202`   | 404         | Familia de aeronaves no encontrada           |
| `FAM_CON_ERR_03203`   | 500         | Error técnico al consultar familia           |

---

## Endpoints API

| Método | Endpoint                                        | Descripción                              | Auth  |
| ------ | ----------------------------------------------- | ---------------------------------------- | ----- |
| GET    | `/flighthours/api/v1/aircraft-families/{family}` | Obtiene los modelos de una familia       | No    |

---

## Ejemplos de Respuesta

### GET /aircraft-families/A320 - Éxito

```json
{
  "aircraft_models": [
    {
      "id": "xK7mN2pQ9rLw",
      "model_name": "A319",
      "aircraft_type_name": "Airbus A319-100",
      "engine_type_name": "JET",
      "family": "A320",
      "manufacturer": "Airbus",
      "_links": [
        { "rel": "self", "href": "/flighthours/api/v1/aircraft-models/xK7mN2pQ9rLw" }
      ]
    },
    {
      "id": "yL8nO3qR0sMx",
      "model_name": "A320",
      "aircraft_type_name": "Airbus A320-200",
      "engine_type_name": "JET",
      "family": "A320",
      "manufacturer": "Airbus",
      "_links": [
        { "rel": "self", "href": "/flighthours/api/v1/aircraft-models/yL8nO3qR0sMx" }
      ]
    },
    {
      "id": "zM9pP4sT1uNy",
      "model_name": "A321",
      "aircraft_type_name": "Airbus A321-200",
      "engine_type_name": "JET",
      "family": "A320",
      "manufacturer": "Airbus",
      "_links": [
        { "rel": "self", "href": "/flighthours/api/v1/aircraft-models/zM9pP4sT1uNy" }
      ]
    }
  ],
  "total": 3,
  "_links": [
    { "rel": "aircraft-models", "href": "/flighthours/api/v1/aircraft-models" }
  ]
}
```

### GET /aircraft-families/INVALID - Error Not Found

```json
{
  "success": false,
  "code": "FAM_CON_ERR_03202",
  "message": "La familia de aeronaves solicitada no existe en el sistema."
}
```

---

## Query SQL Implementada

```sql
-- QueryGetByFamily: Obtener todos los modelos de una familia específica
SELECT
    am.id,
    am.model_name,
    am.aircraft_type_name,
    e.name AS engine_type_name,
    am.family,
    m.name AS manufacturer
FROM aircraft_model am
LEFT JOIN engine e ON am.engine_type_id = e.id
LEFT JOIN manufacturer m ON am.manufacturer_id = m.id
WHERE am.family = ?
ORDER BY am.model_name
```

---

## Notas de Release

1. Este release implementa la consulta de Familia de Aeronaves (HU32).
2. **NO se crea tabla adicional** - Se reutiliza el campo `family` de `aircraft_model`.
3. Se aprovecha la infraestructura existente del módulo `aircraft_model`.
4. El endpoint es público (no requiere autenticación).
5. El "ID" de familia es un string directo (ej: "A320", "B737"), no un UUID.
6. Se implementa HATEOAS (Richardson Maturity Model Level 3) para navegación.
7. La arquitectura sigue el patrón hexagonal: Handler → Interactor → Service → Repository.
8. Los mensajes se cargan desde la tabla `system_messages` a través del sistema de cache.
9. Retorna código 404 cuando no hay modelos para la familia especificada.
10. La respuesta reutiliza `AircraftModelListResponse` para consistencia con el módulo existente.
