# Release 11: Vuelo (Flight) - CRUD Completo

**Tag Git**: `v0.12.0`
**Estado**: ✅ Implementado
**Total Horas**: 32h

## Historias de Usuario

| HU   | Descripción                                | Horas | Endpoint                  | Estado | Full Stack |
| ---- | ------------------------------------------ | ----- | ------------------------- | ------ | ---------- |
| HU48 | Consultar la Información del Vuelo         | 16h   | `GET /flights/{id}`       | ✅     | 🟡         |
| HU49 | Editar la Información del Vuelo            | 8h    | `PUT /flights/{id}`       | ✅     | 🟡         |
| HU50 | Registrar la Información del Vuelo         | 8h    | `POST /flights`           | ✅     | 🟡         |

## Dependencias

- ✅ Release 10: Ruta Aerolínea (FK airline_route_id)

## Estructura del Módulo Flight

```
core/
├── interactor/
│   ├── interactor_flight.go
│   └── services/
│       ├── flight_services.go
│       └── domain/
│           └── flight.go
handlers/
├── flight.go              # DTOs y mappers
└── flight_controller.go   # Handlers
platform/
└── databases/
    └── repositories/
        └── flight/        # Repository con prepared statements
```

## Notas Técnicas

> 📋 **flight** representa un vuelo programado con información de ruta, número de vuelo y estado.
> 🔗 **Relaciones**: FK a `airline_route`
> 📊 **Campo de estado**: `status` (ENUM: SCHEDULED, IN_PROGRESS, COMPLETED, CANCELLED) para gestionar el ciclo de vida del vuelo
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.
> 🔑 **Dual-Format ID Resolution**: Acepta tanto UUID como ID ofuscado (HashID).
> 📊 **Campos desnormalizados**: airline_code, airline_name, route_code, origin/destination IATA codes, airport names, estimated_flight_time (obtenidos via JOINs)

## Tabla de Base de Datos

```sql
CREATE TABLE flight(
    id VARCHAR(36) NOT NULL,
    flight_number VARCHAR(20),
    flight_date DATE NOT NULL,
    airline_route_id VARCHAR(36) NOT NULL,
    status ENUM('SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED') DEFAULT 'SCHEDULED',
    PRIMARY KEY(id),
    CONSTRAINT fk_flight_airline_route FOREIGN KEY(airline_route_id) REFERENCES airline_route(id)
);
```

## Endpoints Implementados

### GET /flights/{id}
Obtiene un vuelo por ID.
- **Formatos aceptados**: UUID directo o ID ofuscado (HashID)
- **Respuesta**: Vuelo con datos denormalizados (código aerolínea, código ruta, aeropuertos) y links HATEOAS
- **Código de éxito**: `VUE_CON_EXI_04801`
- **Código de error**: `VUE_CON_ERR_04803` (no encontrado)

### GET /flights (Funcionalidad adicional)
Lista todos los vuelos.
- **Filtros opcionales**: `?airline_route_id=xxx`, `?flight_date=2026-01-15`
- **Respuesta**: Lista de vuelos con links HATEOAS
- **Código de éxito**: `VUE_LIST_EXI_04800`
- **Código de error**: `VUE_LIST_ERR_04802`

### POST /flights
Registra un nuevo vuelo.
- **Requiere**: JWT authentication
- **Validaciones**: flight_number, flight_date, airline_route_id son requeridos
- **Código de éxito**: `VUE_REG_EXI_05001`
- **Código de error**: `VUE_REG_ERR_05004` (error técnico)

### PUT /flights/{id}
Actualiza la información de un vuelo existente.
- **Requiere**: JWT authentication
- **Formatos aceptados**: UUID directo o ID ofuscado (HashID)
- **Código de éxito**: `VUE_EDI_EXI_04901`
- **Código de error**: `VUE_EDI_ERR_04904` (error técnico)

---

## Casos de Uso

### HU48 - Consultar la Información del Vuelo

#### CU-VUE-01: Consultar Vuelo por ID

**Actor Principal**: Piloto del Sistema

**Precondiciones**:
- El vuelo existe en el sistema con un ID válido.
- El endpoint GET /flights/{id} está disponible.

**Flujo Principal (Éxito)**:
1. El Piloto accede a la funcionalidad de consulta de vuelo.
2. El Piloto ingresa o selecciona un vuelo válido por su ID.
3. El sistema valida que el identificador sea válido (UUID o HashID).
4. El sistema busca el vuelo en la base de datos con los datos denormalizados (código aerolínea, código ruta, aeropuertos origen/destino, tiempo estimado de vuelo).
5. El sistema encuentra el vuelo y retorna la información completa.
6. El sistema presenta los datos del vuelo con links HATEOAS (self, update, collection).
7. El sistema muestra el mensaje satisfactorio: **"La información del vuelo se obtuvo exitosamente"** (`VUE_CON_EXI_04801`).

**Flujos Alternativos**:

| Código     | Escenario                          | Condición                                                  | Mensaje                                                                     | Código Mensaje      |
| ---------- | ---------------------------------- | ---------------------------------------------------------- | -------------------------------------------------------------------------- | ------------------- |
| CONVUE-CA2 | Vuelo no seleccionado              | El piloto no ingresa un identificador o criterio de búsqueda | "Debe ingresar o seleccionar un vuelo para continuar"                       | `VUE_CON_ERR_04802` |
| CONVUE-CA3 | Vuelo no encontrado                | El ID proporcionado no existe en el sistema                | "No se encontraron resultados con los criterios de búsqueda"                | `VUE_CON_ERR_04803` |
| CONVUE-CA4 | Error técnico                      | Falla de BD, conectividad u otro error técnico             | "Ocurrió un error técnico al consultar el vuelo. Intente nuevamente más tarde" | `VUE_CON_ERR_04804` |

**Postcondiciones**:
- El sistema retorna la información del vuelo con código HTTP 200.
- Se incluyen links HATEOAS para navegación.

---

#### CU-VUE-02: Listar Vuelos

**Actor Principal**: Piloto del Sistema

**Precondiciones**:
- El endpoint GET /flights está disponible.

**Flujo Principal (Éxito)**:
1. El Piloto accede a la funcionalidad de listado de vuelos.
2. El Piloto opcionalmente aplica filtros por `airline_route_id` o `flight_date`.
3. El sistema busca los vuelos que coinciden con los criterios.
4. El sistema retorna la lista de vuelos con datos denormalizados.
5. El sistema presenta el listado con links HATEOAS (self, collection).
6. El sistema muestra el mensaje satisfactorio: **"Lista de vuelos obtenida exitosamente"** (`VUE_LIST_EXI_04800`).

**Flujos Alternativos**:

| Código     | Escenario                          | Condición                                                  | Mensaje                                                                      | Código Mensaje      |
| ---------- | ---------------------------------- | ---------------------------------------------------------- | --------------------------------------------------------------------------- | ------------------- |
| LSTVUE-CA2 | Error técnico al listar            | Falla de BD, conectividad u otro error técnico             | "Ocurrió un error técnico al listar los vuelos. Intente nuevamente más tarde" | `VUE_LIST_ERR_04802` |

**Postcondiciones**:
- El sistema retorna la lista de vuelos con código HTTP 200.
- Si no hay vuelos, retorna lista vacía (no es error).

---

### HU49 - Editar la Información del Vuelo

#### CU-VUE-03: Actualizar Información del Vuelo

**Actor Principal**: Piloto del Sistema

**Precondiciones**:
- El piloto está autenticado con JWT válido.
- El vuelo existe en el sistema.

**Flujo Principal (Éxito)**:
1. El Piloto accede a la funcionalidad de edición de vuelo.
2. El Piloto selecciona un vuelo válido por su ID.
3. El Piloto modifica los datos del vuelo (flight_number, flight_date, airline_route_id, status).
4. El sistema valida los datos ingresados.
5. El sistema valida que la `airline_route_id` referenciada exista.
6. El sistema actualiza el vuelo en la base de datos dentro de una transacción.
7. El sistema retorna el vuelo actualizado con datos denormalizados.
8. El sistema presenta la información con links HATEOAS.
9. El sistema muestra el mensaje satisfactorio: **"El vuelo se ha actualizado exitosamente"** (`VUE_EDI_EXI_04901`).

**Flujos Alternativos**:

| Código     | Escenario                          | Condición                                                  | Mensaje                                                                     | Código Mensaje      |
| ---------- | ---------------------------------- | ---------------------------------------------------------- | -------------------------------------------------------------------------- | ------------------- |
| EDIVUE-CA2 | Vuelo no seleccionado              | El piloto no selecciona un vuelo antes de intentar editar  | "Debe seleccionar un vuelo para modificar"                                  | `VUE_EDI_ERR_04902` |
| EDIVUE-CA3 | Datos inválidos                    | Los datos ingresados son incompletos o tienen formato incorrecto | "Los datos ingresados son incompletos, inválidos o tienen formato incorrecto" | `VUE_EDI_ERR_04903` |
| EDIVUE-CA4 | Error técnico al editar            | Falla de BD, conectividad u otro error técnico             | "Ocurrió un error técnico al editar el vuelo. Intente nuevamente más tarde" | `VUE_EDI_ERR_04904` |
| EDIVUE-CA5 | Ruta aerolínea inválida            | La airline_route_id no existe o no es válida               | "La ruta de aerolínea especificada no es válida o no existe"                | `VUE_VAL_ERR_04805` |

**Postcondiciones**:
- El vuelo se actualiza en la base de datos.
- El sistema retorna el vuelo actualizado con código HTTP 200.

---

### HU50 - Registrar la Información del Vuelo

#### CU-VUE-04: Crear Nuevo Vuelo

**Actor Principal**: Piloto del Sistema

**Precondiciones**:
- El piloto está autenticado con JWT válido.
- La `airline_route_id` a referenciar existe en el sistema.

**Flujo Principal (Éxito)**:
1. El Piloto accede a la funcionalidad de registro de vuelo.
2. El Piloto ingresa los datos requeridos: flight_number, flight_date, airline_route_id.
3. El sistema valida que todos los campos requeridos estén completos.
4. El sistema valida que la `airline_route_id` exista en el sistema.
5. El sistema genera un UUID para el nuevo vuelo.
6. El sistema asigna el status por defecto: 'SCHEDULED'.
7. El sistema guarda el vuelo en la base de datos dentro de una transacción.
8. El sistema obtiene el vuelo creado con datos denormalizados.
9. El sistema presenta la información con links HATEOAS.
10. El sistema muestra el mensaje satisfactorio: **"El vuelo se ha registrado exitosamente"** (`VUE_REG_EXI_05001`).

**Flujos Alternativos**:

| Código     | Escenario                          | Condición                                                  | Mensaje                                                                        | Código Mensaje      |
| ---------- | ---------------------------------- | ---------------------------------------------------------- | ----------------------------------------------------------------------------- | ------------------- |
| REGVUE-CA2 | Campos requeridos incompletos      | Faltan campos obligatorios (flight_number, flight_date, airline_route_id) | "Debe completar todos los campos requeridos"                                   | `VUE_REG_ERR_05002` |
| REGVUE-CA3 | Formato inválido                   | Los datos tienen formato incorrecto (ej: fecha inválida)   | "Los datos ingresados tienen formato incorrecto o son inválidos"               | `VUE_REG_ERR_05003` |
| REGVUE-CA4 | Error técnico al registrar         | Falla de BD, conectividad u otro error técnico             | "Ocurrió un error técnico al registrar el vuelo. Intente nuevamente más tarde" | `VUE_REG_ERR_05004` |
| REGVUE-CA5 | Ruta aerolínea inválida            | La airline_route_id no existe o no es válida               | "La ruta de aerolínea especificada no es válida o no existe"                   | `VUE_VAL_ERR_04805` |

**Postcondiciones**:
- Se crea un nuevo registro de vuelo en la base de datos.
- El sistema retorna el vuelo creado con código HTTP 201.
- El vuelo se crea con status 'SCHEDULED' por defecto.

---

## Escenarios de Prueba

### HU48 - Consultar la Información del Vuelo

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| CONVUE-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar la información de un Vuelo, **cuando** acceda a la funcionalidad correspondiente y seleccione o busque un vuelo válido por su identificador, **entonces** el sistema mostrará correctamente los datos del vuelo incluyendo número de vuelo, fecha, estado, ruta (origen-destino), aerolínea, y tiempo estimado de vuelo, presentará la información en la vista correspondiente con links HATEOAS y mostrará al usuario final el mensaje satisfactorio `VUE_CON_EXI_04801`. | `VUE_CON_EXI_04801` | ✅ Implementado |
| CONVUE-CA2 | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar la información de un Vuelo, **cuando** intente realizar la consulta sin seleccionar previamente un vuelo o sin ingresar criterios de búsqueda válidos, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `VUE_CON_ERR_04802` indicando que debe ingresar o seleccionar un vuelo para continuar y permitirá realizar una nueva búsqueda. | `VUE_CON_ERR_04802` | ✅ Implementado |
| CONVUE-CA3 | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar la información de un Vuelo, **cuando** intente realizar la consulta con un identificador que no existe en el sistema, **entonces** el sistema no ejecutará la consulta, mostrará al usuario final el mensaje de advertencia `VUE_CON_ERR_04803` indicando que no se encontraron resultados con los criterios de búsqueda. | `VUE_CON_ERR_04803` | ✅ Implementado |
| CONVUE-CA4 | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar la información de un Vuelo, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `VUE_CON_ERR_04804` y recomendará intentar nuevamente más tarde. | `VUE_CON_ERR_04804` | ✅ Implementado |

### HU49 - Editar la Información del Vuelo

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| EDIVUE-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere editar la información de un Vuelo, **cuando** acceda a la funcionalidad correspondiente, seleccione un vuelo válido por su identificador e ingrese correctamente los datos a modificar (número de vuelo, fecha, ruta aerolínea, estado), **entonces** el sistema guardará los cambios exitosamente, presentará la información actualizada con links HATEOAS y mostrará al usuario final el mensaje satisfactorio `VUE_EDI_EXI_04901`. | `VUE_EDI_EXI_04901` | ✅ Implementado |
| EDIVUE-CA2 | ❌ Error | **Dado** que un Piloto del Sistema quiere editar la información de un Vuelo, **cuando** intente realizar la modificación sin haber seleccionado previamente un vuelo válido, **entonces** el sistema no ejecutará la modificación, mostrará al usuario final el mensaje de advertencia `VUE_EDI_ERR_04902` indicando que debe seleccionar un vuelo para modificar. | `VUE_EDI_ERR_04902` | ✅ Implementado |
| EDIVUE-CA3 | ❌ Error | **Dado** que un Piloto del Sistema quiere editar la información de un Vuelo, **cuando** ingrese datos incompletos, inválidos o con formato incorrecto, **entonces** el sistema no guardará los cambios, mostrará al usuario final el mensaje de advertencia `VUE_EDI_ERR_04903` indicando que los datos ingresados son incompletos, inválidos o tienen formato incorrecto. | `VUE_EDI_ERR_04903` | ✅ Implementado |
| EDIVUE-CA4 | ❌ Error | **Dado** que un Piloto del Sistema quiere editar la información de un Vuelo, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `VUE_EDI_ERR_04904` y recomendará intentar nuevamente más tarde. | `VUE_EDI_ERR_04904` | ✅ Implementado |
| EDIVUE-CA5 | ❌ Error | **Dado** que un Piloto del Sistema quiere editar la información de un Vuelo, **cuando** seleccione una ruta aerolínea que no existe o es inválida, **entonces** el sistema no guardará los cambios, mostrará al usuario final el mensaje de advertencia `VUE_VAL_ERR_04805` indicando que la ruta de aerolínea especificada no es válida y permitirá seleccionar otra ruta. | `VUE_VAL_ERR_04805` | ✅ Implementado |

### HU50 - Registrar la Información del Vuelo

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| REGVUE-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere registrar la información de un nuevo Vuelo, **cuando** acceda a la funcionalidad correspondiente, ingrese correctamente todos los datos requeridos (número de vuelo, fecha del vuelo, ruta aerolínea) y confirme la acción, **entonces** el sistema registrará exitosamente el nuevo vuelo con estado 'SCHEDULED' por defecto, presentará la información del vuelo creado con links HATEOAS y mostrará al usuario final el mensaje satisfactorio `VUE_REG_EXI_05001`. | `VUE_REG_EXI_05001` | ✅ Implementado |
| REGVUE-CA2 | ❌ Error | **Dado** que un Piloto del Sistema quiere registrar la información de un Vuelo, **cuando** intente realizar la acción sin completar todos los campos obligatorios (número de vuelo, fecha del vuelo, ruta aerolínea), **entonces** el sistema no guardará la información, mostrará al usuario final el mensaje de advertencia `VUE_REG_ERR_05002` indicando que debe completar todos los campos requeridos. | `VUE_REG_ERR_05002` | ✅ Implementado |
| REGVUE-CA3 | ❌ Error | **Dado** que un Piloto del Sistema quiere registrar la información de un Vuelo, **cuando** ingrese datos con formato incorrecto o inválidos (como una fecha mal formateada o un número de vuelo que no cumple el patrón), **entonces** el sistema no guardará la información, mostrará al usuario final el mensaje de advertencia `VUE_REG_ERR_05003` indicando que los datos ingresados tienen formato incorrecto o son inválidos. | `VUE_REG_ERR_05003` | ✅ Implementado |
| REGVUE-CA4 | ❌ Error | **Dado** que un Piloto del Sistema quiere registrar la información de un Vuelo, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error general `VUE_REG_ERR_05004` y recomendará intentar nuevamente más tarde. | `VUE_REG_ERR_05004` | ✅ Implementado |
| REGVUE-CA5 | ❌ Error | **Dado** que un Piloto del Sistema quiere registrar la información de un Vuelo, **cuando** seleccione una ruta aerolínea que no existe o es inválida, **entonces** el sistema no guardará la información, mostrará al usuario final el mensaje de advertencia `VUE_VAL_ERR_04805` indicando que la ruta de aerolínea especificada no es válida y permitirá seleccionar otra ruta. | `VUE_VAL_ERR_04805` | ✅ Implementado |

### Listar Vuelos (Funcionalidad adicional)

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| LSTVUE-CA1 | ✅ Éxito | **Dado** que un Piloto del Sistema quiere consultar el listado de Vuelos, **cuando** acceda a la funcionalidad correspondiente y opcionalmente aplique filtros por ruta aerolínea o fecha del vuelo, **entonces** el sistema mostrará el listado completo de vuelos con sus datos asociados (número de vuelo, fecha, estado, ruta, aerolínea), presentará la información en la vista correspondiente con links HATEOAS y mostrará al usuario final el mensaje satisfactorio `VUE_LIST_EXI_04800`. | `VUE_LIST_EXI_04800` | ✅ Implementado |
| LSTVUE-CA2 | ❌ Error | **Dado** que un Piloto del Sistema quiere consultar el listado de Vuelos, **cuando** ocurra un error técnico durante el proceso (como una falla en la base de datos o problemas de conectividad), **entonces** el sistema no podrá completar la operación, mostrará al usuario final el mensaje de error `VUE_LIST_ERR_04802` y recomendará intentar nuevamente más tarde. | `VUE_LIST_ERR_04802` | ✅ Implementado |

---

## Códigos de Mensaje Implementados

### Mensajes de Éxito en errors.go

| Constante          | Código               | Tipo  | Contenido                                      |
| ------------------ | -------------------- | ----- | ---------------------------------------------- |
| `MsgFlightGetOK`   | `VUE_CON_EXI_04801`  | Éxito | La información del vuelo se obtuvo exitosamente |
| `MsgFlightUpdated` | `VUE_EDI_EXI_04901`  | Éxito | El vuelo se ha actualizado exitosamente        |
| `MsgFlightCreated` | `VUE_REG_EXI_05001`  | Éxito | El vuelo se ha registrado exitosamente         |
| `MsgFlightListOK`  | `VUE_LIST_EXI_04800` | Éxito | Lista de vuelos obtenida exitosamente          |

### Mensajes de Error en errors.go

| Constante               | Código               | Tipo  | Contenido                                                              |
| ----------------------- | -------------------- | ----- | ---------------------------------------------------------------------- |
| `MsgFlightNotSelected`  | `VUE_CON_ERR_04802`  | Error | Debe ingresar o seleccionar un vuelo para continuar                    |
| `MsgFlightNotFound`     | `VUE_CON_ERR_04803`  | Error | No se encontraron resultados con los criterios de búsqueda             |
| `MsgFlightGetErr`       | `VUE_CON_ERR_04804`  | Error | Ocurrió un error técnico al consultar el vuelo                         |
| `MsgFlightNotForEdit`   | `VUE_EDI_ERR_04902`  | Error | Debe seleccionar un vuelo para modificar                               |
| `MsgFlightInvalidData`  | `VUE_EDI_ERR_04903`  | Error | Los datos ingresados son incompletos, inválidos o tienen formato incorrecto |
| `MsgFlightUpdateError`  | `VUE_EDI_ERR_04904`  | Error | Ocurrió un error técnico al editar el vuelo                            |
| `MsgFlightMissingFields`| `VUE_REG_ERR_05002`  | Error | Debe completar todos los campos requeridos                             |
| `MsgFlightBadFormat`    | `VUE_REG_ERR_05003`  | Error | Los datos ingresados tienen formato incorrecto o son inválidos         |
| `MsgFlightSaveError`    | `VUE_REG_ERR_05004`  | Error | Ocurrió un error técnico al registrar el vuelo                         |
| `MsgFlightListError`    | `VUE_LIST_ERR_04802` | Error | Ocurrió un error técnico al listar los vuelos                          |
| `MsgFlightInvalidRoute` | `VUE_VAL_ERR_04805`  | Error | La ruta de aerolínea especificada no es válida o no existe             |

### Errores de Dominio en errors.go

| Variable                 | Código de Error            |
| ------------------------ | -------------------------- |
| `ErrFlightNotFound`      | `ERR_FLIGHT_NOT_FOUND`     |
| `ErrFlightCannotSave`    | `ERR_FLIGHT_CANNOT_SAVE`   |
| `ErrFlightCannotUpdate`  | `ERR_FLIGHT_CANNOT_UPDATE` |
| `ErrFlightUnauthorized`  | `ERR_FLIGHT_UNAUTHORIZED`  |
| `ErrFlightInvalidRoute`  | `ERR_FLIGHT_INVALID_ROUTE` |

### Mapeo HTTP Status en cache.go

| Código               | HTTP Status | Descripción                           |
| -------------------- | ----------- | ------------------------------------- |
| `VUE_CON_EXI_04801`  | 200         | Vuelo consultado exitosamente         |
| `VUE_CON_ERR_04802`  | 400         | Vuelo no seleccionado                 |
| `VUE_CON_ERR_04803`  | 404         | Vuelo no encontrado                   |
| `VUE_CON_ERR_04804`  | 500         | Error técnico al consultar            |
| `VUE_EDI_EXI_04901`  | 200         | Vuelo actualizado exitosamente        |
| `VUE_EDI_ERR_04902`  | 400         | Vuelo no seleccionado para editar     |
| `VUE_EDI_ERR_04903`  | 400         | Datos inválidos                       |
| `VUE_EDI_ERR_04904`  | 500         | Error técnico al editar               |
| `VUE_REG_EXI_05001`  | 201         | Vuelo registrado exitosamente         |
| `VUE_REG_ERR_05002`  | 400         | Campos requeridos incompletos         |
| `VUE_REG_ERR_05003`  | 400         | Formato inválido                      |
| `VUE_REG_ERR_05004`  | 500         | Error técnico al registrar            |
| `VUE_LIST_EXI_04800` | 200         | Lista obtenida exitosamente           |
| `VUE_LIST_ERR_04802` | 500         | Error al listar vuelos                |
| `VUE_VAL_ERR_04805`  | 400         | Ruta aerolínea inválida               |

### Mensajes de Log en log_messages.go

| Constante                  | Mensaje                                   |
| -------------------------- | ----------------------------------------- |
| `LogFlightGet`             | Obteniendo información de vuelo           |
| `LogFlightGetOK`           | Vuelo obtenido exitosamente               |
| `LogFlightGetError`        | Error obteniendo vuelo                    |
| `LogFlightNotFound`        | Vuelo no encontrado                       |
| `LogFlightList`            | Listando vuelos                           |
| `LogFlightListOK`          | Vuelos listados exitosamente              |
| `LogFlightListError`       | Error listando vuelos                     |
| `LogFlightCreate`          | Creando vuelo                             |
| `LogFlightCreateOK`        | Vuelo creado exitosamente                 |
| `LogFlightCreateError`     | Error creando vuelo                       |
| `LogFlightUpdate`          | Actualizando vuelo                        |
| `LogFlightUpdateOK`        | Vuelo actualizado exitosamente            |
| `LogFlightUpdateError`     | Error actualizando vuelo                  |
| `LogFlightRepoInit`        | Inicializando repositorio de vuelos       |
| `LogFlightRepoInitOK`      | Repositorio de vuelos inicializado        |
| `LogFlightRepoInitError`   | Error inicializando repositorio de vuelos |

---

## Query SQL con Datos Denormalizados

```sql
SELECT
    f.id,
    f.flight_number,
    f.flight_date,
    f.airline_route_id,
    f.status,
    a.airline_code,
    a.airline_name,
    ao.iata_code AS origin_iata_code,
    ad.iata_code AS destination_iata_code,
    CONCAT(ao.iata_code, '-', ad.iata_code) AS route_code,
    ao.name AS origin_airport_name,
    ad.name AS destination_airport_name,
    r.estimated_flight_time
FROM flight f
JOIN airline_route ar ON f.airline_route_id = ar.id
JOIN airline a ON ar.airline_id = a.id
JOIN route r ON ar.route_id = r.id
JOIN airport ao ON r.origin_airport_id = ao.id
JOIN airport ad ON r.destination_airport_id = ad.id
WHERE f.id = ?;
```

---

## Archivos Principales Modificados

| Categoría      | Archivos                                                             |
| -------------- | -------------------------------------------------------------------- |
| **Handlers**   | `flight_controller.go`, `flight.go`, `handler.go`, `hateoas.go`      |
| **Interactor** | `interactor_flight.go`                                               |
| **Services**   | `flight_services.go`                                                 |
| **Domain**     | `domain/flight.go`, `domain/erros.go`                                |
| **Ports**      | `input/service.go`, `output/repository.go`                           |
| **Repository** | `repositories/flight/repository.go`                                  |
| **Logger**     | `log_messages.go`                                                    |
| **Cache**      | `platform/cache/messaging/cache.go`                                  |
| **Dependency** | `cmd/dependency/dependency.go`                                       |
| **Server**     | `server/server.go`                                                   |
| **Tests**      | `http_test.go`, `airline_http_test.go`, `airport_http_test.go`, `message_http_test.go` |

---

## Scripts SQL

- `docs/sql/add_flight_messages.sql` - Mensajes del sistema para el módulo Flight

---

## Notas de Release

1. Este release implementa las operaciones CRUD para Vuelo (Flight): consultar por ID, listar todos, crear y actualizar.
2. Los endpoints GET son **públicos** (no requieren autenticación JWT). Los endpoints POST y PUT son **protegidos**.
3. Los endpoints aceptan tanto UUID directo como ID ofuscado (HashID) para mayor flexibilidad.
4. Se puede filtrar la lista de vuelos por `airline_route_id` o por `flight_date`.
5. La respuesta incluye datos denormalizados: código de aerolínea, nombre de aerolínea, código de ruta (BOG-CLO), nombres de aeropuertos, tiempo estimado de vuelo.
6. La arquitectura sigue el patrón hexagonal establecido: Handler → Interactor → Service → Repository.
7. Se implementa HATEOAS (Richardson Maturity Model Level 3) para navegación entre recursos relacionados.
8. Los vuelos se crean con status 'SCHEDULED' por defecto.
9. Los estados de vuelo son: SCHEDULED, IN_PROGRESS, COMPLETED, CANCELLED.
10. La tabla `flight` referencia a `airline_route` para obtener información de ruta y aerolínea.
