# Release 03 - Eliminar Empleado

## Información General

| Campo | Valor |
|-------|-------|
| **Versión** | v0.3.0 |
| **Rama** | develop |
| **Sprint** | Sprint 2 |
| **Horas Planificadas** | 8 horas |
| **Pull Requests** | Pendiente |

---

## Historias de Usuario Incluidas

| Código | Historia de Usuario | Talla | Horas | Full Stack |
|--------|---------------------|-------|-------|------------|
| HU24 | Eliminar la Información del Empleado | M | 8 | 🟡 |

---

## Componentes Implementados

### 1. Eliminar Empleado (HU24)
- Endpoint: `DELETE /flighthours/api/v1/employees/:id`
- Acepta UUID o ID ofuscado
- Elimina primero de Keycloak, luego de la base de datos
- Operación irreversible

---

## Escenarios de Prueba

### HU24 - Eliminar la Información del Empleado

| Código | Tipo | Escenario | Código Mensaje | Estado |
|--------|------|-----------|----------------|--------|
| DEL-CA1 | ✅ Éxito | **Dado que** un Administrador del Sistema desea eliminar un empleado del sistema, **cuando** acceda a la funcionalidad de eliminación de empleados, seleccione al empleado a eliminar y confirme la acción, **entonces** el sistema eliminará el usuario del sistema de autenticación (Keycloak), eliminará el registro del empleado de la base de datos, mostrará el mensaje satisfactorio con el código `MOD_U_DEL_EXI_00003` y actualizará la vista para reflejar la eliminación. | `MOD_U_DEL_EXI_00003` | ✅ Aceptado |
| DEL-CA2 | ❌ Error | **Dado que** un Administrador del Sistema desea eliminar un empleado, **cuando** ingrese un identificador que no corresponde a ningún empleado registrado en el sistema, **entonces** el sistema validará que el empleado no existe, mostrará el mensaje de error con el código `MOD_U_GET_ERR_00003` y no permitirá continuar con la eliminación. | `MOD_U_GET_ERR_00003` | ✅ Aceptado |
| DEL-CA3 | ❌ Error | **Dado que** un Administrador del Sistema desea eliminar un empleado, **cuando** ingrese un identificador con formato incorrecto o inválido, **entonces** el sistema validará el formato del identificador, determinará que es inválido, mostrará el mensaje de error con el código `MOD_V_ID_ERR_00013` y solicitará al usuario que corrija el dato ingresado. | `MOD_V_ID_ERR_00013` | ✅ Aceptado |
| DEL-CA4 | ❌ Error | **Dado que** un Administrador del Sistema desea eliminar un empleado, **cuando** el sistema no pueda completar la operación debido a una falla interna (por ejemplo, error al eliminar de Keycloak o de la base de datos), **entonces** el sistema detectará la condición de error, mostrará el mensaje con el código `MOD_U_DEL_ERR_00012` indicando que no se pudo eliminar al empleado y sugerirá al usuario intentar nuevamente más tarde. | `MOD_U_DEL_ERR_00012` | ✅ Aceptado |

---

## Archivos Principales Modificados

| Categoría | Archivos |
|-----------|----------|
| **Ports** | `core/ports/input/service.go` |
| **Services** | `core/interactor/services/employee_services.go` |
| **Interactor** | `core/interactor/interactor.go` |
| **Handlers** | `handlers/employee_controller.go` |
| **Logger** | `platform/logger/log_messages.go` |
| **Cache** | `platform/cache/messaging/cache.go` |
| **Server** | `server/server.go` |

---

## Flujo Técnico

```
1. DELETE /employees/:id recibido
2. Handler valida y decodifica ID (ofuscado o UUID)
3. Interactor busca empleado por ID para obtener keycloakUserID
4. Si empleado no existe → Error 404 (MOD_U_GET_ERR_00003)
5. Service.DeleteEmployee():
   a. Elimina usuario de Keycloak (si tiene keycloakUserID)
   b. Elimina registro de la base de datos
6. Si error en cualquier paso → Error 500 (MOD_U_DEL_ERR_00012)
7. Éxito → 200 OK (MOD_U_DEL_EXI_00003)
```

---

## Consideraciones de Seguridad

1. **Orden de eliminación**: Primero se elimina de Keycloak, luego de la BD. Esto prioriza la seguridad (eliminar acceso antes que datos).
2. **Irreversibilidad**: Una vez eliminado, no hay forma de recuperar los datos del empleado.
3. **Punto de fallo**: Si la eliminación de Keycloak tiene éxito pero la de BD falla, el sistema queda en estado inconsistente (usuario sin acceso pero registro en BD). Este escenario prioriza la seguridad.

---

## Notas de Release

1. Este release completa el **CRUD de empleado** con la funcionalidad DELETE.
2. La eliminación es permanente e irreversible.
3. Se recomienda implementar soft-delete (desactivar) en lugar de hard-delete para casos de producción.
4. Considerar agregar confirmación adicional o autorización de roles antes de eliminar.
