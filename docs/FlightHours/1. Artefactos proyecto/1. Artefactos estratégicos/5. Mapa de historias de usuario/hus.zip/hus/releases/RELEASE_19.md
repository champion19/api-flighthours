# Release 19: Resumen de Horas de Vuelo - Reportes

**Tag Git**: `v0.20.0`
**Estado**: 🔜 Pendiente
**Total Horas**: 32h

## Historias de Usuario

| HU   | Descripción                                                    | Horas | Endpoint                                      | Estado | Full Stack |
| ---- | -------------------------------------------------------------- | ----- | --------------------------------------------- | ------ | ---------- |
| N/A  | Consultar Resumen de Horas por Período                         | 16h   | `GET /employees/{id}/flight-summary`          | 🔜     | 🟡         |
| N/A  | Generar/Actualizar Resumen de Período                          | 16h   | `POST /employees/{id}/flight-summary/refresh` | 🔜     | 🟡         |

## Dependencias

- ✅ Release 1: Empleado (FK employee_id)
- ✅ Release 12: Detalle Bitácora (fuente de datos)
- ✅ Release 18: Limitaciones (para comparación)

## Estructura del Módulo Employee Flight Summary

```
core/
├── interactor/
│   ├── interactor_flight_summary.go
│   └── services/
│       ├── flight_summary_services.go
│       └── domain/
│           └── flight_summary.go
handlers/
├── flight_summary.go
└── flight_summary_controller.go
platform/
└── databases/
    └── repositories/
        └── flight_summary/
```

## Notas Técnicas

> 📊 **Tabla de agregación**: Almacena totales pre-calculados por período.
> 🔄 **Actualización**: Se puede refrescar bajo demanda o automáticamente.
> 📈 **Campos de totales**: total_air_time, total_block_time, total_duty_time, total_flights, total_landings
> 🎯 **Campos CAT**: cat_approaches, last_cat_approach_date
> 🔗 **Richardson Maturity Model Level 3**: Todos los endpoints incluyen HATEOAS links.

## Tabla de Base de Datos

```sql
CREATE TABLE employee_flight_summary (
    id VARCHAR(36) NOT NULL,
    employee_id VARCHAR(36) NOT NULL,
    period_type VARCHAR(20) NOT NULL,
    period_year INT NOT NULL,
    period_number INT NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    total_air_time INTEGER DEFAULT 0,
    total_block_time INTEGER DEFAULT 0,
    total_duty_time INTEGER DEFAULT 0,
    total_flights INTEGER DEFAULT 0,
    total_landings INTEGER DEFAULT 0,
    cat_approaches INTEGER DEFAULT 0,
    last_cat_approach_date DATE,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_summary_employee FOREIGN KEY (employee_id) REFERENCES employee(id),
    UNIQUE KEY uq_employee_period (employee_id, period_type, period_year, period_number)
);
```

## Lógica de Generación

1. Consultar `daily_logbook_detail` para el período
2. Sumar air_time, block_time, duty_time
3. Contar vuelos y aterrizajes
4. Contar aproximaciones CAT (approach_type IN ('PA', 'APV'))
5. Actualizar o insertar en `employee_flight_summary`
