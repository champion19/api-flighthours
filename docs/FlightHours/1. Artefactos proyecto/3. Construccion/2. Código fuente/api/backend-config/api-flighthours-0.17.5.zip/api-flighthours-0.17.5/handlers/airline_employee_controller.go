package handlers

import (
	"time"

	domain "github.com/champion19/api-flighthours/core/interactor/services/domain"
	"github.com/champion19/api-flighthours/middleware"
	"github.com/champion19/api-flighthours/platform/logger"
	"github.com/gin-gonic/gin"
)

const (
	pathEmployeesAirline = "/flighthours/api/v1/employees/airline"
	pathEmployees        = "/flighthours/api/v1/employees"
)

// parseDatesFromRequest parses start_date and optional end_date from the request.
func parseDatesFromRequest(startDateStr, endDateStr string) (time.Time, time.Time, error) {
	startDate, err := time.ParseInLocation(dateFormatISO, startDateStr, time.Local)
	if err != nil {
		return time.Time{}, time.Time{}, err
	}

	var endDate time.Time
	if endDateStr != "" {
		endDate, err = time.ParseInLocation(dateFormatISO, endDateStr, time.Local)
		if err != nil {
			return time.Time{}, time.Time{}, err
		}
	}
	return startDate, endDate, nil
}

// GetEmployeeAirlineInfo godoc
// @Summary      Get authenticated employee's airline information
// @Description  Returns the airline information (airline_id, airline_name, bp) of the authenticated employee
// @Tags         AirlineEmployees
// @Produce      json
// @Security     BearerAuth
// @Success      200  {object}  EmployeeAirlineInfoResponse
// @Failure      401  {object}  middleware.ErrorResponse "Not authenticated"
// @Failure      404  {object}  middleware.ErrorResponse "Employee not found or no airline assigned"
// @Failure      500  {object}  middleware.ErrorResponse "Internal server error"
// @Router       /employees/airline [get]
func (h handler) GetEmployeeAirlineInfo() gin.HandlerFunc {
	return func(c *gin.Context) {
		traceID := middleware.GetRequestID(c)
		log := log.WithTraceID(traceID)

		log.Info(logger.LogAirlineEmployeeGet, "endpoint", "GET /employees/airline", "client_ip", c.ClientIP())

		// Get authenticated employee (core data)
		employee, exists := middleware.GetAuthenticatedUser(c)
		if !exists {
			log.Error(logger.LogEmployeeNotFound, "error", logger.LogErrAuthUserNotInContext, "client_ip", c.ClientIP())
			h.Response.Error(c, domain.MsgUnauthorized)
			return
		}

		// Get airline info for this employee
		airlineInfo, err := h.AirlineEmployeeInteractor.GetAirlineEmployeeByID(c.Request.Context(), employee.ID)

		response := EmployeeAirlineInfoResponse{}

		// If airline info exists, populate the response
		if err == nil && airlineInfo != nil && airlineInfo.AirlineID != "" {
			airline, err := h.AirlineInteractor.GetAirlineByID(c.Request.Context(), airlineInfo.AirlineID)
			if err == nil && airline != nil {
				encodedAirlineID, _ := h.EncodeID(airline.ID)
				response.AirlineID = encodedAirlineID
				response.AirlineName = airline.AirlineName
				response.AirlineCode = airline.AirlineCode
			}
			response.Bp = airlineInfo.Bp
			if !airlineInfo.StartDate.IsZero() {
				response.StartDate = airlineInfo.StartDate.Format(dateFormatISO)
			}
			if !airlineInfo.EndDate.IsZero() {
				response.EndDate = airlineInfo.EndDate.Format(dateFormatISO)
			}
		}

		baseURL := GetBaseURL(c)
		response.Links = []Link{
			{Href: baseURL + pathEmployeesAirline, Rel: "self", Method: "GET"},
			{Href: baseURL + pathEmployeesAirline, Rel: "update", Method: "PUT"},
			{Href: baseURL + pathEmployees, Rel: "profile", Method: "GET"},
		}

		log.Success(logger.LogAirlineEmployeeGetOK, "employee_id", employee.ID, "has_airline", response.AirlineID != "", "client_ip", c.ClientIP())
		h.Response.SuccessWithData(c, domain.MsgAirlineEmployeeGetOK, response)
	}
}

// AddEmployeeAirlineInfo godoc
// @Summary      Add airline information for authenticated employee
// @Description  Adds airline information (airline_id, bp, start_date, end_date) for the authenticated employee. New employees are set as active=true by default. The 'active' field is not accepted - use activate/deactivate endpoints for that.
// @Tags         AirlineEmployees
// @Accept       json
// @Produce      json
// @Security     BearerAuth
// @Param        airline body AddEmployeeAirlineRequest true "Airline information to add (airline_id, bp, start_date, end_date)"
// @Success      200  {object}  AddEmployeeAirlineResponse "Airline info added successfully"
// @Failure      400  {object}  middleware.ErrorResponse "Invalid request data or date format"
// @Failure      401  {object}  middleware.ErrorResponse "Not authenticated"
// @Failure      422  {object}  middleware.ErrorResponse "Invalid airline_id reference"
// @Failure      500  {object}  middleware.ErrorResponse "Internal server error"
// @Router       /employees/airline [put]
func (h handler) AddEmployeeAirlineInfo() gin.HandlerFunc {
	return func(c *gin.Context) {
		traceID := middleware.GetRequestID(c)
		log := log.WithTraceID(traceID)

		log.Info(logger.LogAirlineEmployeeAdd, "endpoint", "PUT /employees/airline", "client_ip", c.ClientIP())

		employee, exists := middleware.GetAuthenticatedUser(c)
		if !exists {
			log.Error(logger.LogEmployeeNotFound, "error", logger.LogErrAuthUserNotInContext, "client_ip", c.ClientIP())
			h.Response.Error(c, domain.MsgUnauthorized)
			return
		}

		var req AddEmployeeAirlineRequest
		if err := c.ShouldBindJSON(&req); err != nil {
			log.Error(logger.LogRegJSONParseError, "error", err, "client_ip", c.ClientIP())
			h.Response.Error(c, domain.MsgValInvalidReq)
			return
		}

		req.Sanitize()

		airlineUUID, airline, errMsg := h.resolveAndVerifyAirline(c, req.AirlineID, logger.LogAirlineEmployeeAddError)
		if errMsg != "" {
			h.Response.Error(c, errMsg)
			return
		}

		startDate, endDate, err := parseDatesFromRequest(req.StartDate, req.EndDate)
		if err != nil {
			log.Error(logger.LogAirlineEmployeeAddError, "error", err, "client_ip", c.ClientIP())
			h.Response.Error(c, domain.MsgValInvalidDateFormat)
			return
		}

		airlineEmployeeInfo := domain.AirlineEmployee{
			ID:        employee.ID,
			AirlineID: airlineUUID,
			Bp:        req.Bp,
			StartDate: startDate,
			EndDate:   endDate,
			Active:    true,
		}

		if err := h.AirlineEmployeeInteractor.AddAirlineEmployee(c.Request.Context(), employee.ID, airlineEmployeeInfo); err != nil {
			log.Error(logger.LogAirlineEmployeeAddError, "error", err, "client_ip", c.ClientIP())
			h.Response.Error(c, mapAirlineEmployeeSaveError(err))
			return
		}

		encodedAirlineID, _ := h.EncodeID(airline.ID)
		response := AddEmployeeAirlineResponse{
			AirlineID:   encodedAirlineID,
			AirlineName: airline.AirlineName,
			Bp:          req.Bp,
			StartDate:   startDate.Format(dateFormatISO),
			EndDate:     endDate.Format(dateFormatISO),
		}

		baseURL := GetBaseURL(c)
		response.Links = []Link{
			{Href: baseURL + pathEmployeesAirline, Rel: "self", Method: "GET"},
			{Href: baseURL + pathEmployees, Rel: "profile", Method: "GET"},
		}

		log.Success(logger.LogAirlineEmployeeAddOK, "employee_id", employee.ID, "airline_id", airlineUUID, "client_ip", c.ClientIP())
		h.Response.SuccessWithData(c, domain.MsgAirlineEmployeeCreated, response)
	}
}

// UpdateEmployeeAirlineInfo godoc
// @Summary      Edit airline information for authenticated employee
// @Description  Updates the airline information (airline_id, bp, start_date, end_date) for the authenticated employee who already has airline info. The 'active' field is not editable - use activate/deactivate endpoints. Requires existing airline info.
// @Tags         AirlineEmployees
// @Accept       json
// @Produce      json
// @Security     BearerAuth
// @Param        airline body UpdateEmployeeAirlineRequest true "Airline information to update (airline_id, bp, start_date, end_date)"
// @Success      200  {object}  UpdateEmployeeAirlineResponse "Airline info updated successfully"
// @Failure      400  {object}  middleware.ErrorResponse "Invalid request data or date format"
// @Failure      401  {object}  middleware.ErrorResponse "Not authenticated"
// @Failure      404  {object}  middleware.ErrorResponse "Employee has no airline info to update"
// @Failure      422  {object}  middleware.ErrorResponse "Invalid airline_id reference"
// @Failure      500  {object}  middleware.ErrorResponse "Internal server error"
// @Router       /employees/airline-info [put]
func (h handler) UpdateEmployeeAirlineInfo() gin.HandlerFunc {
	return func(c *gin.Context) {
		traceID := middleware.GetRequestID(c)
		log := log.WithTraceID(traceID)

		log.Info(logger.LogAirlineEmployeeUpdate, "endpoint", "PUT /employees/airline-info", "client_ip", c.ClientIP())

		employee, exists := middleware.GetAuthenticatedUser(c)
		if !exists {
			log.Error(logger.LogEmployeeNotFound, "error", logger.LogErrAuthUserNotInContext, "client_ip", c.ClientIP())
			h.Response.Error(c, domain.MsgUnauthorized)
			return
		}

		// Verify employee has existing airline info before allowing update
		existingAirlineInfo, err := h.AirlineEmployeeInteractor.GetAirlineEmployeeByID(c.Request.Context(), employee.ID)
		if err != nil || existingAirlineInfo == nil || existingAirlineInfo.AirlineID == "" {
			log.Error(logger.LogAirlineEmployeeNotFound, "error", logger.LogErrEmployeeNoAirlineInfo, "client_ip", c.ClientIP())
			h.Response.Error(c, domain.MsgAirlineEmployeeNotFound)
			return
		}

		var req UpdateEmployeeAirlineRequest
		if err := c.ShouldBindJSON(&req); err != nil {
			log.Error(logger.LogRegJSONParseError, "error", err, "client_ip", c.ClientIP())
			h.Response.Error(c, domain.MsgValInvalidReq)
			return
		}

		req.Sanitize()

		airlineUUID, airline, errMsg := h.resolveAndVerifyAirline(c, req.AirlineID, logger.LogAirlineEmployeeUpdateError)
		if errMsg != "" {
			h.Response.Error(c, errMsg)
			return
		}

		startDate, endDate, err := parseDatesFromRequest(req.StartDate, req.EndDate)
		if err != nil {
			log.Error(logger.LogAirlineEmployeeUpdateError, "error", err, "client_ip", c.ClientIP())
			h.Response.Error(c, domain.MsgValInvalidDateFormat)
			return
		}

		airlineEmployeeInfo := domain.AirlineEmployee{
			ID:        employee.ID,
			AirlineID: airlineUUID,
			Bp:        req.Bp,
			StartDate: startDate,
			EndDate:   endDate,
			Active:    existingAirlineInfo.Active,
		}

		if err := h.AirlineEmployeeInteractor.UpdateAirlineEmployee(c.Request.Context(), employee.ID, airlineEmployeeInfo); err != nil {
			log.Error(logger.LogAirlineEmployeeUpdateError, "error", err, "client_ip", c.ClientIP())
			h.Response.Error(c, mapAirlineEmployeeUpdateError(err))
			return
		}

		encodedAirlineID, _ := h.EncodeID(airline.ID)
		response := UpdateEmployeeAirlineResponse{
			Updated:     true,
			AirlineID:   encodedAirlineID,
			AirlineName: airline.AirlineName,
			Bp:          req.Bp,
			StartDate:   startDate.Format(dateFormatISO),
			EndDate:     endDate.Format(dateFormatISO),
		}

		baseURL := GetBaseURL(c)
		response.Links = []Link{
			{Href: baseURL + pathEmployeesAirline, Rel: "self", Method: "GET"},
			{Href: baseURL + pathEmployees, Rel: "profile", Method: "GET"},
		}

		log.Success(logger.LogAirlineEmployeeUpdateOK, "employee_id", employee.ID, "airline_id", airlineUUID, "client_ip", c.ClientIP())
		h.Response.SuccessWithData(c, domain.MsgAirlineEmployeeUpdated, response)
	}
}

// resolveAndVerifyAirline resolves the airline ID and verifies the airline exists.
func (h handler) resolveAndVerifyAirline(c *gin.Context, airlineID, logMsg string) (string, *domain.Airline, string) {
	airlineUUID, _ := h.resolveID(airlineID)
	if airlineUUID == "" {
		log.Error(logMsg, "error", logger.LogErrInvalidAirlineID, "client_ip", c.ClientIP())
		return "", nil, domain.MsgAirlineEmployeeInvalidAirline
	}

	airline, err := h.AirlineInteractor.GetAirlineByID(c.Request.Context(), airlineUUID)
	if err != nil || airline == nil {
		log.Error(logMsg, "error", logger.LogErrAirlineNotFound, "airline_id", airlineUUID, "client_ip", c.ClientIP())
		return "", nil, domain.MsgAirlineEmployeeInvalidAirline
	}

	return airlineUUID, airline, ""
}

func mapAirlineEmployeeSaveError(err error) string {
	if err == domain.ErrInvalidForeignKey {
		return domain.MsgAirlineEmployeeInvalidAirline
	}
	return domain.MsgAirlineEmployeeSaveError
}

func mapAirlineEmployeeUpdateError(err error) string {
	if err == domain.ErrInvalidForeignKey {
		return domain.MsgAirlineEmployeeInvalidAirline
	}
	return domain.MsgAirlineEmployeeUpdateError
}

// ActivateEmployeeAirlineInfo godoc
// @Summary      Activate airline information for authenticated employee
// @Description  Activates the airline information for the authenticated employee. The employee must already have airline info assigned.
// @Tags         AirlineEmployees
// @Produce      json
// @Security     BearerAuth
// @Success      200  {object}  StatusChangeResponse "Airline info activated successfully"
// @Failure      401  {object}  middleware.ErrorResponse "Not authenticated"
// @Failure      404  {object}  middleware.ErrorResponse "Employee has no airline info to activate"
// @Failure      500  {object}  middleware.ErrorResponse "Internal server error"
// @Router       /employees/airline/activate [patch]
func (h handler) ActivateEmployeeAirlineInfo() gin.HandlerFunc {
	return func(c *gin.Context) {
		traceID := middleware.GetRequestID(c)
		log := log.WithTraceID(traceID)

		log.Info(logger.LogAirlineEmployeeActivate, "endpoint", "PATCH /employees/airline/activate", "client_ip", c.ClientIP())

		// Get authenticated employee (core data)
		employee, exists := middleware.GetAuthenticatedUser(c)
		if !exists {
			log.Error(logger.LogEmployeeNotFound, "error", logger.LogErrAuthUserNotInContext, "client_ip", c.ClientIP())
			h.Response.Error(c, domain.MsgUnauthorized)
			return
		}

		// Activate via AirlineEmployeeInteractor
		if err := h.AirlineEmployeeInteractor.ActivateAirlineEmployee(c.Request.Context(), employee.ID); err != nil {
			log.Error(logger.LogAirlineEmployeeActivateError, "error", err, "client_ip", c.ClientIP())
			if err == domain.ErrAirlineEmployeeNotFound {
				h.Response.Error(c, domain.MsgAirlineEmployeeNotFound)
				return
			}
			h.Response.Error(c, domain.MsgAirlineEmployeeActivateErr)
			return
		}

		response := StatusChangeResponse{
			Success: true,
			Active:  true,
		}

		baseURL := GetBaseURL(c)
		response.Links = []Link{
			{Href: baseURL + pathEmployeesAirline, Rel: "self", Method: "GET"},
			{Href: baseURL + pathEmployeesAirline + "/deactivate", Rel: "deactivate", Method: "PATCH"},
			{Href: baseURL + pathEmployees, Rel: "profile", Method: "GET"},
		}

		log.Success(logger.LogAirlineEmployeeActivateOK, "employee_id", employee.ID, "client_ip", c.ClientIP())
		h.Response.SuccessWithData(c, domain.MsgAirlineEmployeeActivateOK, response)
	}
}

// DeactivateEmployeeAirlineInfo godoc
// @Summary      Deactivate airline information for authenticated employee
// @Description  Deactivates the airline information for the authenticated employee. The employee must already have airline info assigned.
// @Tags         AirlineEmployees
// @Produce      json
// @Security     BearerAuth
// @Success      200  {object}  StatusChangeResponse "Airline info deactivated successfully"
// @Failure      401  {object}  middleware.ErrorResponse "Not authenticated"
// @Failure      404  {object}  middleware.ErrorResponse "Employee has no airline info to deactivate"
// @Failure      500  {object}  middleware.ErrorResponse "Internal server error"
// @Router       /employees/airline/deactivate [patch]
func (h handler) DeactivateEmployeeAirlineInfo() gin.HandlerFunc {
	return func(c *gin.Context) {
		traceID := middleware.GetRequestID(c)
		log := log.WithTraceID(traceID)

		log.Info(logger.LogAirlineEmployeeDeactivate, "endpoint", "PATCH /employees/airline/deactivate", "client_ip", c.ClientIP())

		// Get authenticated employee (core data)
		employee, exists := middleware.GetAuthenticatedUser(c)
		if !exists {
			log.Error(logger.LogEmployeeNotFound, "error", logger.LogErrAuthUserNotInContext, "client_ip", c.ClientIP())
			h.Response.Error(c, domain.MsgUnauthorized)
			return
		}

		// Deactivate via AirlineEmployeeInteractor
		if err := h.AirlineEmployeeInteractor.DeactivateAirlineEmployee(c.Request.Context(), employee.ID); err != nil {
			log.Error(logger.LogAirlineEmployeeDeactivateError, "error", err, "client_ip", c.ClientIP())
			if err == domain.ErrAirlineEmployeeNotFound {
				h.Response.Error(c, domain.MsgAirlineEmployeeNotFound)
				return
			}
			h.Response.Error(c, domain.MsgAirlineEmployeeDeactivateErr)
			return
		}

		response := StatusChangeResponse{
			Success: true,
			Active:  false,
		}

		baseURL := GetBaseURL(c)
		response.Links = []Link{
			{Href: baseURL + pathEmployeesAirline, Rel: "self", Method: "GET"},
			{Href: baseURL + pathEmployeesAirline + "/activate", Rel: "activate", Method: "PATCH"},
			{Href: baseURL + pathEmployees, Rel: "profile", Method: "GET"},
		}

		log.Success(logger.LogAirlineEmployeeDeactivateOK, "employee_id", employee.ID, "client_ip", c.ClientIP())
		h.Response.SuccessWithData(c, domain.MsgAirlineEmployeeDeactivateOK, response)
	}
}
