package interactor

import (
	"context"
	"errors"
	"testing"

	"github.com/champion19/api-flighthours/core/interactor/services/domain"
	"github.com/champion19/api-flighthours/core/ports/input"
	"github.com/champion19/api-flighthours/core/ports/output"
)

type fakeMsgService struct {
	validateFn func(ctx context.Context, msg domain.Message) error
	beginTxFn  func(ctx context.Context) (output.Tx, error)
	saveFn     func(ctx context.Context, tx output.Tx, msg domain.Message) error
	getByIDFn  func(ctx context.Context, id string) (*domain.Message, error)
	updateFn   func(ctx context.Context, tx output.Tx, msg domain.Message) error
	deleteFn   func(ctx context.Context, tx output.Tx, id string) error
}

var _ input.MessageService = (*fakeMsgService)(nil)

func (f *fakeMsgService) BeginTx(ctx context.Context) (output.Tx, error) { return f.beginTxFn(ctx) }
func (f *fakeMsgService) ValidateMessage(ctx context.Context, msg domain.Message) error {
	return f.validateFn(ctx, msg)
}
func (f *fakeMsgService) GetMessageByID(ctx context.Context, id string) (*domain.Message, error) {
	return f.getByIDFn(ctx, id)
}
func (f *fakeMsgService) GetMessageByCode(context.Context, string) (*domain.Message, error) {
	return nil, errors.New("not implemented")
}
func (f *fakeMsgService) ListMessages(context.Context, map[string]interface{}) ([]domain.Message, error) {
	return nil, errors.New("not implemented")
}
func (f *fakeMsgService) ListActiveMessages(context.Context) ([]domain.Message, error) {
	return nil, errors.New("not implemented")
}
func (f *fakeMsgService) SaveMessageToDB(ctx context.Context, tx output.Tx, msg domain.Message) error {
	return f.saveFn(ctx, tx, msg)
}
func (f *fakeMsgService) UpdateMessageInDB(ctx context.Context, tx output.Tx, msg domain.Message) error {
	return f.updateFn(ctx, tx, msg)
}
func (f *fakeMsgService) DeleteMessageFromDB(ctx context.Context, tx output.Tx, id string) error {
	return f.deleteFn(ctx, tx, id)
}

func TestMessageInteractor_CreateMessage(t *testing.T) {
	ctx := context.Background()
	msg := domain.Message{Code: "C1"}

	t.Run("validate fails => returns error, no tx", func(t *testing.T) {
		validateErr := errors.New("invalid")
		calledBegin := 0
		svc := &fakeMsgService{
			validateFn: func(context.Context, domain.Message) error { return validateErr },
			beginTxFn:  func(context.Context) (output.Tx, error) { calledBegin++; return nil, nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		_, err := i.CreateMessage(ctx, msg)
		if !errors.Is(err, validateErr) {
			t.Fatalf("expected %v, got %v", validateErr, err)
		}
		if calledBegin != 0 {
			t.Fatalf("expected BeginTx not called")
		}
	})

	t.Run("save fails => rollback", func(t *testing.T) {
		tx := &fakeTx{}
		saveErr := errors.New("save failed")
		svc := &fakeMsgService{
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return tx, nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return saveErr },
		}
		i := NewMessageInteractor(svc)

		_, err := i.CreateMessage(ctx, msg)
		if !errors.Is(err, saveErr) {
			t.Fatalf("expected %v, got %v", saveErr, err)
		}
		if !tx.rolledBack {
			t.Fatalf("expected rollback")
		}
		if tx.committed {
			t.Fatalf("did not expect commit")
		}
	})

	t.Run("commit fails => rollback", func(t *testing.T) {
		commitErr := errors.New("commit failed")
		tx := &fakeTx{commitFn: func() error { return commitErr }}
		svc := &fakeMsgService{
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return tx, nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		_, err := i.CreateMessage(ctx, msg)
		if !errors.Is(err, commitErr) {
			t.Fatalf("expected error")
		}
		if !tx.committed {
			t.Fatalf("expected commit called")
		}
		if !tx.rolledBack {
			t.Fatalf("expected rollback on commit error")
		}
	})

	t.Run("success => commit true, rollback false", func(t *testing.T) {
		tx := &fakeTx{}
		svc := &fakeMsgService{
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return tx, nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		res, err := i.CreateMessage(ctx, msg)
		if err != nil {
			t.Fatalf("expected nil error, got %v", err)
		}
		if res == nil {
			t.Fatalf("expected non-nil result")
		}
		if !tx.committed || tx.rolledBack {
			t.Fatalf("unexpected tx state committed=%v rolledBack=%v", tx.committed, tx.rolledBack)
		}
	})

	t.Run("BeginTx fails => returns error", func(t *testing.T) {
		beginErr := errors.New("begin tx failed")
		svc := &fakeMsgService{
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return nil, beginErr },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		_, err := i.CreateMessage(ctx, msg)
		if !errors.Is(err, beginErr) {
			t.Fatalf("expected %v, got %v", beginErr, err)
		}
	})

	t.Run("save fails with rollback error => logs rollback error", func(t *testing.T) {
		rollbackErr := errors.New("rollback failed")
		tx := &fakeTx{rollbackFn: func() error { return rollbackErr }}
		saveErr := errors.New("save failed")
		svc := &fakeMsgService{
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return tx, nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return saveErr },
		}
		i := NewMessageInteractor(svc)

		_, err := i.CreateMessage(ctx, msg)
		// Main error is still the save error
		if !errors.Is(err, saveErr) {
			t.Fatalf("expected %v, got %v", saveErr, err)
		}
	})
}

func TestMessageInteractor_UpdateAndDelete(t *testing.T) {
	ctx := context.Background()

	t.Run("update: not found => error", func(t *testing.T) {
		nf := domain.ErrMessageNotFound
		svc := &fakeMsgService{
			getByIDFn: func(context.Context, string) (*domain.Message, error) { return nil, nf },
			validateFn: func(context.Context, domain.Message) error {
				return nil
			},
			beginTxFn: func(context.Context) (output.Tx, error) { return &fakeTx{}, nil },
			updateFn:  func(context.Context, output.Tx, domain.Message) error { return nil },
			deleteFn:  func(context.Context, output.Tx, string) error { return nil },
			saveFn:    func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		_, err := i.UpdateMessage(ctx, domain.Message{ID: "x", Code: "C"})
		if !errors.Is(err, nf) {
			t.Fatalf("expected %v, got %v", nf, err)
		}
	})

	t.Run("update: validation fails => error", func(t *testing.T) {
		validateErr := errors.New("invalid message")
		svc := &fakeMsgService{
			getByIDFn: func(context.Context, string) (*domain.Message, error) {
				return &domain.Message{ID: "x"}, nil
			},
			validateFn: func(context.Context, domain.Message) error { return validateErr },
			beginTxFn:  func(context.Context) (output.Tx, error) { return &fakeTx{}, nil },
			updateFn:   func(context.Context, output.Tx, domain.Message) error { return nil },
			deleteFn:   func(context.Context, output.Tx, string) error { return nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		_, err := i.UpdateMessage(ctx, domain.Message{ID: "x", Code: "C"})
		if !errors.Is(err, validateErr) {
			t.Fatalf("expected %v, got %v", validateErr, err)
		}
	})

	t.Run("update: BeginTx fails => error", func(t *testing.T) {
		beginErr := errors.New("tx begin failed")
		svc := &fakeMsgService{
			getByIDFn: func(context.Context, string) (*domain.Message, error) {
				return &domain.Message{ID: "x"}, nil
			},
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return nil, beginErr },
			updateFn:   func(context.Context, output.Tx, domain.Message) error { return nil },
			deleteFn:   func(context.Context, output.Tx, string) error { return nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		_, err := i.UpdateMessage(ctx, domain.Message{ID: "x", Code: "C"})
		if !errors.Is(err, beginErr) {
			t.Fatalf("expected %v, got %v", beginErr, err)
		}
	})

	t.Run("update: UpdateMessageInDB fails => rollback", func(t *testing.T) {
		tx := &fakeTx{}
		updateErr := errors.New("update failed")
		svc := &fakeMsgService{
			getByIDFn: func(context.Context, string) (*domain.Message, error) {
				return &domain.Message{ID: "x"}, nil
			},
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return tx, nil },
			updateFn:   func(context.Context, output.Tx, domain.Message) error { return updateErr },
			deleteFn:   func(context.Context, output.Tx, string) error { return nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		_, err := i.UpdateMessage(ctx, domain.Message{ID: "x", Code: "C"})
		if !errors.Is(err, updateErr) {
			t.Fatalf("expected %v, got %v", updateErr, err)
		}
		if !tx.rolledBack {
			t.Fatal("expected rollback")
		}
	})

	t.Run("update: commit fails => error", func(t *testing.T) {
		commitErr := errors.New("commit failed")
		tx := &fakeTx{commitFn: func() error { return commitErr }}
		svc := &fakeMsgService{
			getByIDFn: func(context.Context, string) (*domain.Message, error) {
				return &domain.Message{ID: "x"}, nil
			},
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return tx, nil },
			updateFn:   func(context.Context, output.Tx, domain.Message) error { return nil },
			deleteFn:   func(context.Context, output.Tx, string) error { return nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		_, err := i.UpdateMessage(ctx, domain.Message{ID: "x", Code: "C"})
		if !errors.Is(err, commitErr) {
			t.Fatalf("expected %v, got %v", commitErr, err)
		}
	})

	t.Run("update: success => returns message", func(t *testing.T) {
		tx := &fakeTx{}
		svc := &fakeMsgService{
			getByIDFn: func(context.Context, string) (*domain.Message, error) {
				return &domain.Message{ID: "x"}, nil
			},
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return tx, nil },
			updateFn:   func(context.Context, output.Tx, domain.Message) error { return nil },
			deleteFn:   func(context.Context, output.Tx, string) error { return nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		result, err := i.UpdateMessage(ctx, domain.Message{ID: "x", Code: "C"})
		if err != nil {
			t.Fatalf("expected nil error, got %v", err)
		}
		if result == nil {
			t.Fatal("expected non-nil result")
		}
		if !tx.committed {
			t.Fatal("expected commit")
		}
		if tx.rolledBack {
			t.Fatal("did not expect rollback")
		}
	})

	t.Run("update: update fails with rollback error => logs rollback error", func(t *testing.T) {
		rollbackErr := errors.New("rollback failed")
		tx := &fakeTx{rollbackFn: func() error { return rollbackErr }}
		updateErr := errors.New("update failed")
		svc := &fakeMsgService{
			getByIDFn: func(context.Context, string) (*domain.Message, error) {
				return &domain.Message{ID: "x"}, nil
			},
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return tx, nil },
			updateFn:   func(context.Context, output.Tx, domain.Message) error { return updateErr },
			deleteFn:   func(context.Context, output.Tx, string) error { return nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		_, err := i.UpdateMessage(ctx, domain.Message{ID: "x", Code: "C"})
		if !errors.Is(err, updateErr) {
			t.Fatalf("expected %v, got %v", updateErr, err)
		}
	})

	t.Run("delete: GetMessageByID fails => returns error", func(t *testing.T) {
		getErr := errors.New("not found")
		svc := &fakeMsgService{
			getByIDFn:  func(context.Context, string) (*domain.Message, error) { return nil, getErr },
			validateFn: func(context.Context, domain.Message) error { return nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return &fakeTx{}, nil },
			updateFn:   func(context.Context, output.Tx, domain.Message) error { return nil },
			deleteFn:   func(context.Context, output.Tx, string) error { return nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		err := i.DeleteMessage(ctx, "x")
		if !errors.Is(err, getErr) {
			t.Fatalf("expected %v, got %v", getErr, err)
		}
	})

	t.Run("delete: BeginTx fails => returns error", func(t *testing.T) {
		txErr := errors.New("tx failed")
		svc := &fakeMsgService{
			getByIDFn:  func(context.Context, string) (*domain.Message, error) { return &domain.Message{ID: "x"}, nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return nil, txErr },
			validateFn: func(context.Context, domain.Message) error { return nil },
			updateFn:   func(context.Context, output.Tx, domain.Message) error { return nil },
			deleteFn:   func(context.Context, output.Tx, string) error { return nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		err := i.DeleteMessage(ctx, "x")
		if !errors.Is(err, txErr) {
			t.Fatalf("expected %v, got %v", txErr, err)
		}
	})

	t.Run("delete: fails in db => rollback", func(t *testing.T) {
		tx := &fakeTx{}
		deleteErr := errors.New("delete failed")
		svc := &fakeMsgService{
			getByIDFn: func(context.Context, string) (*domain.Message, error) { return &domain.Message{ID: "x"}, nil },
			beginTxFn: func(context.Context) (output.Tx, error) { return tx, nil },
			deleteFn:  func(context.Context, output.Tx, string) error { return deleteErr },
			validateFn: func(context.Context, domain.Message) error {
				return nil
			},
			updateFn: func(context.Context, output.Tx, domain.Message) error { return nil },
			saveFn:   func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		err := i.DeleteMessage(ctx, "x")
		if !errors.Is(err, deleteErr) {
			t.Fatalf("expected %v, got %v", deleteErr, err)
		}
		if !tx.rolledBack {
			t.Fatalf("expected rollback")
		}
	})

	t.Run("delete: Commit fails => rollback", func(t *testing.T) {
		commitErr := errors.New("commit failed")
		tx := &fakeTx{commitFn: func() error { return commitErr }}
		svc := &fakeMsgService{
			getByIDFn:  func(context.Context, string) (*domain.Message, error) { return &domain.Message{ID: "x"}, nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return tx, nil },
			deleteFn:   func(context.Context, output.Tx, string) error { return nil },
			validateFn: func(context.Context, domain.Message) error { return nil },
			updateFn:   func(context.Context, output.Tx, domain.Message) error { return nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		err := i.DeleteMessage(ctx, "x")
		if !errors.Is(err, commitErr) {
			t.Fatalf("expected %v, got %v", commitErr, err)
		}
		if !tx.rolledBack {
			t.Fatalf("expected rollback on commit failure")
		}
	})

	t.Run("delete: success => commit", func(t *testing.T) {
		tx := &fakeTx{}
		svc := &fakeMsgService{
			getByIDFn: func(context.Context, string) (*domain.Message, error) { return &domain.Message{ID: "x"}, nil },
			beginTxFn: func(context.Context) (output.Tx, error) { return tx, nil },
			deleteFn:  func(context.Context, output.Tx, string) error { return nil },
			validateFn: func(context.Context, domain.Message) error {
				return nil
			},
			updateFn: func(context.Context, output.Tx, domain.Message) error { return nil },
			saveFn:   func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		err := i.DeleteMessage(ctx, "x")
		if err != nil {
			t.Fatalf("expected nil error, got %v", err)
		}
		if !tx.committed {
			t.Fatal("expected commit")
		}
		if tx.rolledBack {
			t.Fatal("did not expect rollback")
		}
	})

	t.Run("delete: delete fails with rollback error => logs rollback error", func(t *testing.T) {
		rollbackErr := errors.New("rollback failed")
		tx := &fakeTx{rollbackFn: func() error { return rollbackErr }}
		deleteErr := errors.New("delete failed")
		svc := &fakeMsgService{
			getByIDFn:  func(context.Context, string) (*domain.Message, error) { return &domain.Message{ID: "x"}, nil },
			beginTxFn:  func(context.Context) (output.Tx, error) { return tx, nil },
			deleteFn:   func(context.Context, output.Tx, string) error { return deleteErr },
			validateFn: func(context.Context, domain.Message) error { return nil },
			updateFn:   func(context.Context, output.Tx, domain.Message) error { return nil },
			saveFn:     func(context.Context, output.Tx, domain.Message) error { return nil },
		}
		i := NewMessageInteractor(svc)

		err := i.DeleteMessage(ctx, "x")
		// Main error is still the delete error
		if !errors.Is(err, deleteErr) {
			t.Fatalf("expected %v, got %v", deleteErr, err)
		}
	})
}
