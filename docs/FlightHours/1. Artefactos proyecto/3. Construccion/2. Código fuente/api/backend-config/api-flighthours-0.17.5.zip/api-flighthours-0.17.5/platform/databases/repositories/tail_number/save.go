package tailnumber

import (
	"context"
	"strings"

	domain "github.com/champion19/api-flighthours/core/interactor/services/domain"
	"github.com/champion19/api-flighthours/core/ports/output"
	"github.com/champion19/api-flighthours/platform/databases/common"
	"github.com/champion19/api-flighthours/platform/logger"
)

func (r *repository) SaveTailNumber(ctx context.Context, tx output.Tx, registration domain.TailNumber) error {
	sqlTx, err := common.CastTx(tx)
	if err != nil {
		return err
	}

	_, err = sqlTx.ExecContext(ctx, QueryInsert,
		registration.ID,
		registration.TailNumber,
		registration.AircraftModelID,
		registration.AirlineID,
	)
	if err != nil {
		log.Error(logger.LogTailNumberRepoSaveError,
			"id", registration.ID,
			"tail_number", registration.TailNumber,
			"aircraft_model_id", registration.AircraftModelID,
			"airline_id", registration.AirlineID,
			"error", err.Error())

		if strings.Contains(err.Error(), "Duplicate entry") {
			return domain.ErrTailNumberDuplicatePlate
		}
		if strings.Contains(err.Error(), "foreign key constraint") || strings.Contains(err.Error(), "FOREIGN KEY") {

			if strings.Contains(err.Error(), "aircraft_model") {
				return domain.ErrTailNumberInvalidModel
			}
			if strings.Contains(err.Error(), "airline") {
				return domain.ErrTailNumberInvalidAirline
			}
		}
		return domain.ErrTailNumberCannotSave
	}
	return nil
}
