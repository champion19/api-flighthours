package interactor

import (
	"context"

	"github.com/champion19/api-flighthours/core/interactor/dto"
	"github.com/champion19/api-flighthours/core/interactor/services/domain"
	"github.com/champion19/api-flighthours/core/ports/input"
	"github.com/champion19/api-flighthours/core/ports/output"
	"github.com/champion19/api-flighthours/middleware"
	"github.com/champion19/api-flighthours/platform/logger"
)

var log = logger.NewSlogLogger()

type Interactor struct {
	service input.Service
}

func NewInteractor(service input.Service) *Interactor {
	return &Interactor{
		service: service,
	}
}
func (i *Interactor) RegisterEmployee(ctx context.Context, employee domain.Employee) (result *dto.RegisterEmployee, err error) {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	log.Info(logger.LogEmployeeInteractorRegStart, employee.ToLogger())

	result, err = i.service.RegisterEmployee(ctx, employee)
	if err != nil {
		return i.handleRegistrationValidationError(ctx, log, employee, err)
	}
	log.Success(logger.LogEmployeeInteractorStep1_OK)

	employee.SetID()
	log.Debug(logger.LogEmployeeInteractorIDGenerated, "employee_id", employee.ID)

	if err = i.service.CheckAndCleanInconsistentState(ctx, employee.Email); err != nil {
		log.Error(logger.LogEmployeeInteractorStep15_Error, "error", err)
		return
	}
	log.Success(logger.LogEmployeeInteractorStep15_OK, "email", employee.Email)

	tx, err := i.service.BeginTx(ctx)
	if err != nil {
		log.Error(logger.LogEmployeeInteractorStep2_Error, "error", err)
		return
	}
	defer tx.Rollback()
	log.Success(logger.LogEmployeeInteractorStep2_OK)

	keycloakUserID, keycloakCreated, stepErr := i.executeRegistrationSteps(ctx, log, tx, &employee)
	if stepErr != nil {
		rollbackOnError(log, tx, keycloakCreated, keycloakUserID, i.service, ctx)
		err = stepErr
		return
	}

	if err = tx.Commit(); err != nil {
		log.Error(logger.LogEmployeeInteractorCommit_Error, "error", err)
		rollbackOnError(log, tx, keycloakCreated, keycloakUserID, i.service, ctx)
		return
	}
	log.Success(logger.LogEmployeeInteractorCommit_OK)

	employee.KeycloakUserID = keycloakUserID
	result.Employee = employee
	result.Message = logger.DtoMsgUserRegistered

	if sendErr := i.service.SendVerificationEmail(ctx, keycloakUserID); sendErr != nil {
		log.Warn(logger.LogKeycloakSendVerificationEmailError,
			"keycloak_user_id", keycloakUserID,
			"email", employee.Email,
			"error", sendErr)
	} else {
		log.Info(logger.LogKeycloakSendVerificationEmailOK, "keycloak_user_id", keycloakUserID, "email", employee.Email)
	}

	log.Success(logger.LogEmployeeInteractorRegComplete, employee.ToLogger(),
		"Keycloak_id", keycloakUserID)
	err = nil

	return
}

func (i *Interactor) handleRegistrationValidationError(ctx context.Context, log logger.Logger, employee domain.Employee, err error) (*dto.RegisterEmployee, error) {
	if err == domain.ErrIncompleteRegistration {
		log.Warn(logger.LogEmployeeInteractorIncompleteDetected, "email", employee.Email)

		if cleanErr := i.service.CheckAndCleanInconsistentState(ctx, employee.Email); cleanErr != nil {
			log.Error(logger.LogEmployeeInteractorCleanup_Error, "email", employee.Email, "error", cleanErr)
			return nil, cleanErr
		}

		log.Success(logger.LogEmployeeInteractorCleanup_OK, "email", employee.Email)
		return nil, err
	}
	log.Error(logger.LogEmployeeInteractorStep1_Error, "error", err)
	return nil, err
}

func (i *Interactor) executeRegistrationSteps(ctx context.Context, log logger.Logger, tx output.Tx, employee *domain.Employee) (string, bool, error) {
	if err := i.service.SaveEmployeeToDB(ctx, tx, *employee); err != nil {
		log.Error(logger.LogEmployeeInteractorStep3_Error, "error", err)
		return "", false, err
	}
	log.Success(logger.LogEmployeeInteractorStep3_OK)

	keycloakUserID, err := i.service.CreateUserInKeycloak(ctx, employee)
	if err != nil {
		log.Error(logger.LogEmployeeInteractorStep4_Error, "error", err)
		return "", false, domain.ErrKeycloakUserCreationFailed
	}
	log.Success(logger.LogEmployeeInteractorStep4_OK, "keycloak_user_id", keycloakUserID)

	if err = i.service.SetUserPassword(ctx, keycloakUserID, employee.Password); err != nil {
		log.Error(logger.LogEmployeeInteractorStep5_Error, "error", err)
		return keycloakUserID, true, err
	}
	log.Success(logger.LogEmployeeInteractorStep5_OK)

	if err = i.service.AssignUserRole(ctx, keycloakUserID, employee.Role); err != nil {
		log.Error(logger.LogEmployeeInteractorStep6_Error, "error", err)
		return keycloakUserID, true, err
	}
	log.Success(logger.LogEmployeeInteractorStep6_OK, "keycloak_role", employee.Role, "cargo", employee.Role)

	if err = i.service.UpdateEmployeeKeycloakID(ctx, tx, employee.ID, keycloakUserID); err != nil {
		log.Error(logger.LogEmployeeInteractorStep7_Error, "error", err)
		return keycloakUserID, true, err
	}
	log.Success(logger.LogEmployeeInteractorStep7_OK)

	return keycloakUserID, true, nil
}

func rollbackOnError(log logger.Logger, tx output.Tx, keycloakCreated bool, keycloakUserID string, svc input.Service, ctx context.Context) {
	if rbErr := tx.Rollback(); rbErr != nil {
		log.Error(logger.LogEmployeeInteractorRollbackDB_Error, "rollback_error", rbErr)
	} else {
		log.Warn(logger.LogEmployeeInteractorRollbackDB_OK)
	}

	if keycloakCreated {
		if kcErr := svc.RollbackKeycloakUser(ctx, keycloakUserID); kcErr != nil {
			log.Error(logger.LogEmployeeInteractorRollbackKeycloak_Err,
				"keycloak_error", kcErr,
				"keycloak_user_id", keycloakUserID)
		} else {
			log.Warn(logger.LogEmployeeInteractorRollbackKeycloak_OK)
		}
	}
}

func (i *Interactor) Locate(ctx context.Context, id string) (*dto.RegisterEmployee, error) {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	result, err := i.service.LocateEmployee(ctx, id)
	if err != nil {
		log.Error(logger.LogEmployeeLocateError, "error", err)
		return nil, err
	}
	return result, nil
}

func (i *Interactor) ResendVerificationEmail(ctx context.Context, email string) error {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	log.Info(logger.LogKeycloakSendVerificationEmail, "email", email)

	user, err := i.service.GetUserByEmail(ctx, email)
	if err != nil {
		log.Error(logger.LogKeycloakUserNotFound, "email", email, "error", err)
		return domain.ErrUserNotFound
	}

	if user.EmailVerified != nil && *user.EmailVerified {
		log.Warn(logger.LogKeycloakSendVerificationEmailError, "email", email, "reason", "email already verified")
		return domain.ErrEmailAlreadyVerified
	}

	if err = i.service.SendVerificationEmail(ctx, *user.ID); err != nil {
		log.Error(logger.LogKeycloakSendVerificationEmailError, "email", email, "error", err)
		return err
	}

	log.Success(logger.LogKeycloakSendVerificationEmailOK, "email", email, "user_id", *user.ID)
	return nil
}

func (i *Interactor) RequestPasswordReset(ctx context.Context, email string) error {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	log.Info(logger.LogKeycloakSendPasswordReset, "email", email)

	if err := i.service.SendPasswordResetEmail(ctx, email); err != nil {
		log.Warn(logger.LogKeycloakSendPasswordResetError, "email", email, "error", err)
	} else {
		log.Success(logger.LogKeycloakSendPasswordResetOK, "email", email)
	}

	return nil
}

func (i *Interactor) VerifyEmailByToken(ctx context.Context, token string) (string, error) {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	log.Info(logger.LogKeycloakEmailVerify)

	email, err := i.service.VerifyEmailByToken(ctx, token)
	if err != nil {
		switch err {
		case domain.ErrInvalidToken:
			log.Error(logger.LogKeycloakEmailVerifyError, "error", err, "reason", "invalid token")
		case domain.ErrUserNotFound:
			log.Warn(logger.LogKeycloakUserNotFound, "email", email)
		case domain.ErrEmailAlreadyVerified:
			log.Warn(logger.LogKeycloakEmailAlreadyVerified, "email", email)
		default:
			log.Error(logger.LogKeycloakEmailVerifyError, "email", email, "error", err)
		}
		return email, err
	}

	log.Success(logger.LogKeycloakEmailVerifyOK, "email", email)
	return email, nil
}

func (i *Interactor) Login(ctx context.Context, email string, password string) (*dto.TokenResponse, error) {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	log.Info(logger.LogKeycloakUserLogin, "email", email, "client_ip")
	token, err := i.service.Login(ctx, email, password)
	if err != nil {
		log.Error(logger.LogKeycloakUserLoginError, "email", email, "error", err, "client_ip")
		return nil, err
	}

	log.Success(logger.LogKeycloakUserLoginOK, "email", email)
	return &dto.TokenResponse{
		ExpiresIn:    token.ExpiresIn,
		AccessToken:  token.AccessToken,
		RefreshToken: token.RefreshToken,
		TokenType:    token.TokenType,
	}, nil
}

func (i *Interactor) RefreshToken(ctx context.Context, refreshToken string) (*dto.TokenResponse, error) {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	log.Info(logger.LogKeycloakUserTokenRefresh)
	token, err := i.service.RefreshToken(ctx, refreshToken)
	if err != nil {
		log.Error(logger.LogKeycloakUserTokenRefreshErr, "error", err)
		return nil, err
	}

	log.Success(logger.LogKeycloakUserTokenRefreshOK)
	return &dto.TokenResponse{
		ExpiresIn:    token.ExpiresIn,
		AccessToken:  token.AccessToken,
		RefreshToken: token.RefreshToken,
		TokenType:    token.TokenType,
	}, nil
}

func (i *Interactor) UpdatePassword(ctx context.Context, token, newPassword, confirmPassword string) (string, error) {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	log.Info(logger.LogKeycloakPasswordUpdate)

	if newPassword != confirmPassword {
		log.Warn(logger.LogKeycloakPasswordMismatch)
		return "", domain.ErrPasswordMismatch
	}

	email, err := i.service.UpdatePassword(ctx, token, newPassword)
	if err != nil {
		switch err {
		case domain.ErrInvalidToken:
			log.Error(logger.LogKeycloakPasswordTokenInvalid, "error", err)
		case domain.ErrPasswordUpdateFailed:
			log.Error(logger.LogKeycloakPasswordUpdateError, "error", err)
		default:
			log.Error(logger.LogKeycloakPasswordUpdateError, "error", err)
		}
		return "", err
	}

	log.Success(logger.LogKeycloakPasswordUpdateOK, "email", email)
	return email, nil
}

func (i *Interactor) ChangePassword(ctx context.Context, email, currentPassword, newPassword, confirmPassword string) (string, error) {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	log.Info(logger.LogKeycloakChangePassword, "email", email)
	if newPassword != confirmPassword {
		log.Warn(logger.LogKeycloakChangePasswordMismatch, "email", email)
		return "", domain.ErrPasswordMismatch
	}

	resultEmail, err := i.service.ChangePassword(ctx, email, currentPassword, newPassword)
	if err != nil {
		switch err {
		case domain.ErrInvalidCurrentPassword:
			log.Warn(logger.LogKeycloakChangePasswordInvalid, "email", email)
		case domain.ErrUserNotFound:
			log.Warn(logger.LogKeycloakUserNotFound, "email", email)
		case domain.ErrPasswordUpdateFailed:
			log.Error(logger.LogKeycloakChangePasswordError, "email", email, "error", err)
		default:
			log.Error(logger.LogKeycloakChangePasswordError, "email", email, "error", err)
		}
		return "", err
	}

	log.Success(logger.LogKeycloakChangePasswordOK, "email", resultEmail)
	return resultEmail, nil
}

func (i *Interactor) DeleteEmployee(ctx context.Context, employeeID string) error {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	log.Info(logger.LogEmployeeDeleting, "employee_id", employeeID)
	employee, err := i.service.GetEmployeeByID(ctx, employeeID)
	if err != nil {
		log.Warn(logger.LogEmployeeNotFound, "employee_id", employeeID, "error", err)
		return domain.ErrPersonNotFound
	}

	if err := i.service.DeleteEmployee(ctx, employee.ID, employee.KeycloakUserID); err != nil {
		log.Error(logger.LogEmployeeDeleteError, "employee_id", employeeID, "error", err)
		return err
	}

	log.Success(logger.LogEmployeeDeleteComplete, "employee_id", employeeID, "email", employee.Email)
	return nil
}

func (i *Interactor) UpdateEmployee(ctx context.Context, employee domain.Employee) (*dto.UpdateEmployee, error) {
	traceID := middleware.GetTraceIDFromContext(ctx)
	log := log.WithTraceID(traceID)

	log.Info(logger.LogEmployeeUpdateRequest, employee.ToLogger())

	tx, err := i.service.BeginTx(ctx)
	if err != nil {
		log.Error(logger.LogDBTransactionBeginErr, "error", err)
		return nil, domain.ErrDatabaseUnavailable
	}

	defer func() {
		if err != nil {
			if rbErr := tx.Rollback(); rbErr != nil {
				log.Error(logger.LogDBTransactionRollback, "rollback_error", rbErr, "original_error", err)
			}
		}
	}()

	if err = i.service.UpdateEmployee(ctx, tx, employee); err != nil {
		log.Error(logger.LogEmployeeUpdateError, "employee_id", employee.ID, "error", err)
		return nil, err
	}
	log.Debug(logger.LogEmployeeUpdated, "employee_id", employee.ID)

	if err = tx.Commit(); err != nil {
		log.Error(logger.LogDBTransactionCommitErr, "error", err)
		return nil, domain.ErrDatabaseUnavailable
	}

	log.Success(logger.LogEmployeeUpdateComplete, employee.ToLogger())
	return &dto.UpdateEmployee{
		ID:      employee.ID,
		Updated: true,
		Message: logger.DtoMsgEmployeeUpdated,
	}, nil
}
