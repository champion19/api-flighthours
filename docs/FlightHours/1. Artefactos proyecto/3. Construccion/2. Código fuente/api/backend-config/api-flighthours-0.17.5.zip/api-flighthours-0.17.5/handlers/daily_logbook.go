package handlers

import (
	"time"

	domain "github.com/champion19/api-flighthours/core/interactor/services/domain"
)

const dateFormatISO = "2006-01-02"

// DailyLogbookResponse - Response DTO for daily logbook data
type DailyLogbookResponse struct {
	ID         string `json:"id"`
	LogDate    string `json:"log_date"`
	EmployeeID string `json:"employee_id"`
	BookPage   *int   `json:"book_page,omitempty"`
	Status     string `json:"status"`
	Links      []Link `json:"_links,omitempty"`
}

// FromDomainDailyLogbook converts domain.DailyLogbook to DailyLogbookResponse with encoded IDs
func FromDomainDailyLogbook(logbook *domain.DailyLogbook, encodedID, encodedEmployeeID string) DailyLogbookResponse {
	status := "inactive"
	if logbook.Status {
		status = "active"
	}
	return DailyLogbookResponse{
		ID:         encodedID,
		LogDate:    logbook.LogDate.Format(dateFormatISO),
		EmployeeID: encodedEmployeeID,
		BookPage:   logbook.BookPage,
		Status:     status,
	}
}

// CreateDailyLogbookRequest - Request DTO for creating a daily logbook
type CreateDailyLogbookRequest struct {
	LogDate  string `json:"log_date" binding:"required"`
	BookPage *int   `json:"book_page,omitempty"`
}

// Sanitize trims whitespace from CreateDailyLogbookRequest fields
func (r *CreateDailyLogbookRequest) Sanitize() {
	r.LogDate = TrimString(r.LogDate)
}

// ToDomain converts the request to a domain model
func (r *CreateDailyLogbookRequest) ToDomain(employeeID string) (*domain.DailyLogbook, error) {
	logDate, err := time.ParseInLocation(dateFormatISO, r.LogDate, time.Local)
	if err != nil {
		return nil, domain.ErrInvalidDateFormat
	}

	logbook := &domain.DailyLogbook{
		LogDate:    logDate,
		EmployeeID: employeeID,
		BookPage:   r.BookPage,
		Status:     true, // New logbooks are active by default
	}
	logbook.SetID()
	return logbook, nil
}

// UpdateDailyLogbookRequest - Request DTO for updating a daily logbook
type UpdateDailyLogbookRequest struct {
	LogDate  string `json:"log_date" binding:"required"`
	BookPage *int   `json:"book_page,omitempty"`
	Status   *bool  `json:"status,omitempty"`
}

// Sanitize trims whitespace from UpdateDailyLogbookRequest fields
func (r *UpdateDailyLogbookRequest) Sanitize() {
	r.LogDate = TrimString(r.LogDate)
}

// ToDomain converts the request to a domain model for update
func (r *UpdateDailyLogbookRequest) ToDomain(id, employeeID string) (*domain.DailyLogbook, error) {
	logDate, err := time.Parse(dateFormatISO, r.LogDate)
	if err != nil {
		return nil, domain.ErrInvalidDateFormat
	}

	status := true
	if r.Status != nil {
		status = *r.Status
	}

	return &domain.DailyLogbook{
		ID:         id,
		LogDate:    logDate,
		EmployeeID: employeeID,
		BookPage:   r.BookPage,
		Status:     status,
	}, nil
}

// DailyLogbookListResponse - Response DTO for listing daily logbooks
type DailyLogbookListResponse struct {
	Logbooks []DailyLogbookResponse `json:"daily_logbooks"`
	Total    int                    `json:"total"`
	Links    []Link                 `json:"_links,omitempty"`
}

// ToDailyLogbookListResponse converts a slice of domain.DailyLogbook to DailyLogbookListResponse
func ToDailyLogbookListResponse(logbooks []domain.DailyLogbook, encodeFunc func(string) (string, error), baseURL string) DailyLogbookListResponse {
	response := DailyLogbookListResponse{
		Logbooks: make([]DailyLogbookResponse, 0, len(logbooks)),
		Total:    len(logbooks),
	}

	for _, logbook := range logbooks {
		encodedID, err := encodeFunc(logbook.ID)
		if err != nil {
			// If encoding fails, use the original UUID
			encodedID = logbook.ID
		}
		encodedEmployeeID, err := encodeFunc(logbook.EmployeeID)
		if err != nil {
			encodedEmployeeID = logbook.EmployeeID
		}
		logbookResp := FromDomainDailyLogbook(&logbook, encodedID, encodedEmployeeID)
		// Add HATEOAS links to each logbook
		if baseURL != "" {
			logbookResp.Links = BuildDailyLogbookLinks(baseURL, encodedID)
		}
		response.Logbooks = append(response.Logbooks, logbookResp)
	}

	// Add collection-level links
	if baseURL != "" {
		response.Links = BuildDailyLogbookListLinks(baseURL)
	}

	return response
}

// DailyLogbookStatusResponse - Response DTO for daily logbook status changes
type DailyLogbookStatusResponse struct {
	ID      string `json:"id"`
	Status  string `json:"status"`
	Updated bool   `json:"updated"`
	Links   []Link `json:"_links,omitempty"`
}

// DailyLogbookDeleteResponse - Response DTO for daily logbook deletion
type DailyLogbookDeleteResponse struct {
	ID      string `json:"id"`
	Deleted bool   `json:"deleted"`
	Links   []Link `json:"_links,omitempty"`
}
