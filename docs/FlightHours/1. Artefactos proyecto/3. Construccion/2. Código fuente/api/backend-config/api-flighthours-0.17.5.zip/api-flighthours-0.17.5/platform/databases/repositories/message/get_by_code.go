package message

import (
	"context"
	"database/sql"

	"github.com/champion19/api-flighthours/core/interactor/services/domain"
)

func (r *repository) GetByCode(ctx context.Context, code string) (*domain.Message, error) {
	var m domain.Message

	err := r.db.QueryRowContext(ctx, queryGetByCode, code).Scan(
		&m.ID,
		&m.Code,
		&m.Type,
		&m.Category,
		&m.Module,
		&m.Title,
		&m.Content,
		&m.Active,
		&m.CreatedAt,
		&m.UpdatedAt,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}
	return &m, nil

}
